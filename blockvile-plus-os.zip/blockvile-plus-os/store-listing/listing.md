# Google Play store listing — copy & paste

Paste these into **Play Console → Grow → Store presence → Main store listing**.

## App name (max 30 characters)
```
Blockvile Plus OS
```

## Short description (max 80 characters)
```
Phone, tablet & laptop modes in one home screen, with 25+ built-in apps.
```

## Full description (max 4000 characters)
```
Blockvile Plus OS turns your phone into a smooth, modern home screen with three layouts in one: Phone, Tablet and Laptop.

THREE MODES
• Phone – home screen, dock, gestures and swipe-down panels
• Tablet – split-screen for two apps side by side
• Laptop – a desktop with a menu bar, dock and windows you can drag, resize and snap

TEMPORARY TAKEOVER
Tap "Temporarily let Blockvile take over this device" and Blockvile becomes your phone's home screen – only until you end it. Tap Exit or type "application exit" in the Terminal and your phone goes straight back to its usual home screen. It never starts by itself and is never permanent.

ACCOUNT, DIGITAL SIM & AI (OPTIONAL)
• Sign in with Google, Microsoft or any email address
• Digital SIM – your own Blockvile number for messaging other Blockvile users. It charges and banks Wi-Fi data while you're on Wi-Fi, which its messages use when Wi-Fi is off. It is not a phone-company SIM: no calls or texts to normal numbers
• Link your devices, open your Google and Microsoft apps and see unread mail, events and files
• Blockvile AI answers questions and runs device commands like "open Notes"

REAL PHONE CONTROLS
Brightness, volume and torch work for real, alarms and timers are set on your phone's clock, and Wi-Fi, Bluetooth and data open your phone's own switches.

YOUR APPS, YOUR WAY
• See every app on your phone in the Android Apps drawer – open, pin, or uninstall
• Get new Android apps: tap Install and Blockvile opens the app on Google Play; when it's installed, Blockvile adds it to your home screen
• Temporarily use Blockvile as your phone's home screen – only when you choose

25+ BUILT-IN APPS
Videos (YouTube), Files, Terminal, Text Editor, Notes, Videos, Help, Feedback, Calculator, Clock with alarms, Calendar, Reminders, Phone & Contacts, Weather, Maps, Browser, Camera, Gallery, Music player, Cloud Music, Voice Recorder, Paint, Task Manager, and games like Snake, 2048 and Tic-Tac-Toe.

CONTROL CENTRE & SETTINGS
• Dark mode, night light, Do Not Disturb and battery saver
• Brightness and volume sliders
• Accent colours, wallpapers or your own photo
• Optional PIN lock and auto-lock
• Large text, reduce motion and high contrast

SEARCH EVERYTHING
One search finds apps, files, settings and even does quick sums.

PRIVATE BY DESIGN
No account, no ads, no tracking. Your notes, files, photos and settings stay on your device.

Exit button and dark mode are one tap away – or use the keyboard shortcuts on tablets and laptops with a keyboard.
```

## Category & tags
- **App category:** Personalization
- **Tags (pick up to 5 in Play Console):** Launcher, Home screen, Customisation, Productivity, Themes

## Graphics (all in this folder)
| Play Console field | File | Size |
|---|---|---|
| App icon | `icon-512.png` | 512 × 512 |
| Feature graphic | `feature-graphic.png` | 1024 × 500 |
| Phone screenshots | `screenshots/phone-*.png` | 1080 × 1920 |
| 7-inch & 10-inch tablet screenshots | `screenshots/tablet-*.png` | 1920 × 1080 |

## Contact details
- **Email:** your contact e-mail (shown publicly on Play)
- **Website:** your GitHub Pages link, e.g. `https://<your-github-name>.github.io/<repo-name>/`
- **Privacy policy:** `https://<your-github-name>.github.io/<repo-name>/privacy.html`

---

## Data safety form — suggested answers
Answer these based on how *your* published version works. These match the code as delivered. (I'm not a lawyer — check Google's help text for each question.)

**Does your app collect or share any of the required user data types?** → **Yes** (location for weather/maps, plus account data if someone signs in)

| Data type | Collected? | Shared? | Notes to select |
|---|---|---|---|
| Location → Approximate location | Yes | Yes (with the weather / map service) | Processed ephemerally: **Yes** · Optional: **Yes** · Purpose: **App functionality** |
| Personal info → Email address, Name | Yes | No | Optional (only if the user signs in) · Purpose: **Account management**, **App functionality** |
| Personal info → User IDs | Yes | No | Optional · Purpose: **Account management** |
| Messages → Other in-app messages | Yes | No | Digital SIM messages, stored so the recipient can read them · Optional · Purpose: **App functionality** |
| Device or other IDs | Yes | No | The name of a device the user chooses to link · Optional · Purpose: **App functionality** |
| App activity → Other user-generated content | Yes | Yes (with the AI provider) | Questions typed into Blockvile AI · Optional · Processed to answer, not kept on the server · Purpose: **App functionality** |
| Everything else (contacts, photos, audio, files, app list…) | No | No | These stay on the device and are never transmitted, so Google doesn't count them as "collected" |

- **Is all data encrypted in transit?** → Yes (all services use HTTPS)
- **Can users request data deletion?** → Yes. Settings → Erase everything or uninstalling removes on-device data. For account data (email, name, SIM, messages) you must offer a way to ask for deletion — Play requires a **web link** for account deletion when an app lets people create accounts. Add a short page or form on your site (the contact e-mail in `privacy.html` works as a start, but check Google's current account-deletion rules).

## Other "App content" questions
- **Privacy policy:** your `privacy.html` link (fill in the two yellow placeholders first)
- **App access:** All functionality available without special access
- **Ads:** No, my app does not contain ads
- **Content rating:** questionnaire category *All other app types*. Answer **Yes** to "unrestricted internet access" (there's a web browser), and No to violence, sexual content, gambling and so on.
- **Target audience:** 13+ (choose the 13–15, 16–17 and 18+ groups). Don't pick under-13 groups: the app has an unrestricted browser.
- **News app / Government / Financial / Health:** No
