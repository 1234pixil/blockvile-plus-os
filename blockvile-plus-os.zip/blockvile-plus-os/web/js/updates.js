/* Blockvile Plus OS — software updates. Finds out when a newer version is published and updates in place
   (no re-download): the website/installed app refreshes its cache, the Android app downloads the new web files. */
(() => {
  const { store, esc } = window.BV;
  const CFG = () => window.BV_CONFIG || {};
  const local = () => window.BV_BUILD || { version: CFG().version || "", build: "" };
  const android = () => window.BV.android;
  const isAndroid = () => !!android()?.available;
  const os = () => window.BlockvileOS;
  const HOURS = 6;

  const st = { checking: false, remote: null, error: "", last: store.get("updLast", 0), applying: false, pct: 0, msg: "" };
  const emit = () => window.dispatchEvent(new Event("bv:update"));

  const cmp = (a, b) => { const x = String(a).split(".").map(Number), y = String(b).split(".").map(Number); for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d < 0 ? -1 : 1; } return 0; };

  // Where new versions are announced: the publisher's website (installUrl), or the site this copy is running from
  function versionUrl() {
    const base = CFG().installUrl;
    if (base) { try { return new URL("version.json", base.endsWith("/") ? base : base + "/").href; } catch { return ""; } }
    if (!isAndroid() && /^https?:$/.test(location.protocol)) return new URL("version.json", location.href).href;
    return "";
  }
  const nativeApi = () => (isAndroid() ? android().ota()?.api || 1 : 99);
  const otaOn = () => !isAndroid() || !!android().ota()?.enabled;

  const updates = {
    state: st, local,
    configured: () => !!versionUrl(),
    // is a newer version published?
    available() {
      const r = st.remote; if (!r?.build) return false;
      if (r.build === local().build) return false;
      return cmp(r.version, local().version) >= 0;       // never "update" to an older one
    },
    needsStore: () => !!st.remote && (st.remote.native || 1) > nativeApi(),
    async check(manual) {
      const url = versionUrl();
      if (!url) { st.error = isAndroid() ? "The publisher hasn't set the update address yet" : "Updates need the hosted website"; if (manual) emit(); return false; }
      if (st.checking) return updates.available();
      st.checking = true; st.error = ""; emit();
      try {
        const r = await fetch(url + "?t=" + Date.now(), { cache: "no-store" });
        if (!r.ok) throw new Error("HTTP " + r.status);
        const j = await r.json();
        if (typeof j.version !== "string" || !/^[a-f0-9]{12}$/.test(j.build || "")) throw new Error("bad version file");
        st.remote = { version: j.version, build: j.build, native: +j.native || 1, notes: Array.isArray(j.notes) ? j.notes.slice(0, 8).map(String) : [], released: j.released || "" };
        st.last = Date.now(); store.set("updLast", st.last);
      } catch (e) { st.error = navigator.onLine === false ? "You're offline" : "Couldn't reach the update server"; }
      st.checking = false; emit();
      if (updates.available()) announce();
      return updates.available();
    },
    async apply() {
      if (st.applying) return;
      if (!updates.available()) return os()?.toast("✅ Blockvile is up to date");
      const target = st.remote.version;
      if (updates.needsStore()) { android()?.playUpdate?.(); return os()?.toast("This update comes through Google Play"); }
      st.applying = true; st.pct = 0; st.msg = "Starting…"; st.error = ""; emit();
      store.set("updPending", { to: target, build: st.remote.build, notes: st.remote.notes || [] });
      if (isAndroid()) {
        if (!otaOn()) { st.applying = false; st.error = "The publisher hasn't set the update address yet"; emit(); return; }
        android().otaApply();                       // progress arrives as "bv:ota"; the app reloads itself when done
        return;
      }
      try {
        const reg = await navigator.serviceWorker?.getRegistration?.();
        const sw = reg?.active || navigator.serviceWorker?.controller;
        if (sw) {
          await new Promise((res, rej) => {
            const t = setTimeout(() => rej(new Error("timeout")), 30000);
            navigator.serviceWorker.addEventListener("message", function f(e) { if (e.data === "bv-updated") { clearTimeout(t); navigator.serviceWorker.removeEventListener("message", f); res(); } else if (e.data === "bv-update-failed") { clearTimeout(t); rej(new Error("failed")); } });
            sw.postMessage("bv-update");
          });
          try { await reg.update(); } catch { }
          location.reload();
        } else {
          // no offline cache (one-file copy, or the browser doesn't allow it): reload past the browser cache
          const u = new URL(location.href); u.searchParams.set("v", st.remote.build); location.replace(u.href);
        }
      } catch (e) { st.applying = false; st.error = "The update didn't finish — check your connection and try again"; store.del("updPending"); emit(); }
    },
    autoOn: () => store.get("autoUpdate", true),
    setAuto(v) { store.set("autoUpdate", !!v); emit(); },

    // The "Software update" section of Settings (sw = Settings' switch helper)
    html(sw) {
      const l = local(), r = st.remote, av = updates.available();
      const when = t => { if (!t) return "never"; const m = (Date.now() - t) / 6e4; return m < 1 ? "just now" : m < 60 ? Math.floor(m) + " min ago" : m < 1440 ? Math.floor(m / 60) + " h ago" : new Date(t).toLocaleDateString(); };
      const status = st.applying ? `Updating… ${st.pct ? st.pct + "%" : ""} ${esc(st.msg || "")}` : st.error ? "⚠️ " + esc(st.error) : st.checking ? "Checking…" : av ? `Blockvile ${esc(r.version)} is ready` : r ? "✅ You're up to date" : "Not checked yet";
      const notes = av && r.notes?.length ? `<div class="upd-notes"><b>What's new</b><ul>${r.notes.map(n => `<li>${esc(n)}</li>`).join("")}</ul></div>` : "";
      return `<div class="h" id="sec-update">Software update</div>
        <div class="list">
          <div><span>Blockvile Plus<br><small>${l.build ? "build " + esc(l.build) : "version " + esc(l.version)}</small></span><b>${esc(l.version)}</b></div>
          <div><span>Status<br><small>${status}</small></span>${av ? `<b style="color:var(--accent)">⬆️</b>` : ""}</div>
          ${av ? `<button data-k="updNow" ${st.applying ? "disabled" : ""}><span><b>⬆️ ${updates.needsStore() ? "Update on Google Play" : "Update now to " + esc(r.version)}</b><br><small>${updates.needsStore() ? "This release changes the Android app itself" : "Keeps your apps, files and settings. Takes a few seconds."}</small></span><small>›</small></button>` : ""}
          <button data-k="updCheck" ${st.checking || st.applying ? "disabled" : ""}><span>Check for updates<br><small>Last checked ${when(st.last)}</small></span><small>${st.checking ? "…" : "↻"}</small></button>
          ${sw("autoUpdate", updates.autoOn(), "Update automatically", "Installs new versions when you open Blockvile, as long as nothing is open")}
        </div>${notes}`;
    },
  };

  // Tell the person once per new version
  function announce() {
    const r = st.remote; if (!r || store.get("updNotified", "") === r.build) return;
    store.set("updNotified", r.build);
    os()?.notify({ app: "settings", action: "update", icon: "⬆️", title: "Update available", text: `Blockvile ${r.version} is ready. Tap to update.` });
  }

  // Android reports download progress
  window.addEventListener("bv:ota", e => {
    const d = e.detail || {};
    if (d.state === "downloading") { st.applying = true; st.pct = d.pct || 0; st.msg = d.msg || ""; }
    else if (d.state === "error") { st.applying = false; st.error = d.msg || "Update failed"; store.del("updPending"); }
    else if (d.state === "done") { st.msg = "Restarting…"; }
    emit();
  });

  // Auto: check shortly after start and whenever the app comes back after a few hours
  async function autoCheck(first) {
    if (!updates.configured()) return;
    if (!first && Date.now() - st.last < HOURS * 36e5) return;
    const has = await updates.check(false);
    if (!has || !updates.autoOn() || updates.needsStore()) return;
    const quiet = !(os()?.running?.().length) && !document.hidden;
    if (quiet && store.get("updAutoTried", "") !== st.remote.build) { store.set("updAutoTried", st.remote.build); os()?.toast("⬆️ Updating Blockvile…"); setTimeout(() => updates.apply(), 700); }
  }
  document.addEventListener("visibilitychange", () => { if (!document.hidden) autoCheck(false); });

  // After an update: say so
  function justUpdated() {
    const p = store.get("updPending", null); if (!p) return;
    store.del("updPending");
    if (p.build && local().build === p.build) {     // only say so if the new version is really the one running now
      setTimeout(() => os()?.notify({ app: "settings", action: "update", icon: "✅", title: "Blockvile updated", text: "You're on version " + local().version + (p.notes?.length ? " — " + p.notes[0] : ""), sound: false }), 1500);
    }
  }

  window.BV.updates = updates;
  window.addEventListener("load", () => { justUpdated(); setTimeout(() => autoCheck(true), 6000); });
})();
