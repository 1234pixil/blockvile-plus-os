# Publishing Blockvile Plus OS on Google Play

You don't need Android Studio. GitHub builds the app for you for free, and you upload the result to Google Play.

**How app installs work in the Play version:** Google Play's rules don't let a Play app download and install other apps by itself. Blockvile does what real launcher apps do:
- **Install** opens the app's Google Play page, and Google Play installs it.
- When you come back, Blockvile has already noticed the new app and adds it to your home screen with a notification.
- From the **Android Apps** drawer you can open, pin and uninstall any app on the phone. Uninstalling shows Android's own confirmation.
- **Temporary takeover:** only when the user taps *Temporarily let Blockvile take over this device*, Blockvile asks to be the phone's home screen. Android shows its own prompt, and the user can say no. It never starts by itself and is never permanent: **Exit**, the Terminal command `application exit`, or a phone restart switches off Blockvile's home-screen entry (`HomeAlias` in the manifest) and Home goes to the usual launcher again.

This is the version that will pass Play review.

---

## 1. Pick your app ID (do this first — it can never change)
Open `android/app/build.gradle.kts` and change
```
applicationId = "com.blockvile.plusos"
```
to something unique to you, for example `com.yourname.blockvile`. Use lower case, dots between parts, and no spaces.

## 2. Put the project on GitHub
1. Make a free account at github.com, then create a new repository, e.g. `blockvile-plus-os`.
2. Upload **everything in this folder**, including the hidden `.github` folder. **GitHub Desktop** is the easiest way to include hidden folders: choose *Add local repository*, then *Publish*.
3. Open the repo's **Actions** tab. A "Build Android app" run starts by itself and takes about 5–10 minutes.

## 3. Try the app on your phone
1. In **Actions**, click the finished "Build Android app" run.
2. Under **Artifacts**, download **blockvile-plus-test-apk** and unzip it to get `app-debug.apk`.
3. Copy it to your Android phone and open it. Allow "install unknown apps" when asked. This is only for your own testing.

> If the build fails, open the red step in the run and copy the error message. Paste it to me and I'll fix it. I wrote and compile-checked the code, but I couldn't run a full Android build in my workspace.

## 4. Turn on your website link (and the privacy policy)
1. Fill in the two yellow placeholders in `web/privacy.html`: the date and your contact e-mail.
2. In the repo, go to **Settings → Pages → Build and deployment → Source: GitHub Actions**.
3. The "Publish website" workflow runs. Your links will be:
   - Web version: `https://<your-github-name>.github.io/<repo-name>/`
   - One-file version (good for embedding): `https://<your-github-name>.github.io/<repo-name>/blockvile-plus-os.html`
   - Privacy policy: `https://<your-github-name>.github.io/<repo-name>/privacy.html`

## 5. Make your upload key (once, keep it forever)
Google Play needs your uploads signed with your own key. The `keytool` program comes with Java ([download Java 17+](https://adoptium.net) if you don't have it).

```
keytool -genkeypair -v -keystore upload.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```
Choose a password and remember it. **Back up `upload.jks` somewhere safe** and never put it in the GitHub repo.

Turn the key into text so GitHub can store it as a secret:
- **Windows (PowerShell):** `[Convert]::ToBase64String([IO.File]::ReadAllBytes("upload.jks")) | Set-Clipboard`
- **Mac:** `base64 -i upload.jks | pbcopy`
- **Linux:** `base64 -w0 upload.jks`

In the repo, open **Settings → Secrets and variables → Actions → New repository secret** and add these four:

| Name | Value |
|---|---|
| `BV_KEYSTORE_BASE64` | the long text you just copied |
| `BV_KEYSTORE_PASSWORD` | your keystore password |
| `BV_KEY_ALIAS` | `upload` |
| `BV_KEY_PASSWORD` | your key password (the same one, if you only set one) |

Then go to **Actions → Build Android app → Run workflow**. This time there's a second artifact, **blockvile-plus-play-bundle**, which contains `app-release.aab`. That's the file you upload to Google Play.

Each run automatically gets a higher version number, which Play requires for every upload.

## 6. Google Play Console
1. Sign up at [play.google.com/console](https://play.google.com/console). It's a one-time fee, and Google verifies your identity.
2. **Create app:** name *Blockvile Plus OS*, choose App, choose Free, and accept the declarations.
3. **App content** (left menu): fill every section using `store-listing/listing.md`. It has suggested answers for Privacy policy, Ads, Content rating, Target audience and Data safety.
4. **Main store listing:** paste the text and upload the graphics from the `store-listing` folder.
5. **Testing → Closed testing:**
   - Create a track, upload `app-release.aab`, and add your testers' e-mails.
   - New *personal* developer accounts must run a closed test with at least **12 testers** who stay opted in for **14 days** before you can publish to everyone. Ask friends and family to join through the opt-in link and install it.
   - Google sometimes changes these numbers; the Console tells you exactly what your account needs.
6. After the test, go to **Production → Create new release**, upload the latest `.aab`, and send it for review. Reviews usually take a few days.

## 7. Updating the app later
Edit files in `web/` or `android/` and push to GitHub. A new signed `.aab` appears in Actions. Upload it as a new release in Play Console.

---

### Notes for Play review
- **Package visibility:** the app only asks to see apps with a launcher icon (plus the Play Store). It does **not** use the restricted `QUERY_ALL_PACKAGES` permission.
- **No self-installing:** the app never downloads or installs app files itself. Installs always go through Google Play.
- **Permissions:**
  - Camera, microphone and approximate location are asked only when the user opens the Camera, Recorder, or "My location" in Weather or Maps.
  - `REQUEST_DELETE_PACKAGES` only opens Android's own uninstall confirmation.
  - `POST_NOTIFICATIONS` is for reminders, alarms and other Blockvile notifications while it's in the background. Android asks the user.
  - `SET_ALARM` lets the Clock app hand alarms and timers to the phone's own Clock app. It can't read or change other alarms.
  - `VIBRATE` is for touch feedback.
  - `ACCESS_NETWORK_STATE` lets the Digital SIM check whether the phone is on Wi-Fi.
  - The `blockvile://auth` link brings the user back after Google/Microsoft sign-in in their browser.
- **Temporary home screen:** Blockvile only becomes the home screen when the user taps the takeover button AND agrees in Android's own prompt. It ends with Exit, `application exit` or a restart, and the home entry is disabled by default. `RECEIVE_BOOT_COMPLETED` is used only to end a takeover after a restart. In the listing, describe it honestly: "temporarily take over your phone's home screen, only until you exit".
- **Wi-Fi, Bluetooth, mobile data, airplane mode:** Android doesn't let apps switch these. Blockvile opens the phone's own settings panel for each one, which is allowed.
- **Trademarks:** the in-app list of popular Android apps only shows names, emoji and links to their real Play pages. Don't put other companies' names or logos in your store listing, icon or screenshots.
- **Updates:** the app downloads updated *web files* (HTML/CSS/JS) from your website and checks each one's SHA-256 before using it. It never downloads or runs app code. Play policy forbids apps updating their own code outside Play, but web content shown in a WebView is the normal exception. Read Google's current policy before you publish and mention nothing in the listing that suggests the app replaces itself. Set `installUrl` in `web/js/config.js` before building. See `UPDATING.md`.
- **Accounts:** if you turn on sign-in (see `SUPABASE-SETUP.md`), update the Data safety form as in `store-listing/listing.md`, and provide an **account-deletion web link** — Google Play requires one for apps that let people create accounts.
- **Digital SIM:** it is an in-app messaging number, not a phone-company SIM. Keep the listing wording honest ("messaging number that charges on Wi-Fi") so reviewers and users aren't misled.
