# Updating Blockvile (nobody has to download it again)

Blockvile updates itself, like a phone: people get a notification, or open the **Software Update** app (it has its own icon) and tap **Update now**. Their apps, files and settings stay as they are.

## How you publish an update
1. Change whatever you like in `web/`. For a new version number, edit `version` in `web/js/config.js` (e.g. `"3.9"` → `"3.10"`).
2. Optional: write a few short lines about what's new in `RELEASE-NOTES.txt` (one per line). People see them in the Software Update app.
3. Publish the website:
   - **GitHub:** push to `main`. The "Publish website" workflow runs `tools/make-version.py` and deploys.
   - **Publisher Pad / any host:** run `python3 tools/make-version.py` (or `python3 tools/build-single-file.py`, which runs it), then upload the `web/` folder again. It must include the new `version.json` and `js/build.js`.
4. That's it. Every installed copy notices within hours (or when it's next opened) and offers the update.

## What updates how
| Copy | How it updates |
|---|---|
| Website / installed web app (PWA) / one-file page on a website | Refreshes its offline files from your site, then reloads. Works as soon as `version.json` is on the site. |
| Android app (Play) | Downloads the new **web files** from your website (over HTTPS, every file checked against its SHA-256 in `version.json`), then reloads. No Play update needed. |
| Android app, when you changed the Android code | Changes to `android/…` (manifest, Java) can only arrive through Google Play. Raise `nativeApi` in `web/js/config.js` for that release: installed apps then show **Update on Google Play** instead of the web update. |

**Android needs one setting:** put your website address in `installUrl` in `web/js/config.js` (e.g. `"https://yourname.github.io/blockvile-plus-os/"`, with `https://` and a final `/`) **before you build the Android app**. Without it the Android app can't find updates by itself.

## Safety
- If a downloaded Android update doesn't start properly, the next time the app opens it throws it away and goes back to the version inside the app.
- When Play delivers a new version of the app, any older downloaded update is removed so it can't hide newer files.
- Only web files (HTML, CSS, JavaScript, images) are downloaded. No app code is installed. Google Play's rules are about not replacing the app's own code outside Play; keep it that way, and check the current policy before you publish.
- Anyone who can change your website can change what the Android app shows, so protect your GitHub account (2-step sign-in) and keep the repo private-write.
