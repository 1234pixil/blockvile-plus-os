package com.blockvile.plusos;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.os.BatteryManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Exposed to the Blockvile web OS as window.BlockvileAndroid.
 * Installs always go through Google Play (Play policy doesn't allow apps to install other apps
 * themselves); Blockvile opens the Play listing, then notices the new app once Play has installed it.
 */
public class AndroidBridge {

    private static final Pattern PACKAGE = Pattern.compile("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+");
    private static final String PLAY_STORE = "com.android.vending";
    private final MainActivity activity;
    private static final String CHANNEL = "blockvile";
    private int notificationId = 1000;

    AndroidBridge(MainActivity activity) {
        this.activity = activity;
    }

    private static boolean validPackage(String pkg) {
        return pkg != null && pkg.length() < 256 && PACKAGE.matcher(pkg).matches();
    }

    /** Every app with a launcher icon, as JSON: [{"pkg": "...", "name": "..."}], sorted by name. */
    @JavascriptInterface
    public String listApps() {
        PackageManager pm = activity.getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found = pm.queryIntentActivities(main, 0);
        List<String[]> apps = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (ResolveInfo ri : found) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(activity.getPackageName()) || !seen.add(pkg)) continue;
            apps.add(new String[]{pkg, String.valueOf(ri.loadLabel(pm))});
        }
        Collections.sort(apps, (a, b) -> a[1].toLowerCase(Locale.ROOT).compareTo(b[1].toLowerCase(Locale.ROOT)));
        JSONArray out = new JSONArray();
        try {
            for (String[] a : apps) out.put(new JSONObject().put("pkg", a[0]).put("name", a[1]));
        } catch (JSONException ignored) { }
        return out.toString();
    }

    @JavascriptInterface
    public boolean isInstalled(String pkg) {
        return validPackage(pkg) && activity.getPackageManager().getLaunchIntentForPackage(pkg) != null;
    }

    @JavascriptInterface
    public boolean launchApp(String pkg) {
        if (!validPackage(pkg)) return false;
        Intent launch = activity.getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) return false;
        activity.startSafely(launch);
        return true;
    }

    /** App icon as a PNG data URL. */
    @JavascriptInterface
    public String getIcon(String pkg) {
        if (!validPackage(pkg)) return "";
        try {
            Drawable d = activity.getPackageManager().getApplicationIcon(pkg);
            int size = 128;
            Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bmp);
            d.setBounds(0, 0, size, size);
            d.draw(c);
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.PNG, 100, bytes);
            bmp.recycle();
            return "data:image/png;base64," + Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP);
        } catch (PackageManager.NameNotFoundException e) {
            return "";
        }
    }

    /** Opens the app's page in the Google Play Store app (or the Play website if Play isn't installed). */
    @JavascriptInterface
    public void openPlayStore(String pkg) {
        if (!validPackage(pkg)) return;
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + Uri.encode(pkg)));
        i.setPackage(PLAY_STORE);
        activity.startWithFallback(i, new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + Uri.encode(pkg))));
    }

    @JavascriptInterface
    public void openPlaySearch(String query) {
        if (query == null || query.trim().isEmpty()) return;
        String q = Uri.encode(query.trim());
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + q + "&c=apps"));
        i.setPackage(PLAY_STORE);
        activity.startWithFallback(i, new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=" + q + "&c=apps")));
    }

    /** Opens web links, phone numbers and e-mail addresses in the right app. */
    @JavascriptInterface
    public void openUrl(String url) {
        if (url == null) return;
        String u = url.trim();
        String lower = u.toLowerCase(Locale.ROOT);
        if (lower.startsWith("https://") || lower.startsWith("http://") || lower.startsWith("tel:")
                || lower.startsWith("mailto:") || lower.startsWith("market://")) {
            activity.openExternal(u);
        }
    }

    /* ================= Updates ================= */

    /** {"enabled":bool,"build":"","api":1,"version":"3.9"} — enabled once the publisher set installUrl in config.js. */
    @JavascriptInterface
    public String otaStatus() {
        try {
            return new JSONObject().put("enabled", activity.ota.enabled()).put("build", activity.ota.current())
                    .put("api", MainActivity.NATIVE_API).put("version", MainActivity.VERSION).toString();
        } catch (JSONException e) {
            return "{}";
        }
    }

    /** Downloads the newest web files in the background, then reloads. Progress arrives as "bv:ota" events. */
    @JavascriptInterface
    public void otaApply() {
        new Thread(() -> {
            try {
                activity.ota.apply((state, pct, msg) -> activity.js("window.dispatchEvent(new CustomEvent('bv:ota',{detail:{state:" + JSONObject.quote(state) + ",pct:" + pct + ",msg:" + JSONObject.quote(msg) + "}}))"));
                activity.reloadPage();
            } catch (Exception e) {
                String m = e.getMessage() == null ? "Update failed" : e.getMessage();
                activity.js("window.dispatchEvent(new CustomEvent('bv:ota',{detail:{state:'error',pct:0,msg:" + JSONObject.quote(m) + "}}))");
            }
        }, "bv-ota").start();
    }

    /** The page started fine: keep the update. */
    @JavascriptInterface
    public void otaBooted() {
        activity.ota.confirmBoot();
    }

    /** Opens this app's own Google Play page (for updates that need a new Android app). */
    @JavascriptInterface
    public void playUpdate() {
        activity.openExternal("market://details?id=" + activity.getPackageName());
    }

    /** The blockvile://auth link that finished a Google/Microsoft sign-in while the app was closed (or "" if none). */
    @JavascriptInterface
    public String pendingDeepLink() {
        String d = activity.takePendingDeepLink();
        return d == null ? "" : d;
    }

    /** Shows Android's own "Uninstall this app?" confirmation. */
    @JavascriptInterface
    public void uninstall(String pkg) {
        if (!validPackage(pkg)) return;
        activity.startSafely(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg)));
    }

    @JavascriptInterface
    public void appInfo(String pkg) {
        if (!validPackage(pkg)) return;
        activity.startSafely(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg)));
    }

    @JavascriptInterface
    public boolean isDefaultLauncher() {
        return activity.isDefaultLauncher();
    }


    @JavascriptInterface
    public String deviceInfo() {
        try {
            return new JSONObject()
                    .put("model", Build.MANUFACTURER + " " + Build.MODEL)
                    .put("android", Build.VERSION.RELEASE)
                    .put("sdk", Build.VERSION.SDK_INT)
                    .put("version", MainActivity.VERSION)
                    .toString();
        } catch (JSONException e) {
            return "{}";
        }
    }

    /** Saves a file from Blockvile (photos, drawings, recordings) into Downloads/Blockvile. */
    @JavascriptInterface
    public String saveFile(String base64, String name, String mime) {
        try {
            byte[] data = Base64.decode(base64, Base64.DEFAULT);
            String safeName = (name == null || name.isEmpty() ? "blockvile-file" : name).replaceAll("[\\\\/:*?\"<>|]", "_");
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime == null || mime.isEmpty() ? "application/octet-stream" : mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Blockvile");
                ContentResolver r = activity.getContentResolver();
                Uri uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) return "";
                try (OutputStream os = r.openOutputStream(uri)) {
                    if (os == null) return "";
                    os.write(data);
                }
                return "Downloads/Blockvile";
            } else {
                File dir = activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (dir == null) return "";
                File f = new File(dir, safeName);
                try (FileOutputStream os = new FileOutputStream(f)) {
                    os.write(data);
                }
                return f.getAbsolutePath();
            }
        } catch (Exception e) {
            return "";
        }
    }

    /* ================= Temporary takeover & Exit ================= */

    /**
     * "Temporarily let Blockvile take over this device": Blockvile becomes the home screen (Android shows
     * its own prompt first). Always temporary — ends with Exit, "application exit", or a restart.
     */
    @JavascriptInterface
    public void startTakeover() {
        activity.startTakeover();
    }

    /** Exit / "application exit": end the takeover and go back to the phone's original home screen. */
    @JavascriptInterface
    public void exitToSystem() {
        activity.exitToSystem();
    }

    /** {"active":bool, "isHome":bool, "previousHome":"Pixel Launcher"} */
    @JavascriptInterface
    public String takeoverStatus() {
        try {
            return new JSONObject()
                    .put("active", activity.takeoverActive())
                    .put("isHome", activity.isDefaultLauncher())
                    .put("previousHome", activity.previousHomeLabel())
                    .toString();
        } catch (JSONException e) {
            return "{}";
        }
    }

    /* ================= Real device controls ================= */

    /** 0–100 for this screen, or -1 to follow the phone's own brightness. */
    @JavascriptInterface
    public void setBrightness(int percent) {
        activity.setScreenBrightness(percent);
    }

    @JavascriptInterface
    public void keepScreenOn(boolean on) {
        activity.keepScreenOn(on);
    }

    /** Media volume, 0–100. */
    @JavascriptInterface
    public void setVolume(int percent) {
        AudioManager am = activity.getSystemService(AudioManager.class);
        if (am == null) return;
        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int v = Math.round(Math.max(0, Math.min(100, percent)) / 100f * max);
        try {
            am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0);
        } catch (SecurityException ignored) { } // e.g. Do Not Disturb restrictions
    }

    @JavascriptInterface
    public int getVolume() {
        AudioManager am = activity.getSystemService(AudioManager.class);
        if (am == null) return -1;
        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        return max == 0 ? 0 : Math.round(am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100f / max);
    }

    /** The phone's real torch (flashlight). Returns false if there's no flash. */
    @JavascriptInterface
    public boolean setTorch(boolean on) {
        CameraManager cm = activity.getSystemService(CameraManager.class);
        if (cm == null) return false;
        try {
            for (String id : cm.getCameraIdList()) {
                Boolean flash = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (Boolean.TRUE.equals(flash)) {
                    cm.setTorchMode(id, on);
                    return true;
                }
            }
        } catch (CameraAccessException | IllegalArgumentException | SecurityException ignored) { }
        return false;
    }

    /**
     * Opens the phone's real setting for something apps aren't allowed to switch themselves
     * (Wi-Fi, Bluetooth, mobile data, airplane mode, Do Not Disturb, battery saver…).
     */
    @JavascriptInterface
    public void openPanel(String which) {
        String w = which == null ? "" : which;
        Intent primary, fallback = new Intent(Settings.ACTION_SETTINGS);
        switch (w) {
            case "wifi":
                primary = new Intent(Build.VERSION.SDK_INT >= 29 ? Settings.Panel.ACTION_WIFI : Settings.ACTION_WIFI_SETTINGS);
                fallback = new Intent(Settings.ACTION_WIFI_SETTINGS);
                break;
            case "data":
                primary = new Intent(Build.VERSION.SDK_INT >= 29 ? Settings.Panel.ACTION_INTERNET_CONNECTIVITY : Settings.ACTION_DATA_ROAMING_SETTINGS);
                fallback = new Intent(Settings.ACTION_WIRELESS_SETTINGS);
                break;
            case "bluetooth":
                primary = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
                break;
            case "airplane":
                primary = new Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS);
                fallback = new Intent(Settings.ACTION_WIRELESS_SETTINGS);
                break;
            case "volume":
                primary = new Intent(Build.VERSION.SDK_INT >= 29 ? Settings.Panel.ACTION_VOLUME : Settings.ACTION_SOUND_SETTINGS);
                fallback = new Intent(Settings.ACTION_SOUND_SETTINGS);
                break;
            case "dnd":
                primary = new Intent("android.settings.ZEN_MODE_SETTINGS");
                fallback = new Intent(Settings.ACTION_SOUND_SETTINGS);
                break;
            case "battery":
                primary = new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS);
                break;
            case "display":
                primary = new Intent(Settings.ACTION_DISPLAY_SETTINGS);
                break;
            case "notifications":
                primary = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, activity.getPackageName());
                break;
            default:
                primary = new Intent(Settings.ACTION_SETTINGS);
        }
        activity.startWithFallback(primary, fallback);
    }

    /** A real Android notification (used when Blockvile isn't on screen). */
    @JavascriptInterface
    public boolean notify(String title, String text) {
        if (Build.VERSION.SDK_INT >= 33
                && activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        NotificationManager nm = activity.getSystemService(NotificationManager.class);
        if (nm == null) return false;
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Blockvile", NotificationManager.IMPORTANCE_DEFAULT));
        }
        Intent open = new Intent(activity, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(activity, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(activity, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_blockvile)
                .setContentTitle(title == null ? "" : title)
                .setContentText(text == null ? "" : text)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build();
        nm.notify(notificationId++, n);
        return true;
    }

    /** True when the phone is on Wi-Fi (or Ethernet). The Digital SIM only charges then. */
    @JavascriptInterface
    public boolean onWifi() {
        try {
            ConnectivityManager cm = (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm == null ? null : cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities c = cm.getNetworkCapabilities(n);
            return c != null && (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public boolean canNotify() {
        return Build.VERSION.SDK_INT < 33
                || activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    @JavascriptInterface
    public void askNotifyPermission() {
        if (Build.VERSION.SDK_INT >= 33) activity.askPermission(Manifest.permission.POST_NOTIFICATIONS, MainActivity.REQ_PERM_NOTIFY);
    }

    /** Sets a real alarm in the phone's own Clock app, so it rings even when Blockvile is closed. */
    @JavascriptInterface
    public void setAlarm(int hour, int minute, String label) {
        Intent i = new Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label == null || label.isEmpty() ? "Blockvile alarm" : label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        activity.startSafely(i);
    }

    /** Starts a real timer in the phone's own Clock app. */
    @JavascriptInterface
    public void setTimer(int seconds, String label) {
        Intent i = new Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, Math.max(1, seconds))
                .putExtra(AlarmClock.EXTRA_MESSAGE, label == null || label.isEmpty() ? "Blockvile timer" : label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        activity.startSafely(i);
    }

    /** Opens the phone's calendar with a new event filled in. */
    @JavascriptInterface
    public void addCalendarEvent(String title, double startMillis, double endMillis) {
        Intent i = new Intent(Intent.ACTION_INSERT)
                .setData(CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.Events.TITLE, title == null ? "" : title)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, (long) startMillis)
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, (long) endMillis);
        activity.startSafely(i);
    }

    @JavascriptInterface
    public void vibrate(int ms) {
        Vibrator v;
        if (Build.VERSION.SDK_INT >= 31) {
            VibratorManager vm = activity.getSystemService(VibratorManager.class);
            v = vm == null ? null : vm.getDefaultVibrator();
        } else {
            v = activity.getSystemService(Vibrator.class);
        }
        if (v == null || !v.hasVibrator()) return;
        v.vibrate(VibrationEffect.createOneShot(Math.max(1, Math.min(1000, ms)), VibrationEffect.DEFAULT_AMPLITUDE));
    }

    /** Android's share sheet. */
    @JavascriptInterface
    public void share(String subject, String text) {
        Intent send = new Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_SUBJECT, subject == null ? "" : subject)
                .putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
        activity.startSafely(Intent.createChooser(send, null));
    }

    /** {"level":0.87,"charging":true} */
    @JavascriptInterface
    public String battery() {
        BatteryManager bm = activity.getSystemService(BatteryManager.class);
        try {
            if (bm == null) return "{}";
            return new JSONObject()
                    .put("level", bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) / 100.0)
                    .put("charging", bm.isCharging())
                    .toString();
        } catch (JSONException e) {
            return "{}";
        }
    }
}
