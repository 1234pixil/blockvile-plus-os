// Blockvile Code AI — Supabase Edge Function (name it: blockvile-code)
// Used by the Publisher buttons "Avatar connector with AI" and "Multiplayer connector with AI".
// Secret needed: GEMINI_API_KEY1 (same as blockvile-ai). Keep "Verify JWT" on.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (b: unknown, status = 200) => new Response(JSON.stringify(b), { status, headers: { ...cors, "Content-Type": "application/json" } });
const MODEL = "gemini-2.5-flash";

const DOCS = `
Two helper libraries are ALREADY loaded automatically in every Blockvile game (do NOT add script tags for them, do NOT redefine them):

BVAvatar (3D avatars, needs three.js):
  BVAvatar.wear(THREE, playerGroup, { height: 1.8, hide: [oldBodyMeshOrGroup, ...] })  // puts the local player's own 3D avatar on playerGroup; hide lists the old body parts to hide. Does nothing if the player has no 3D avatar.
  BVAvatar.wearFrom(THREE, otherPlayerGroup, peer.avatar, { height: 1.8, hide: [...] })  // same for another player (peer.avatar comes from BVRoom)
  BVAvatar.share()  // tiny object describing my avatar (BVRoom already sends it for you)
  If the game imports three as an ES module, pass the loader you imported: { GLTFLoader: GLTFLoader } in the options.

BVRoom (easy multiplayer through Supabase Realtime, nothing to set up):
  var room = BVRoom.join("roomName", { name: "Player name" });  // same room name = same lobby
  room.setState({ ...small plain object... });   // my current state (position, rotation, animation...). Call every frame if you like; it is throttled to ~10 per second.
  room.on("join", function (peer) {});  room.on("leave", function (peer) {});  room.on("state", function (peer) {});  room.on("avatar", function (peer) {});
  room.emit("eventName", data); room.on("eventName", function (peer, data) {});   // one-off events like shots, chat, pickups
  room.peers  // { id: { id, name, state, avatar } } everyone else
  room.id, room.leave()
  Rooms are open to anyone: never send secrets.
`;
const TASKS: Record<string, string> = {
  avatar: `TASK: Make this game use the player's own 3D avatar. Find the player's character (the THREE.Group/Object3D that represents the local player; also the other players in multiplayer if they exist) and add BVAvatar.wear(...) after it is created (and again if the character is rebuilt/respawned), hiding the old body parts. If the character is created in a function that runs more than once, call it there. If the game is not 3D / does not use three.js, do not change the code and explain that in the NOTE line.`,
  multiplayer: `TASK: Make this game multiplayer using BVRoom. Join a room named after the game (lowercase, dashes). Send the local player's state with room.setState each frame (position x,y,z, rotation, and anything needed to draw them, e.g. animation phase). For every peer, create a visible stand-in for the other player (reuse the game's own character/model builder, with a name label if easy), update it from peer.state with simple smoothing, and remove it on "leave". If the game uses 3D avatars, also call BVAvatar.wearFrom for peers on the "avatar" event. Use room.emit/room.on for important one-off events only if the game clearly has them (shooting, collecting, chat). Keep single-player behaviour working if nobody else is there.`,
};
const SYSTEM = `You are a careful web-game programmer inside the Blockvile Publisher. You receive ONE complete HTML game file and a task.
${DOCS}
Rules:
- Change as little as possible; keep every existing feature working. Do not rewrite or reformat unrelated code. Add short comments starting with "Blockvile:" next to what you add.
- Reply in exactly this format and nothing else:
NOTE: <one or two short plain sentences about what you changed, or why you could not>
<<<CODE
<the COMPLETE updated HTML file>
CODE>>>
- If you cannot do it safely, put the reason in NOTE and return the original code unchanged between the markers.`;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ error: "POST only" }, 405);
  const auth = req.headers.get("Authorization") ?? "";
  const supa = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: auth } } });
  const { data: { user } } = await supa.auth.getUser();
  if (!user) return json({ error: "Log in first" }, 401);
  const key = Deno.env.get("GEMINI_API_KEY1");
  if (!key) return json({ error: "The AI key hasn't been set up on the server yet" }, 503);

  let task = "", code = "";
  try { const b = await req.json(); task = String(b.task ?? ""); code = String(b.code ?? ""); } catch { return json({ error: "Bad request" }, 400); }
  if (!TASKS[task]) return json({ error: "Unknown task" }, 400);
  if (code.trim().length < 20) return json({ error: "Put your game code in the editor first" }, 400);
  if (code.length > 200000) return json({ error: "The game is too big for the AI (over about 200,000 characters)" }, 413);

  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
    method: "POST",
    headers: { "x-goog-api-key": key, "content-type": "application/json" },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: SYSTEM }] },
      contents: [{ role: "user", parts: [{ text: `${TASKS[task]}\n\nHere is the game file:\n<<<CODE\n${code}\nCODE>>>` }] }],
      generationConfig: { maxOutputTokens: 60000, temperature: 0.2 },
    }),
  });
  if (!r.ok) return json({ error: "The AI service is busy, try again" }, 502);
  const out = await r.json();
  const text = (out.candidates?.[0]?.content?.parts ?? []).map((p: { text?: string }) => p.text ?? "").join("");
  const note = (text.match(/NOTE:\s*([^\n]*)/)?.[1] ?? "").trim();
  const m = text.match(/<<<CODE\n?([\s\S]*?)\n?CODE>>>/);
  let newCode = (m?.[1] ?? "").replace(/^```[a-z]*\n/i, "").replace(/\n```$/, "");
  if (out.candidates?.[0]?.finishReason === "MAX_TOKENS") return json({ error: "The game is too long for the AI to finish. Try a smaller game." }, 413);
  if (!newCode.trim() || !/<\/(html|body|script)>/i.test(newCode)) return json({ error: "The AI answer wasn't usable, try again" }, 502);
  return json({ code: newCode, note, changed: newCode.trim() !== code.trim() });
});
