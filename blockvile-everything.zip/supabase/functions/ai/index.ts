// Blockvile AI — Supabase Edge Function (name it: ai)
// reads your Gemini key from the secret GEMINI_API_KEY1. The key never goes in the app.
const KEY = Deno.env.get("GEMINI_API_KEY1") ?? "";
const MODEL = "gemini-2.5-flash";
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const send = (o: unknown, status = 200) =>
  new Response(JSON.stringify(o), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return send({ error: "Use POST" }, 405);
  if (!KEY) return send({ error: "The Gemini key secret is missing" }, 500);
  let body: any;
  try { body = await req.json(); } catch { return send({ error: "Bad request" }, 400); }
  const prompt = String(body?.prompt ?? "").slice(0, 4000);
  if (!prompt.trim()) return send({ error: "Say something first" }, 400);
  // optional chat history: [{role:"user"|"model", text:"..."}]
  const history = (Array.isArray(body?.history) ? body.history : []).slice(-12)
    .map((m: any) => ({ role: m?.role === "model" ? "model" : "user", parts: [{ text: String(m?.text ?? "").slice(0, 2000) }] }));
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-goog-api-key": KEY },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: "You are Blockvile AI, a friendly helper inside Blockvile Plus OS. Keep answers short and simple." }] },
      contents: [...history, { role: "user", parts: [{ text: prompt }] }],
    }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) return send({ error: j?.error?.message ?? "The AI had a problem" }, 502);
  const text = j?.candidates?.[0]?.content?.parts?.map((p: any) => p.text ?? "").join("") ?? "";
  return send({ text: text || "I have no answer for that." });
});
