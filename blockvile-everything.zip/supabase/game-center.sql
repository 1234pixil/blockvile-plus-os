-- Blockvile Game Center: games published by players (Publisher Pad or the Game Center's Publish button).
-- Safe to run more than once. Run it in Supabase: SQL Editor -> paste all -> Run.
-- Moderation: a new game is visible only to its author until YOU approve it
-- (Table Editor -> gc_games -> tick "approved" on the row). Editing the code sends it back for approval.

create table if not exists public.gc_games (
  id          text primary key check (id ~ '^[a-z0-9-]{3,60}$'),
  owner       uuid not null default auth.uid() references auth.users(id) on delete cascade,
  title       text not null check (char_length(title) between 2 and 40),
  description text not null default '' check (char_length(description) <= 400),
  category    text not null default 'Arcade' check (category in ('3D','Action','Adventure','Arcade','Learning','Obby','Puzzle','Strategy','Sandbox','Other')),
  icon        text not null default '🎮' check (char_length(icon) between 1 and 8),
  color       text not null default '#74c0fc' check (color ~ '^#[0-9a-fA-F]{6}$'),
  code        text not null check (char_length(code) between 40 and 400000),
  author_name text not null default 'player' check (char_length(author_name) between 1 and 30),
  approved    boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists gc_games_created_idx on public.gc_games (created_at desc);

alter table public.gc_games enable row level security;

drop policy if exists gc_games_read   on public.gc_games;
drop policy if exists gc_games_insert on public.gc_games;
drop policy if exists gc_games_update on public.gc_games;
drop policy if exists gc_games_delete on public.gc_games;
-- Admins (you): can see every submission, preview it, approve it or reject it from the Publisher app's Review tab.
create table if not exists public.gc_admins (user_id uuid primary key references auth.users(id) on delete cascade);
alter table public.gc_admins enable row level security;
drop policy if exists gc_admins_self on public.gc_admins;
create policy gc_admins_self on public.gc_admins for select to authenticated using (user_id = auth.uid());
grant select on public.gc_admins to authenticated;
create or replace function public.gc_is_admin() returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.gc_admins where user_id = auth.uid())
$$;
grant execute on function public.gc_is_admin() to anon, authenticated;

create policy gc_games_read   on public.gc_games for select using (approved or owner = auth.uid() or public.gc_is_admin());
create policy gc_games_insert on public.gc_games for insert to authenticated with check (owner = auth.uid() and approved = false);
create policy gc_games_update on public.gc_games for update to authenticated using (owner = auth.uid() or public.gc_is_admin()) with check (owner = auth.uid() or public.gc_is_admin());
create policy gc_games_delete on public.gc_games for delete to authenticated using (owner = auth.uid() or public.gc_is_admin());

-- Players can never approve their own games, a changed game needs approving again, and nobody can flood the store.
create or replace function public.gc_games_guard() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if coalesce(auth.role(), '') = 'authenticated' then
    if tg_op = 'INSERT' then
      new.approved := false;
      if (select count(*) from public.gc_games where owner = auth.uid()) >= 25 then
        raise exception 'You can have up to 25 games here. Delete one first.';
      end if;
    else
      new.owner := old.owner;
      if public.gc_is_admin() then
        null;  -- an admin may approve or un-approve
      else
        new.approved := old.approved;
        if new.code is distinct from old.code or new.title is distinct from old.title then new.approved := false; end if;
      end if;
    end if;
  end if;
  new.updated_at := now();
  return new;
end $$;
drop trigger if exists gc_games_guard_t on public.gc_games;
create trigger gc_games_guard_t before insert or update on public.gc_games for each row execute function public.gc_games_guard();

grant select on public.gc_games to anon, authenticated;
grant insert, update, delete on public.gc_games to authenticated;

-- Blockvile Publisher: what kind of thing it is (a game in the Game Center, a page in the Blockvile Browser, or an app / extension)
alter table public.gc_games add column if not exists kind text not null default 'game';
alter table public.gc_games drop constraint if exists gc_games_kind_check;
alter table public.gc_games add constraint gc_games_kind_check check (kind in ('game','page','app'));
create index if not exists gc_games_kind_idx on public.gc_games (kind, created_at desc);

-- Make YOUR account an admin (change the email if you log in to Blockvile with a different one), then run again.
insert into public.gc_admins (user_id) select id from auth.users where email = 'ethanabraham09092014@gmail.com' on conflict do nothing;
