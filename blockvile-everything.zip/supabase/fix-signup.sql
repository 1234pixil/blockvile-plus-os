-- FIX for "Database error saving new user": makes the two sign-up helpers unable to block a new account.
-- Run once in Supabase -> SQL Editor -> paste all -> Run. Safe to run again.

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  begin
    insert into public.profiles (id, display_name)
    values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)))
    on conflict do nothing;
  exception when others then null;   -- never stop someone signing up
  end;
  return new;
end $$;

create or replace function public.bv_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  begin
    insert into public.bv_profiles (id, email) values (new.id, new.email) on conflict (id) do nothing;
  exception when others then null;   -- never stop someone signing up
  end;
  return new;
end $$;

-- make sure the sign-up triggers point at these functions (only if the tables exist)
do $$ begin
  if to_regclass('public.profiles') is not null then
    drop trigger if exists on_auth_user_created on auth.users;
    create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();
  end if;
  if to_regclass('public.bv_profiles') is not null then
    drop trigger if exists bv_new_user_t on auth.users;
    create trigger bv_new_user_t after insert on auth.users for each row execute function public.bv_new_user();
  end if;
end $$;

-- show anything else attached to sign-ups (for debugging: you should only see the two above)
select tgname as trigger_on_new_users from pg_trigger where tgrelid = 'auth.users'::regclass and not tgisinternal;
