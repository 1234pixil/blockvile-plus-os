-- ============================================================
-- Feedback file uploads + Debug Center reports  (run once in Supabase → SQL Editor)
-- ============================================================
alter table public.feedback add column if not exists files jsonb;          -- paths of uploaded files

-- Private storage bucket for feedback attachments: anyone can UPLOAD (max 5 MB, pictures/text/json/pdf only); nobody can read through the app.
-- You open the files in Supabase → Storage → feedback-files.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('feedback-files', 'feedback-files', false, 5242880,
        array['image/png','image/jpeg','image/webp','image/gif','text/plain','application/json','application/pdf'])
on conflict (id) do update set public = false, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;
drop policy if exists "anyone can upload feedback files" on storage.objects;
create policy "anyone can upload feedback files" on storage.objects for insert to anon, authenticated with check (bucket_id = 'feedback-files');

-- Errors sent from the Debug Center ("Send to developer", or automatic sharing if the person turned it on).
-- Anyone can send; nobody can read through the app. You read them in Supabase → Table Editor → debug_reports.
create table if not exists public.debug_reports (
  id bigint generated always as identity primary key,
  created_at timestamptz not null default now(),
  happened_at timestamptz,
  app_version text check (char_length(app_version) <= 20),
  device text check (char_length(device) <= 200),
  kind text not null check (char_length(kind) <= 20),
  source text check (char_length(source) <= 80),
  message text not null check (char_length(message) <= 600),
  stack text check (char_length(stack) <= 1500),
  page text check (char_length(page) <= 200)
);
alter table public.debug_reports enable row level security;
drop policy if exists "anyone can send debug reports" on public.debug_reports;
create policy "anyone can send debug reports" on public.debug_reports for insert to anon, authenticated with check (true);
revoke all on public.debug_reports from anon, authenticated;
grant insert on public.debug_reports to anon, authenticated;
