-- Blockvile: user profiles (active / suspended), Orbs, Shop, Quests, Friends, Blockvile Plus.
-- Safe to run more than once. Run AFTER game-center.sql:  Supabase -> SQL Editor -> paste all -> Run.
--
-- HOW YOU MANAGE PEOPLE (Table Editor -> bv_profiles):
--   status      "active" (default) or "suspended"  -> a suspended person is signed out, can't publish, earn, spend or add friends
--   suspended_reason  (optional note, shown to them)
--   plus        true = Blockvile Plus member (2x quest orbs, Plus-only avatars). plus_until = optional end date.
--   orbs        their balance. Change it to give or take Orbs.
--   role        free text for you ("tester", "friend", ...)
--   notes       private notes for you
-- Shop items live in bv_shop_items and quests in bv_quests: add/edit rows there any time and the apps show them.

-- ---------- profiles ----------
create table if not exists public.bv_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  username text unique check (username is null or username ~ '^[a-z0-9_]{3,20}$'),
  status text not null default 'active' check (status in ('active','suspended')),
  suspended_reason text,
  plus boolean not null default false,
  plus_until timestamptz,
  orbs integer not null default 0 check (orbs >= 0),
  total_orbs_earned integer not null default 0,
  avatar text not null default '🙂',
  owned jsonb not null default '["a-smile"]'::jsonb,
  role text,
  notes text,
  last_seen timestamptz,
  created_at timestamptz not null default now()
);
alter table public.bv_profiles enable row level security;
drop policy if exists bv_profiles_read on public.bv_profiles;
create policy bv_profiles_read on public.bv_profiles for select to authenticated using (id = auth.uid());
grant select on public.bv_profiles to authenticated;   -- people can only READ their own row; every change goes through the functions below

create or replace function public.bv_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.bv_profiles (id, email) values (new.id, new.email) on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists bv_new_user_t on auth.users;
create trigger bv_new_user_t after insert on auth.users for each row execute function public.bv_new_user();
insert into public.bv_profiles (id, email) select id, email from auth.users on conflict (id) do nothing;   -- everyone who already signed up

create or replace function public.bv_active() returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select status = 'active' from public.bv_profiles where id = auth.uid()), true)
$$;
create or replace function public.bv_is_plus() returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select plus and (plus_until is null or plus_until > now()) from public.bv_profiles where id = auth.uid()), false)
$$;
grant execute on function public.bv_active(), public.bv_is_plus() to authenticated;

-- suspended people cannot publish
create or replace function public.gc_active_guard() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.bv_active() and not public.gc_is_admin() then raise exception 'Your account is suspended.'; end if;
  return new;
end $$;
drop trigger if exists gc_active_t on public.gc_games;
create trigger gc_active_t before insert or update on public.gc_games for each row execute function public.gc_active_guard();

-- my profile (also marks me as seen). Returns what the apps need.
create or replace function public.bv_me() returns jsonb language plpgsql security definer set search_path = public as $$
declare p public.bv_profiles;
begin
  if auth.uid() is null then return null; end if;
  insert into public.bv_profiles (id, email) select id, email from auth.users where id = auth.uid() on conflict (id) do nothing;
  update public.bv_profiles set last_seen = now() where id = auth.uid() returning * into p;
  return jsonb_build_object('id', p.id, 'username', p.username, 'status', p.status, 'reason', p.suspended_reason, 'plus', (p.plus and (p.plus_until is null or p.plus_until > now())),
    'orbs', p.orbs, 'avatar', p.avatar, 'owned', p.owned);
end $$;
grant execute on function public.bv_me() to authenticated;

create or replace function public.bv_set_username(u text) returns text language plpgsql security definer set search_path = public as $$
begin
  if not public.bv_active() then return 'suspended'; end if;
  u := lower(trim(u));
  if u !~ '^[a-z0-9_]{3,20}$' then return 'Use 3 to 20 letters, numbers or _'; end if;
  begin update public.bv_profiles set username = u where id = auth.uid();
  exception when unique_violation then return 'That name is taken'; end;
  return 'ok';
end $$;
grant execute on function public.bv_set_username(text) to authenticated;

-- ---------- shop ----------
create table if not exists public.bv_shop_items (
  id text primary key, kind text not null default 'avatar' check (kind in ('avatar')),
  name text not null, emoji text not null, price integer not null default 0 check (price >= 0),
  plus_only boolean not null default false, active boolean not null default true, sort integer not null default 100
);
alter table public.bv_shop_items enable row level security;
drop policy if exists bv_shop_read on public.bv_shop_items;
create policy bv_shop_read on public.bv_shop_items for select using (active);
grant select on public.bv_shop_items to anon, authenticated;
insert into public.bv_shop_items (id, name, emoji, price, plus_only, sort) values
 ('a-smile','Smiley','🙂',0,false,1),('a-cool','Cool','😎',40,false,2),('a-cat','Cat','🐱',60,false,3),('a-dog','Dog','🐶',60,false,4),
 ('a-frog','Frog','🐸',80,false,5),('a-robot','Robot','🤖',100,false,6),('a-alien','Alien','👽',120,false,7),('a-ghost','Ghost','👻',120,false,8),
 ('a-fox','Fox','🦊',150,false,9),('a-panda','Panda','🐼',150,false,10),('a-unicorn','Unicorn','🦄',250,false,11),('a-dragon','Dragon','🐉',300,false,12),
 ('a-rocket','Rocket','🚀',200,false,13),('a-crown','Crown','👑',500,false,14),
 ('p-star','Plus Star','🌟',0,true,20),('p-diamond','Plus Diamond','💎',0,true,21),('p-phoenix','Plus Phoenix','🔥',0,true,22)
on conflict (id) do nothing;

create or replace function public.bv_buy(item text) returns text language plpgsql security definer set search_path = public as $$
declare it public.bv_shop_items; p public.bv_profiles;
begin
  if auth.uid() is null then return 'Sign in first'; end if;
  if not public.bv_active() then return 'suspended'; end if;
  select * into it from public.bv_shop_items where id = item and active;
  if not found then return 'That item is not for sale'; end if;
  select * into p from public.bv_profiles where id = auth.uid() for update;
  if p.owned ? item then return 'You already own it'; end if;
  if it.plus_only and not public.bv_is_plus() then return 'Only for Blockvile Plus members'; end if;
  if p.orbs < it.price then return 'Not enough Orbs'; end if;
  update public.bv_profiles set orbs = orbs - it.price, owned = owned || to_jsonb(item) where id = auth.uid();
  return 'ok';
end $$;
create or replace function public.bv_equip(item text) returns text language plpgsql security definer set search_path = public as $$
declare e text;
begin
  if not public.bv_active() then return 'suspended'; end if;
  select emoji into e from public.bv_shop_items where id = item;
  if e is null then return 'Unknown item'; end if;
  if not exists (select 1 from public.bv_profiles where id = auth.uid() and owned ? item) then return 'You do not own it'; end if;
  update public.bv_profiles set avatar = e where id = auth.uid(); return 'ok';
end $$;
grant execute on function public.bv_buy(text), public.bv_equip(text) to authenticated;

-- ---------- quests ----------
create table if not exists public.bv_quests (
  id text primary key, title text not null, description text not null default '',
  kind text not null default 'play' check (kind in ('play','friends')),   -- play = play a Blockvile Game Center game; friends = play together with a friend
  game_id text,                      -- Game Center id (see games-catalog.js). Empty = any game
  minutes integer not null default 10 check (minutes between 1 and 240),
  reward integer not null default 10 check (reward between 1 and 1000),
  icon text not null default '🎯', active boolean not null default true, sort integer not null default 100
);
alter table public.bv_quests enable row level security;
drop policy if exists bv_quests_read on public.bv_quests;
create policy bv_quests_read on public.bv_quests for select using (active);
grant select on public.bv_quests to anon, authenticated;
insert into public.bv_quests (id, title, description, kind, game_id, minutes, reward, icon, sort) values
 ('q-any15','Warm up','Play any Blockvile game for 15 minutes','play',null,15,15,'🎮',1),
 ('q-bedwars','Bed Wars fan','Play Bed Wars for 10 minutes','play','bedwars',10,25,'🛏️',2),
 ('q-skybed','Sky high','Play Sky Bed Wars for 10 minutes','play','skybedwars',10,25,'☁️',3),
 ('q-obby','Obby runner','Play Obby for 8 minutes','play','obby',8,20,'🏃',4),
 ('q-snake','Snake charmer','Play Snake Blocks for 5 minutes','play','snake',5,10,'🐍',5),
 ('q-defense','Defender','Play Tower Defense for 10 minutes','play','defense',10,20,'🏰',6),
 ('q-friends','Better together','Play a game with a friend (send an invite they join)','friends',null,1,30,'🤝',7)
on conflict (id) do nothing;

create table if not exists public.bv_quest_progress (
  user_id uuid not null references auth.users(id) on delete cascade, quest_id text not null references public.bv_quests(id) on delete cascade,
  day date not null default current_date, seconds integer not null default 0, claimed boolean not null default false, last_tick timestamptz,
  primary key (user_id, quest_id, day)
);
alter table public.bv_quest_progress enable row level security;
drop policy if exists bv_qp_read on public.bv_quest_progress;
create policy bv_qp_read on public.bv_quest_progress for select to authenticated using (user_id = auth.uid());
grant select on public.bv_quest_progress to authenticated;

-- the app reports play time (at most real elapsed time counts, so it can't be sped up)
create or replace function public.bv_quest_tick(game text, secs integer) returns void language plpgsql security definer set search_path = public as $$
declare q record; pr public.bv_quest_progress; add integer;
begin
  if auth.uid() is null or not public.bv_active() then return; end if;
  for q in select * from public.bv_quests where active and kind = 'play' and (game_id is null or game_id = game) loop
    insert into public.bv_quest_progress (user_id, quest_id) values (auth.uid(), q.id) on conflict do nothing;
    select * into pr from public.bv_quest_progress where user_id = auth.uid() and quest_id = q.id and day = current_date for update;
    add := least(greatest(secs, 0), 70);
    if pr.last_tick is not null then add := least(add, greatest(0, extract(epoch from (now() - pr.last_tick))::integer + 3)); end if;
    update public.bv_quest_progress set seconds = least(seconds + add, q.minutes * 60 + 120), last_tick = now() where user_id = auth.uid() and quest_id = q.id and day = current_date;
  end loop;
end $$;

create or replace function public.bv_quest_claim(qid text) returns text language plpgsql security definer set search_path = public as $$
declare q public.bv_quests; pr public.bv_quest_progress; r integer;
begin
  if auth.uid() is null then return 'Sign in first'; end if;
  if not public.bv_active() then return 'suspended'; end if;
  select * into q from public.bv_quests where id = qid and active;
  if not found then return 'Unknown quest'; end if;
  insert into public.bv_quest_progress (user_id, quest_id) values (auth.uid(), qid) on conflict do nothing;
  select * into pr from public.bv_quest_progress where user_id = auth.uid() and quest_id = qid and day = current_date for update;
  if pr.claimed then return 'You already claimed this today'; end if;
  if q.kind = 'play' and pr.seconds < q.minutes * 60 then return 'Keep playing, not finished yet'; end if;
  if q.kind = 'friends' and not exists (select 1 from public.bv_invites where from_user = auth.uid() and status = 'joined' and created_at::date = current_date) then return 'Invite a friend and have them join first'; end if;
  r := q.reward * case when public.bv_is_plus() then 2 else 1 end;
  update public.bv_quest_progress set claimed = true where user_id = auth.uid() and quest_id = qid and day = current_date;
  update public.bv_profiles set orbs = orbs + r, total_orbs_earned = total_orbs_earned + r where id = auth.uid();
  return 'ok:' || r;
end $$;
grant execute on function public.bv_quest_tick(text, integer), public.bv_quest_claim(text) to authenticated;

-- ---------- watch to earn (ads) ----------
-- 6 times a day, at least 45 seconds apart. The app only offers it once ads are switched on (config.js -> ads).
create table if not exists public.bv_ad_log (id bigserial primary key, user_id uuid not null references auth.users(id) on delete cascade, at timestamptz not null default now());
alter table public.bv_ad_log enable row level security;
create or replace function public.bv_ad_claim() returns text language plpgsql security definer set search_path = public as $$
declare n integer; last timestamptz; r integer;
begin
  if auth.uid() is null then return 'Sign in first'; end if;
  if not public.bv_active() then return 'suspended'; end if;
  select count(*), max(at) into n, last from public.bv_ad_log where user_id = auth.uid() and at::date = current_date;
  if n >= 6 then return 'You have watched the most for today. Come back tomorrow.'; end if;
  if last is not null and now() - last < interval '45 seconds' then return 'Too fast. Wait a moment.'; end if;
  insert into public.bv_ad_log (user_id) values (auth.uid());
  r := 5 * case when public.bv_is_plus() then 2 else 1 end;
  update public.bv_profiles set orbs = orbs + r, total_orbs_earned = total_orbs_earned + r where id = auth.uid();
  return 'ok:' || r;
end $$;
grant execute on function public.bv_ad_claim() to authenticated;

-- ---------- friends + play together ----------
create table if not exists public.bv_friends (
  id bigserial primary key, a uuid not null references auth.users(id) on delete cascade, b uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted')), created_at timestamptz not null default now(), unique (a, b), check (a <> b)
);
alter table public.bv_friends enable row level security;
drop policy if exists bv_friends_read on public.bv_friends;
create policy bv_friends_read on public.bv_friends for select to authenticated using (a = auth.uid() or b = auth.uid());
grant select on public.bv_friends to authenticated;

create table if not exists public.bv_invites (
  id bigserial primary key, from_user uuid not null references auth.users(id) on delete cascade, to_user uuid not null references auth.users(id) on delete cascade,
  game_id text not null, status text not null default 'sent' check (status in ('sent','joined','declined')), created_at timestamptz not null default now()
);
alter table public.bv_invites enable row level security;
drop policy if exists bv_invites_read on public.bv_invites;
create policy bv_invites_read on public.bv_invites for select to authenticated using (from_user = auth.uid() or to_user = auth.uid());
grant select on public.bv_invites to authenticated;

-- names for my friends (people can only see usernames/avatars of their own friends)
create or replace function public.bv_friend_list() returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('rel', f.id, 'status', f.status, 'incoming', f.b = auth.uid(), 'uid', p.id, 'username', p.username, 'avatar', p.avatar,
    'online', coalesce(p.last_seen > now() - interval '3 minutes', false)) order by f.created_at desc), '[]'::jsonb)
  from public.bv_friends f join public.bv_profiles p on p.id = case when f.a = auth.uid() then f.b else f.a end
  where (f.a = auth.uid() or f.b = auth.uid()) and p.status = 'active'
$$;
create or replace function public.bv_friend_request(u text) returns text language plpgsql security definer set search_path = public as $$
declare t uuid;
begin
  if auth.uid() is null then return 'Sign in first'; end if;
  if not public.bv_active() then return 'suspended'; end if;
  if not exists (select 1 from public.bv_profiles where id = auth.uid() and username is not null) then return 'Choose your own username first'; end if;
  select id into t from public.bv_profiles where username = lower(trim(u)) and status = 'active';
  if t is null then return 'No one has that username'; end if;
  if t = auth.uid() then return 'That is you'; end if;
  if exists (select 1 from public.bv_friends where (a = auth.uid() and b = t) or (a = t and b = auth.uid())) then return 'Already friends or waiting'; end if;
  if (select count(*) from public.bv_friends where a = auth.uid() and status = 'pending') >= 20 then return 'Too many waiting requests'; end if;
  insert into public.bv_friends (a, b) values (auth.uid(), t); return 'ok';
end $$;
create or replace function public.bv_friend_respond(rel bigint, accept boolean) returns text language plpgsql security definer set search_path = public as $$
begin
  if not public.bv_active() then return 'suspended'; end if;
  if accept then update public.bv_friends set status = 'accepted' where id = rel and b = auth.uid();
  else delete from public.bv_friends where id = rel and (a = auth.uid() or b = auth.uid()); end if;
  return 'ok';
end $$;
create or replace function public.bv_invite(friend uuid, game text) returns text language plpgsql security definer set search_path = public as $$
begin
  if not public.bv_active() then return 'suspended'; end if;
  if not exists (select 1 from public.bv_friends where status = 'accepted' and ((a = auth.uid() and b = friend) or (a = friend and b = auth.uid()))) then return 'You are not friends yet'; end if;
  if (select count(*) from public.bv_invites where from_user = auth.uid() and created_at > now() - interval '1 hour') >= 20 then return 'Slow down a little'; end if;
  insert into public.bv_invites (from_user, to_user, game_id) values (auth.uid(), friend, left(game, 40)); return 'ok';
end $$;
create or replace function public.bv_invites_in() returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('id', i.id, 'game', i.game_id, 'from', p.username, 'avatar', p.avatar) order by i.created_at desc), '[]'::jsonb)
  from public.bv_invites i join public.bv_profiles p on p.id = i.from_user
  where i.to_user = auth.uid() and i.status = 'sent' and i.created_at > now() - interval '30 minutes'
$$;
create or replace function public.bv_invite_respond(inv bigint, join_it boolean) returns text language plpgsql security definer set search_path = public as $$
begin
  if not public.bv_active() then return 'suspended'; end if;
  update public.bv_invites set status = case when join_it then 'joined' else 'declined' end where id = inv and to_user = auth.uid() and status = 'sent';
  return 'ok';
end $$;
create or replace function public.bv_unfriend(rel bigint) returns void language sql security definer set search_path = public as $$
  delete from public.bv_friends where id = rel and (a = auth.uid() or b = auth.uid())
$$;
grant execute on function public.bv_friend_list(), public.bv_friend_request(text), public.bv_friend_respond(bigint, boolean), public.bv_invite(uuid, text), public.bv_invites_in(), public.bv_invite_respond(bigint, boolean), public.bv_unfriend(bigint) to authenticated;
