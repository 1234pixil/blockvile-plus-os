-- Blockvile: user profiles (active / suspended), Orbs, Shop, Quests, Friends, Blockvile Plus.
-- Safe to run more than once. Run AFTER game-center.sql:  Supabase -> SQL Editor -> paste all -> Run.
--
-- HOW YOU MANAGE PEOPLE (Table Editor -> bv_profiles):
--   status      "active" (default) or "suspended"  -> a suspended person is signed out, can't publish, earn, spend or add friends
--   suspended_reason  (optional note, shown to them)
--   plus        true = Blockvile Plus member (2x quest orbs, Plus-only avatars). plus_until = optional end date.
--   orbs        their balance. Change it to give or take Orbs.
--   role        free text for you ("tester", "friend", ...)
--   notes       private notes for you
-- Shop items live in bv_shop_items and quests in bv_quests: add/edit rows there any time and the apps show them.

-- ---------- profiles ----------
create table if not exists public.bv_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  username text unique check (username is null or username ~ '^[a-z0-9_]{3,20}$'),
  status text not null default 'active' check (status in ('active','suspended')),
  suspended_reason text,
  plus boolean not null default false,
  plus_until timestamptz,
  orbs integer not null default 0 check (orbs >= 0),
  total_orbs_earned integer not null default 0,
  avatar text not null default '🙂',
  owned jsonb not null default '["a-smile"]'::jsonb,
  role text,
  notes text,
  last_seen timestamptz,
  created_at timestamptz not null default now()
);
alter table public.bv_profiles enable row level security;
drop policy if exists bv_profiles_read on public.bv_profiles;
create policy bv_profiles_read on public.bv_profiles for select to authenticated using (id = auth.uid());
grant select on public.bv_profiles to authenticated;   -- people can only READ their own row; every change goes through the functions below

create or replace function public.bv_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.bv_profiles (id, email) values (new.id, new.email) on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists bv_new_user_t on auth.users;
create trigger bv_new_user_t after insert on auth.users for each row execute function public.bv_new_user();
insert into public.bv_profiles (id, email) select id, email from auth.users on conflict (id) do nothing;   -- everyone who already signed up

create or replace function public.bv_active() returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select status = 'active' from public.bv_profiles where id = auth.uid()), true)
$$;
create or replace function public.bv_is_plus() returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select plus and (plus_until is null or plus_until > now()) from public.bv_profiles where id = auth.uid()), false)
$$;
grant execute on function public.bv_active(), public.bv_is_plus() to authenticated;

-- suspended people cannot publish
create or replace function public.gc_active_guard() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.bv_active() and not public.gc_is_admin() then raise exception 'Your account is suspended.'; end if;
  return new;
end $$;
drop trigger if exists gc_active_t on public.gc_games;
create trigger gc_active_t before insert or update on public.gc_games for each row execute function public.gc_active_guard();

-- my profile (also marks me as seen). Returns what the apps need.
create or replace function public.bv_me() returns jsonb language plpgsql security definer set search_path = public as $$
declare p public.bv_profiles;
begin
  if auth.uid() is null then return null; end if;
  insert into public.bv_profiles (id, email) select id, email from auth.users where id = auth.uid() on conflict (id) do nothing;
  update public.bv_profiles set last_seen = now() where id = auth.uid() returning * into p;
  return jsonb_build_object('id', p.id, 'username', p.username, 'status', p.status, 'reason', p.suspended_reason, 'plus', (p.plus and (p.plus_until is null or p.plus_until > now())),
    'orbs', p.orbs, 'avatar', p.avatar, 'owned', p.owned);
end $$;
grant execute on function public.bv_me() to authenticated;

create or replace function public.bv_set_username(u text) returns text language plpgsql security definer set search_path = public as $$
begin
  if not public.bv_active() then return 'suspended'; end if;
  u := lower(trim(u));
  if u !~ '^[a-z0-9_]{3,20}$' then return 'Use 3 to 20 letters, numbers or _'; end if;
  begin update public.bv_profiles set username = u where id = auth.uid();
  exception when unique_violation then return 'That name is taken'; end;
  return 'ok';
end $$;
grant execute on function public.bv_set_username(text) to authenticated;

-- ---------- shop ----------
create table if not exists public.bv_shop_items (
  id text primary key, kind text not null default 'avatar' check (kind in ('avatar')),
  name text not null, emoji text not null, price integer not null default 0 check (price >= 0),
  plus_only boolean not null default false, active boolean not null default true, sort integer not null default 100
);
alter table public.bv_shop_items enable row level security;
drop policy if exists bv_shop_read on public.bv_shop_items;
create policy bv_shop_read on public.bv_shop_items for select using (active);
grant select on public.bv_shop_items to anon, authenticated;
insert into public.bv_shop_items (id, name, emoji, price, plus_only, sort) values
 ('a-smile','Smiley','🙂',0,false,1),('a-cool','Cool','😎',40,false,2),('a-cat','Cat','🐱',60,false,3),('a-dog','Dog','🐶',60,false,4),
 ('a-frog','Frog','🐸',80,false,5),('a-robot','Robot','🤖',100,false,6),('a-alien','Alien','👽',120,false,7),('a-ghost','Ghost','👻',120,false,8),
 ('a-fox','Fox','🦊',150,false,9),('a-panda','Panda','🐼',150,false,10),('a-unicorn','Unicorn','🦄',250,false,11),('a-dragon','Dragon','🐉',300,false,12),
 ('a-rocket','Rocket','🚀',200,false,13),('a-crown','Crown','👑',500,false,14),
 ('p-star','Plus Star','🌟',0,true,20),('p-diamond','Plus Diamond','💎',0,true,21),('p-phoenix','Plus Phoenix','🔥',0,true,22)
on conflict (id) do nothing;

create or replace function public.bv_buy(item text) returns text language plpgsql security definer set search_path = public as $$
declare it public.bv_shop_items; p public.bv_profiles;
begin
  if auth.uid() is null then return 'Sign in first'; end if;
  if not public.bv_active() then return 'suspended'; end if;
  select * into it from public.bv_shop_items where id = item and active;
  if not found then return 'That item is not for sale'; end if;
  select * into p from public.bv_profiles where id = auth.uid() for update;
  if p.owned ? item then return 'You already own it'; end if;
  if it.plus_only and not public.bv_is_plus() then return 'Only for Blockvile Plus members'; end if;
  if p.orbs < it.price then return 'Not enough Orbs'; end if;
  update public.bv_profiles set orbs = orbs - it.price, owned = owned || to_jsonb(item) where id = auth.uid();
  return 'ok';
end $$;
create or replace function public.bv_equip(item text) returns text language plpgsql security definer set search_path = public as $$
declare e text;
begin
  if not public.bv_active() then return 'suspended'; end if;
  select emoji into e from public.bv_shop_items where id = item;
  if e is null then return 'Unknown item'; end if;
  if not exists (select 1 from public.bv_profiles where id = auth.uid() and owned ? item) then return 'You do not own it'; end if;
  update public.bv_profiles set avatar = e where id = auth.uid(); return 'ok';
end $$;
grant execute on function public.bv_buy(text), public.bv_equip(text) to authenticated;

-- ---------- quests ----------
create table if not exists public.bv_quests (
  id text primary key, title text not null, description text not null default '',
  kind text not null default 'play' check (kind in ('play','friends')),   -- play = play a Blockvile Game Center game; friends = play together with a friend
  game_id text,                      -- Game Center id (see games-catalog.js). Empty = any game
  minutes integer not null default 10 check (minutes between 1 and 240),
  reward integer not null default 10 check (reward between 1 and 1000),
  icon text not null default '🎯', active boolean not null default true, sort integer not null default 100
);
alter table public.bv_quests enable row level security;
drop policy if exists bv_quests_read on public.bv_quests;
create policy bv_quests_read on public.bv_quests for select using (active);
grant select on public.bv_quests to anon, authenticated;
insert into public.bv_quests (id, title, description, kind, game_id, minutes, reward, icon, sort) values
 ('q-any15','Warm up','Play any Blockvile game for 15 minutes','play',null,15,15,'🎮',1),
 ('q-bedwars','Bed Wars fan','Play Bed Wars for 10 minutes','play','bedwars',10,25,'🛏️',2),
 ('q-skybed','Sky high','Play Sky Bed Wars for 10 minutes','play','skybedwars',10,25,'☁️',3),
 ('q-obby','Obby runner','Play Obby for 8 minutes','play','obby',8,20,'🏃',4),
 ('q-snake','Snake charmer','Play Snake Blocks for 5 minutes','play','snake',5,10,'🐍',5),
 ('q-defense','Defender','Play Tower Defense for 10 minutes','play','defense',10,20,'🏰',6),
 ('q-friends','Better together','Play a game with a friend (send an invite they join)','friends',null,1,30,'🤝',7)
on conflict (id) do nothing;

create table if not exists public.bv_quest_progress (
  user_id uuid not null references auth.users(id) on delete cascade, quest_id text not null references public.bv_quests(id) on delete cascade,
  day date not null default current_date, seconds integer not null default 0, claimed boolean not null default false, last_tick timestamptz,
  primary key (user_id, quest_id, day)
);
alter table public.bv_quest_progress enable row level security;
drop policy if exists bv_qp_read on public.bv_quest_progress;
create policy bv_qp_read on public.bv_quest_progress for select to authenticated using (user_id = auth.uid());
grant select on public.bv_quest_progress to authenticated;

-- the app reports play time (at most real elapsed time counts, so it can't be sped up)
create or replace function public.bv_quest_tick(game text, secs integer) returns void language plpgsql security definer set search_path = public as $$
declare q record; pr public.bv_quest_progress; add integer;
begin
  if auth.uid() is null or not public.bv_active() then return; end if;
  for q in select * from public.bv_quests where active and kind = 'play' and (game_id is null or game_id = game) loop
    insert into public.bv_quest_progress (user_id, quest_id) values (auth.uid(), q.id) on conflict do nothing;
    select * into pr from public.bv_quest_progress where user_id = auth.uid() and quest_id = q.id and day = current_date for update;
    add := least(greatest(secs, 0), 70);
    if pr.last_tick is not null then add := least(add, greatest(0, extract(epoch from (now() - pr.last_tick))::integer + 3)); end if;
    update public.bv_quest_progress set seconds = least(seconds + add, q.minutes * 60 + 120), last_tick = now() where user_id = auth.uid() and quest_id = q.id and day = current_date;
  end loop;
end $$;

create or replace function public.bv_quest_claim(qid text) returns text language plpgsql security definer set search_path = public as $$
declare q public.bv_quests; pr public.bv_quest_progress; r integer;
begin
  if auth.uid() is null then return 'Sign in first'; end if;
  if not public.bv_active() then return 'suspended'; end if;
  select * into q from public.bv_quests where id = qid and active;
  if not found then return 'Unknown quest'; end if;
  insert into public.bv_quest_progress (user_id, quest_id) values (auth.uid(), qid) on conflict do nothing;
  select * into pr from public.bv_quest_progress where user_id = auth.uid() and quest_id = qid and day = current_date for update;
  if pr.claimed then return 'You already claimed this today'; end if;
  if q.kind = 'play' and pr.seconds < q.minutes * 60 then return 'Keep playing, not finished yet'; end if;
  if q.kind = 'friends' and not exists (select 1 from public.bv_invites where from_user = auth.uid() and status = 'joined' and created_at::date = current_date) then return 'Invite a friend and have them join first'; end if;
  r := q.reward * case when public.bv_is_plus() then 2 else 1 end;
  update public.bv_quest_progress set claimed = true where user_id = auth.uid() and quest_id = qid and day = current_date;
  update public.bv_profiles set orbs = orbs + r, total_orbs_earned = total_orbs_earned + r where id = auth.uid();
  return 'ok:' || r;
end $$;
grant execute on function public.bv_quest_tick(text, integer), public.bv_quest_claim(text) to authenticated;

-- ---------- watch to earn (ads) ----------
-- 6 times a day, at least 45 seconds apart. The app only offers it once ads are switched on (config.js -> ads).
create table if not exists public.bv_ad_log (id bigserial primary key, user_id uuid not null references auth.users(id) on delete cascade, at timestamptz not null default now());
alter table public.bv_ad_log enable row level security;
create or replace function public.bv_ad_claim() returns text language plpgsql security definer set search_path = public as $$
declare n integer; last timestamptz; r integer;
begin
  if auth.uid() is null then return 'Sign in first'; end if;
  if not public.bv_active() then return 'suspended'; end if;
  select count(*), max(at) into n, last from public.bv_ad_log where user_id = auth.uid() and at::date = current_date;
  if n >= 6 then return 'You have watched the most for today. Come back tomorrow.'; end if;
  if last is not null and now() - last < interval '45 seconds' then return 'Too fast. Wait a moment.'; end if;
  insert into public.bv_ad_log (user_id) values (auth.uid());
  r := 5 * case when public.bv_is_plus() then 2 else 1 end;
  update public.bv_profiles set orbs = orbs + r, total_orbs_earned = total_orbs_earned + r where id = auth.uid();
  return 'ok:' || r;
end $$;
grant execute on function public.bv_ad_claim() to authenticated;

-- ---------- friends + play together ----------
create table if not exists public.bv_friends (
  id bigserial primary key, a uuid not null references auth.users(id) on delete cascade, b uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted')), created_at timestamptz not null default now(), unique (a, b), check (a <> b)
);
alter table public.bv_friends enable row level security;
drop policy if exists bv_friends_read on public.bv_friends;
create policy bv_friends_read on public.bv_friends for select to authenticated using (a = auth.uid() or b = auth.uid());
grant select on public.bv_friends to authenticated;

create table if not exists public.bv_invites (
  id bigserial primary key, from_user uuid not null references auth.users(id) on delete cascade, to_user uuid not null references auth.users(id) on delete cascade,
  game_id text not null, status text not null default 'sent' check (status in ('sent','joined','declined')), created_at timestamptz not null default now()
);
alter table public.bv_invites enable row level security;
drop policy if exists bv_invites_read on public.bv_invites;
create policy bv_invites_read on public.bv_invites for select to authenticated using (from_user = auth.uid() or to_user = auth.uid());
grant select on public.bv_invites to authenticated;

-- names for my friends (people can only see usernames/avatars of their own friends)
create or replace function public.bv_friend_list() returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('rel', f.id, 'status', f.status, 'incoming', f.b = auth.uid(), 'uid', p.id, 'username', p.username, 'avatar', p.avatar,
    'online', coalesce(p.last_seen > now() - interval '3 minutes', false)) order by f.created_at desc), '[]'::jsonb)
  from public.bv_friends f join public.bv_profiles p on p.id = case when f.a = auth.uid() then f.b else f.a end
  where (f.a = auth.uid() or f.b = auth.uid()) and p.status = 'active'
$$;
create or replace function public.bv_friend_request(u text) returns text language plpgsql security definer set search_path = public as $$
declare t uuid;
begin
  if auth.uid() is null then return 'Sign in first'; end if;
  if not public.bv_active() then return 'suspended'; end if;
  if not exists (select 1 from public.bv_profiles where id = auth.uid() and username is not null) then return 'Choose your own username first'; end if;
  select id into t from public.bv_profiles where username = lower(trim(u)) and status = 'active';
  if t is null then return 'No one has that username'; end if;
  if t = auth.uid() then return 'That is you'; end if;
  if exists (select 1 from public.bv_friends where (a = auth.uid() and b = t) or (a = t and b = auth.uid())) then return 'Already friends or waiting'; end if;
  if (select count(*) from public.bv_friends where a = auth.uid() and status = 'pending') >= 20 then return 'Too many waiting requests'; end if;
  insert into public.bv_friends (a, b) values (auth.uid(), t); return 'ok';
end $$;
create or replace function public.bv_friend_respond(rel bigint, accept boolean) returns text language plpgsql security definer set search_path = public as $$
begin
  if not public.bv_active() then return 'suspended'; end if;
  if accept then update public.bv_friends set status = 'accepted' where id = rel and b = auth.uid();
  else delete from public.bv_friends where id = rel and (a = auth.uid() or b = auth.uid()); end if;
  return 'ok';
end $$;
create or replace function public.bv_invite(friend uuid, game text) returns text language plpgsql security definer set search_path = public as $$
begin
  if not public.bv_active() then return 'suspended'; end if;
  if not exists (select 1 from public.bv_friends where status = 'accepted' and ((a = auth.uid() and b = friend) or (a = friend and b = auth.uid()))) then return 'You are not friends yet'; end if;
  if (select count(*) from public.bv_invites where from_user = auth.uid() and created_at > now() - interval '1 hour') >= 20 then return 'Slow down a little'; end if;
  insert into public.bv_invites (from_user, to_user, game_id) values (auth.uid(), friend, left(game, 40)); return 'ok';
end $$;
create or replace function public.bv_invites_in() returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('id', i.id, 'game', i.game_id, 'from', p.username, 'avatar', p.avatar) order by i.created_at desc), '[]'::jsonb)
  from public.bv_invites i join public.bv_profiles p on p.id = i.from_user
  where i.to_user = auth.uid() and i.status = 'sent' and i.created_at > now() - interval '30 minutes'
$$;
create or replace function public.bv_invite_respond(inv bigint, join_it boolean) returns text language plpgsql security definer set search_path = public as $$
begin
  if not public.bv_active() then return 'suspended'; end if;
  update public.bv_invites set status = case when join_it then 'joined' else 'declined' end where id = inv and to_user = auth.uid() and status = 'sent';
  return 'ok';
end $$;
create or replace function public.bv_unfriend(rel bigint) returns void language sql security definer set search_path = public as $$
  delete from public.bv_friends where id = rel and (a = auth.uid() or b = auth.uid())
$$;
grant execute on function public.bv_friend_list(), public.bv_friend_request(text), public.bv_friend_respond(bigint, boolean), public.bv_invite(uuid, text), public.bv_invites_in(), public.bv_invite_respond(bigint, boolean), public.bv_unfriend(bigint) to authenticated;

-- =====================================================================================
-- COSTUMES: Blockvile Plus members upload their own 2D avatars (picture / GIF / custom emoji) and 3D avatars (.glb).
-- Nothing is visible to anyone else until YOU approve it (Table Editor -> bv_creations -> tick "approved",
-- or the Shop app's Review tab). Buyers pay Orbs; the maker gets 70%.
-- SALES: add a row to bv_sales (percent 10-90, starts/ends) and everything in the Shop gets that discount.
-- =====================================================================================
alter table public.bv_profiles add column if not exists avatar_ref uuid;

create table if not exists public.bv_creations (
  id uuid primary key default gen_random_uuid(),
  owner uuid not null references auth.users(id) on delete cascade,
  creator_name text not null default 'player',
  kind text not null check (kind in ('avatar2d','avatar3d')),
  name text not null check (char_length(name) between 2 and 30),
  price integer not null default 0 check (price between 0 and 5000),
  discount_pct integer not null default 0 check (discount_pct between 0 and 90),
  discount_until timestamptz,
  thumb text,                       -- small picture shown in the shop (data URL)
  image text,                       -- 2D avatar picture / GIF (data URL)
  model text,                       -- 3D avatar .glb (data URL)
  approved boolean not null default false,
  active boolean not null default true,
  sales integer not null default 0,
  earned integer not null default 0,
  created_at timestamptz not null default now()
);
alter table public.bv_creations enable row level security;
drop policy if exists bv_creations_read on public.bv_creations;
create policy bv_creations_read on public.bv_creations for select to authenticated using (owner = auth.uid());
grant select (id, owner, creator_name, kind, name, price, discount_pct, discount_until, thumb, approved, active, sales, earned, created_at) on public.bv_creations to authenticated;

create table if not exists public.bv_creation_owned (
  user_id uuid not null references auth.users(id) on delete cascade, creation_id uuid not null references public.bv_creations(id) on delete cascade,
  at timestamptz not null default now(), primary key (user_id, creation_id)
);
alter table public.bv_creation_owned enable row level security;
drop policy if exists bv_co_read on public.bv_creation_owned;
create policy bv_co_read on public.bv_creation_owned for select to authenticated using (user_id = auth.uid());
grant select on public.bv_creation_owned to authenticated;

create table if not exists public.bv_sales (
  id serial primary key, title text not null default 'Sale', percent integer not null check (percent between 1 and 90),
  starts timestamptz not null default now(), ends timestamptz not null default now() + interval '3 days', active boolean not null default true
);
alter table public.bv_sales enable row level security;
drop policy if exists bv_sales_read on public.bv_sales;
create policy bv_sales_read on public.bv_sales for select using (active);
grant select on public.bv_sales to anon, authenticated;

create or replace function public.bv_sale() returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce((select jsonb_build_object('title', title, 'percent', percent, 'ends', ends) from public.bv_sales where active and now() between starts and ends order by percent desc limit 1), 'null'::jsonb)
$$;
create or replace function public.bv_sale_pct() returns integer language sql stable security definer set search_path = public as $$
  select coalesce((select max(percent) from public.bv_sales where active and now() between starts and ends), 0)
$$;
grant execute on function public.bv_sale(), public.bv_sale_pct() to anon, authenticated;

-- the Shop's normal items also follow sales
create or replace function public.bv_buy(item text) returns text language plpgsql security definer set search_path = public as $$
declare it public.bv_shop_items; p public.bv_profiles; cost integer;
begin
  if auth.uid() is null then return 'Sign in first'; end if;
  if not public.bv_active() then return 'suspended'; end if;
  select * into it from public.bv_shop_items where id = item and active;
  if not found then return 'That item is not for sale'; end if;
  select * into p from public.bv_profiles where id = auth.uid() for update;
  if p.owned ? item then return 'You already own it'; end if;
  if it.plus_only and not public.bv_is_plus() then return 'Only for Blockvile Plus members'; end if;
  cost := ceil(it.price * (100 - public.bv_sale_pct()) / 100.0);
  if p.orbs < cost then return 'Not enough Orbs'; end if;
  update public.bv_profiles set orbs = orbs - cost, owned = owned || to_jsonb(item) where id = auth.uid();
  return 'ok';
end $$;
create or replace function public.bv_equip(item text) returns text language plpgsql security definer set search_path = public as $$
declare e text;
begin
  if not public.bv_active() then return 'suspended'; end if;
  select emoji into e from public.bv_shop_items where id = item;
  if e is null then return 'Unknown item'; end if;
  if not exists (select 1 from public.bv_profiles where id = auth.uid() and owned ? item) then return 'You do not own it'; end if;
  update public.bv_profiles set avatar = e, avatar_ref = null where id = auth.uid(); return 'ok';
end $$;

-- what's for sale (approved costumes). Price shown already includes any discount.
create or replace function public.bv_market() returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('id', c.id, 'kind', c.kind, 'name', c.name, 'creator', c.creator_name, 'price', c.price, 'thumb', c.thumb, 'sales', c.sales,
    'pct', greatest(case when c.discount_pct > 0 and (c.discount_until is null or c.discount_until > now()) then c.discount_pct else 0 end, public.bv_sale_pct()),
    'owned', (c.owner = auth.uid() or exists (select 1 from public.bv_creation_owned o where o.creation_id = c.id and o.user_id = auth.uid())),
    'mine', c.owner = auth.uid()) order by c.created_at desc), '[]'::jsonb)
  from (select * from public.bv_creations where approved and active order by created_at desc limit 120) c
$$;

create or replace function public.bv_create(k text, nm text, pr integer, th text, img text, mdl text) returns text language plpgsql security definer set search_path = public as $$
declare uname text;
begin
  if auth.uid() is null then return 'Sign in first'; end if;
  if not public.bv_active() then return 'suspended'; end if;
  if not public.bv_is_plus() then return 'Only Blockvile Plus members can make costumes'; end if;
  if k not in ('avatar2d','avatar3d') then return 'Pick 2D or 3D'; end if;
  if char_length(trim(nm)) < 2 or char_length(trim(nm)) > 30 then return 'Give it a name (2 to 30 letters)'; end if;
  if pr < 0 or pr > 5000 then return 'Price must be 0 to 5000 Orbs'; end if;
  if (select count(*) from public.bv_creations where owner = auth.uid()) >= 20 then return 'You can have up to 20 costumes. Delete one first.'; end if;
  if th is not null and (th !~ '^data:image/(png|jpeg|gif|webp);base64,' or char_length(th) > 60000) then return 'Preview picture is not allowed'; end if;
  if k = 'avatar2d' and (img is null or img !~ '^data:image/(png|jpeg|gif|webp);base64,' or char_length(img) > 400000) then return 'Use a PNG, JPG, GIF or WebP picture under 250 KB'; end if;
  if k = 'avatar3d' and (mdl is null or mdl !~ '^data:(model/gltf-binary|application/octet-stream);base64,' or char_length(mdl) > 4000000) then return 'Use a .glb 3D file under 2.5 MB'; end if;
  select coalesce(username, split_part(email, '@', 1)) into uname from public.bv_profiles where id = auth.uid();
  insert into public.bv_creations (owner, creator_name, kind, name, price, thumb, image, model) values (auth.uid(), left(coalesce(uname, 'player'), 30), k, trim(nm), pr, th, case when k = 'avatar2d' then img end, case when k = 'avatar3d' then mdl end);
  return 'ok';
end $$;
create or replace function public.bv_creation_discount(cid uuid, pct integer, days integer) returns text language plpgsql security definer set search_path = public as $$
begin
  if pct < 0 or pct > 90 then return 'Discount can be 0 to 90 percent'; end if;
  update public.bv_creations set discount_pct = pct, discount_until = case when pct = 0 then null else now() + make_interval(days => least(greatest(days, 1), 30)) end where id = cid and owner = auth.uid();
  return 'ok';
end $$;
create or replace function public.bv_creation_delete(cid uuid) returns void language sql security definer set search_path = public as $$
  update public.bv_profiles set avatar_ref = null where avatar_ref = cid and id = auth.uid();
  delete from public.bv_creations where id = cid and owner = auth.uid()
$$;

create or replace function public.bv_buy_creation(cid uuid) returns text language plpgsql security definer set search_path = public as $$
declare c public.bv_creations; p public.bv_profiles; pct integer; cost integer; pay integer;
begin
  if auth.uid() is null then return 'Sign in first'; end if;
  if not public.bv_active() then return 'suspended'; end if;
  select * into c from public.bv_creations where id = cid and approved and active;
  if not found then return 'That costume is not for sale'; end if;
  if c.owner = auth.uid() then return 'You made this one, it is already yours'; end if;
  if exists (select 1 from public.bv_creation_owned where user_id = auth.uid() and creation_id = cid) then return 'You already own it'; end if;
  select * into p from public.bv_profiles where id = auth.uid() for update;
  pct := greatest(case when c.discount_pct > 0 and (c.discount_until is null or c.discount_until > now()) then c.discount_pct else 0 end, public.bv_sale_pct());
  cost := ceil(c.price * (100 - pct) / 100.0);
  if p.orbs < cost then return 'Not enough Orbs'; end if;
  pay := floor(cost * 0.7);
  update public.bv_profiles set orbs = orbs - cost where id = auth.uid();
  update public.bv_profiles set orbs = orbs + pay, total_orbs_earned = total_orbs_earned + pay where id = c.owner;
  update public.bv_creations set sales = sales + 1, earned = earned + pay where id = cid;
  insert into public.bv_creation_owned (user_id, creation_id) values (auth.uid(), cid);
  return 'ok';
end $$;
-- wear a costume you own (or made)
create or replace function public.bv_equip_creation(cid uuid) returns text language plpgsql security definer set search_path = public as $$
begin
  if not public.bv_active() then return 'suspended'; end if;
  if not exists (select 1 from public.bv_creations c where c.id = cid and c.active and (c.owner = auth.uid() or (c.approved and exists (select 1 from public.bv_creation_owned o where o.creation_id = c.id and o.user_id = auth.uid())))) then return 'You do not own that costume'; end if;
  update public.bv_profiles set avatar_ref = cid where id = auth.uid(); return 'ok';
end $$;
-- the picture / 3D file of a costume you wear, own or made
create or replace function public.bv_creation_data(cid uuid) returns jsonb language plpgsql stable security definer set search_path = public as $$
declare c public.bv_creations;
begin
  select * into c from public.bv_creations where id = cid and active;
  if not found then return null; end if;
  if not (c.owner = auth.uid() or public.gc_is_admin() or (c.approved and exists (select 1 from public.bv_creation_owned o where o.creation_id = c.id and o.user_id = auth.uid()))) then return null; end if;
  return jsonb_build_object('kind', c.kind, 'image', c.image, 'model', c.model, 'name', c.name);
end $$;
-- admin: what is waiting for approval, and the decision
create or replace function public.bv_creations_pending() returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not public.gc_is_admin() then return '[]'::jsonb; end if;
  return coalesce((select jsonb_agg(jsonb_build_object('id', id, 'kind', kind, 'name', name, 'creator', creator_name, 'price', price, 'thumb', thumb) order by created_at) from public.bv_creations where not approved and active), '[]'::jsonb);
end $$;
create or replace function public.bv_creation_decide(cid uuid, ok boolean) returns text language plpgsql security definer set search_path = public as $$
begin
  if not public.gc_is_admin() then return 'Admins only'; end if;
  if ok then update public.bv_creations set approved = true where id = cid; else delete from public.bv_creations where id = cid; end if;
  return 'ok';
end $$;
grant execute on function public.bv_market(), public.bv_create(text, text, integer, text, text, text), public.bv_creation_discount(uuid, integer, integer), public.bv_creation_delete(uuid),
  public.bv_buy_creation(uuid), public.bv_equip_creation(uuid), public.bv_creation_data(uuid), public.bv_creations_pending(), public.bv_creation_decide(uuid, boolean), public.bv_buy(text), public.bv_equip(text) to authenticated;

-- my profile now also says which costume I wear
create or replace function public.bv_me() returns jsonb language plpgsql security definer set search_path = public as $$
declare p public.bv_profiles; c record;
begin
  if auth.uid() is null then return null; end if;
  insert into public.bv_profiles (id, email) select id, email from auth.users where id = auth.uid() on conflict (id) do nothing;
  update public.bv_profiles set last_seen = now() where id = auth.uid() returning * into p;
  select kind, thumb, image into c from public.bv_creations where id = p.avatar_ref and active and (owner = auth.uid() or approved);
  return jsonb_build_object('id', p.id, 'username', p.username, 'status', p.status, 'reason', p.suspended_reason, 'plus', (p.plus and (p.plus_until is null or p.plus_until > now())),
    'orbs', p.orbs, 'avatar', p.avatar, 'owned', p.owned, 'ref', case when c.kind is null then null else p.avatar_ref end, 'ref_kind', c.kind, 'ref_img', coalesce(c.image, c.thumb));
end $$;
-- friends see my approved costume picture too
create or replace function public.bv_friend_list() returns jsonb language sql security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('rel', f.id, 'status', f.status, 'incoming', f.b = auth.uid(), 'uid', p.id, 'username', p.username, 'avatar', p.avatar,
    'img', (select cr.thumb from public.bv_creations cr where cr.id = p.avatar_ref and cr.approved and cr.active),
    'online', coalesce(p.last_seen > now() - interval '3 minutes', false)) order by f.created_at desc), '[]'::jsonb)
  from public.bv_friends f join public.bv_profiles p on p.id = case when f.a = auth.uid() then f.b else f.a end
  where (f.a = auth.uid() or f.b = auth.uid()) and p.status = 'active'
$$;
