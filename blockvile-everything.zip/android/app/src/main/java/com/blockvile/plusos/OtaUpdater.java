package com.blockvile.plusos;

import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.WebResourceResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Over-the-air updates for Blockvile's WEB content (all the apps, screens and settings).
 *
 * When the user taps "Update now" (or automatic updates run), this downloads the new web files from the
 * publisher's own website over HTTPS, checks every file against the SHA-256 hashes in version.json, and only
 * then switches to them. Nothing is installed and no native code is downloaded: only the HTML/CSS/JS that
 * the WebView shows. Changes to the Android app itself (manifest, Java) still come through Google Play.
 *
 * Safety net: if a new version doesn't confirm that it started ({@link #confirmBoot}), the next launch
 * throws it away and goes back to the web files that came inside the app.
 */
final class OtaUpdater {

    interface Progress { void on(String state, int pct, String message); }

    private static final long MAX_FILE = 6L * 1024 * 1024, MAX_TOTAL = 24L * 1024 * 1024;
    private static final Pattern BUILD = Pattern.compile("^[a-f0-9]{12}$");

    private final Context ctx;
    private final File root;
    private String baseCache = null;

    OtaUpdater(Context c) {
        ctx = c;
        root = new File(c.getFilesDir(), "ota");
    }

    private SharedPreferences prefs() { return ctx.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE); }

    /** The publisher's website address, read from the config.js that shipped INSIDE the app (never from an update). */
    String baseUrl() {
        if (baseCache != null) return baseCache;
        String out = "";
        try (InputStream in = ctx.getAssets().open("js/config.js")) {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[4096]; int n;
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
            Matcher m = Pattern.compile("installUrl:\\s*\"(https://[^\"]+)\"").matcher(b.toString("UTF-8"));
            if (m.find()) { out = m.group(1); if (!out.endsWith("/")) out += "/"; }
        } catch (Exception ignored) { }
        baseCache = out;
        return out;
    }

    boolean enabled() { return !baseUrl().isEmpty(); }

    String current() { return prefs().getString("otaBuild", ""); }

    /** Called once at app start, before anything loads. Drops updates that never started, or that belong to an older app. */
    void startup() {
        SharedPreferences p = prefs();
        boolean pending = p.getBoolean("otaPending", false);
        String forApp = p.getString("otaFor", "");
        if (pending || (!current().isEmpty() && !MainActivity.VERSION.equals(forApp))) clear();
    }

    /** The new version loaded and its page started: keep it. */
    void confirmBoot() {
        if (prefs().getBoolean("otaPending", false)) prefs().edit().putBoolean("otaPending", false).apply();
    }

    void clear() {
        prefs().edit().putString("otaBuild", "").putBoolean("otaPending", false).apply();
        deleteTree(root);
    }

    private static void deleteTree(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteTree(k);
        f.delete();
    }

    /** Serves a file from the downloaded update, or null so the bundled copy is used. */
    WebResourceResponse open(String path) {
        String build = current();
        if (build.isEmpty() || path == null) return null;
        try {
            File dir = new File(root, build), f = new File(dir, path);
            String canon = f.getCanonicalPath();
            if (!canon.startsWith(dir.getCanonicalPath() + File.separator) || !f.isFile()) return null;   // no ../ tricks
            return new WebResourceResponse(mime(path), mime(path).startsWith("text/") || mime(path).contains("javascript") || mime(path).contains("json") || mime(path).contains("svg") ? "utf-8" : null, new FileInputStream(f));
        } catch (Exception e) {
            return null;
        }
    }

    private static String mime(String p) {
        String l = p.toLowerCase(Locale.ROOT);
        if (l.endsWith(".html")) return "text/html";
        if (l.endsWith(".js")) return "application/javascript";
        if (l.endsWith(".css")) return "text/css";
        if (l.endsWith(".json")) return "application/json";
        if (l.endsWith(".svg")) return "image/svg+xml";
        if (l.endsWith(".png")) return "image/png";
        if (l.endsWith(".jpg") || l.endsWith(".jpeg")) return "image/jpeg";
        if (l.endsWith(".webp")) return "image/webp";
        if (l.endsWith(".ico")) return "image/x-icon";
        return "application/octet-stream";
    }

    private static byte[] get(String url, long max) throws IOException {
        HttpURLConnection c = (HttpURLConnection) java.net.URI.create(url).toURL().openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        c.setUseCaches(false);
        c.setInstanceFollowRedirects(true);
        if (c.getResponseCode() != 200) throw new IOException("HTTP " + c.getResponseCode());
        if (!c.getURL().getProtocol().equals("https")) throw new IOException("Not secure");
        try (InputStream in = c.getInputStream()) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384]; int n; long total = 0;
            while ((n = in.read(buf)) > 0) { total += n; if (total > max) throw new IOException("File too big"); out.write(buf, 0, n); }
            return out.toByteArray();
        } finally {
            c.disconnect();
        }
    }

    private static String sha256(byte[] data) throws Exception {
        byte[] d = MessageDigest.getInstance("SHA-256").digest(data);
        StringBuilder s = new StringBuilder();
        for (byte b : d) s.append(String.format("%02x", b));
        return s.toString();
    }

    private static final Pattern VER = Pattern.compile("^[0-9]{1,4}(\\.[0-9]{1,4}){0,3}$");

    /** Downloads, verifies and switches to the newest web files. Runs on a background thread. */
    void apply(Progress p) throws Exception { apply(null, p); }

    /**
     * Same, but for a chosen release kept at <site>/versions/<version>/ (older OR newer). Passing the version that is
     * bundled inside the app just drops any downloaded files. A release that needs a newer Android app is refused.
     */
    void apply(String version, Progress p) throws Exception {
        String base = baseUrl();
        if (base.isEmpty()) throw new IOException("Updates aren't set up for this app");
        if (version != null) {
            if (!VER.matcher(version).matches()) throw new IOException("Bad version");
            if (version.equals(MainActivity.VERSION)) { clear(); p.on("done", 100, "Switched"); return; }
            base = base + "versions/" + version + "/";
        }
        p.on("downloading", 0, "Checking…");
        JSONObject v = new JSONObject(new String(get(base + "version.json?t=" + System.currentTimeMillis(), 2L * 1024 * 1024), StandardCharsets.UTF_8));
        String build = v.getString("build");
        if (!BUILD.matcher(build).matches()) throw new IOException("Bad version file");
        if (version != null && !version.equals(v.optString("version"))) throw new IOException("That version isn't available");
        if (v.optInt("native", 1) > MainActivity.NATIVE_API) throw new IOException("That version needs a newer Android app (Google Play)");
        if (build.equals(current())) { p.on("done", 100, "Already up to date"); return; }
        JSONArray files = v.getJSONArray("files");
        if (files.length() < 1 || files.length() > 400) throw new IOException("Bad version file");

        File tmp = new File(root, "tmp-" + build), fin = new File(root, build);
        deleteTree(tmp); deleteTree(fin);
        if (!tmp.mkdirs()) throw new IOException("No space to save the update");
        long total = 0; boolean hasIndex = false;
        try {
            for (int i = 0; i < files.length(); i++) {
                JSONObject f = files.getJSONObject(i);
                String path = f.getString("path"), want = f.getString("sha256").toLowerCase(Locale.ROOT);
                if (path.startsWith("/") || path.contains("..") || path.contains("\\") || path.contains("?") || path.contains("#")) throw new IOException("Bad file name");
                byte[] data = get(base + path, MAX_FILE);
                total += data.length;
                if (total > MAX_TOTAL) throw new IOException("Update too big");
                if (!sha256(data).equals(want)) throw new IOException("A file didn't match its checksum: " + path);
                File out = new File(tmp, path);
                File parent = out.getParentFile();
                if (!out.getCanonicalPath().startsWith(tmp.getCanonicalPath() + File.separator)) throw new IOException("Bad file name");
                if (parent != null && !parent.exists() && !parent.mkdirs()) throw new IOException("Couldn't save the update");
                try (FileOutputStream fo = new FileOutputStream(out)) { fo.write(data); }
                if (path.equals("index.html")) hasIndex = true;
                p.on("downloading", (i + 1) * 100 / files.length(), path);
            }
            if (!hasIndex) throw new IOException("Update is missing its main page");
            if (!tmp.renameTo(fin)) throw new IOException("Couldn't finish the update");
        } catch (Exception e) {
            deleteTree(tmp);
            throw e;
        }
        String old = current();
        prefs().edit().putString("otaBuild", build).putString("otaFor", MainActivity.VERSION).putBoolean("otaPending", true).apply();
        if (!old.isEmpty() && !old.equals(build)) deleteTree(new File(root, old));
        p.on("done", 100, "Updated");
    }
}
