package com.blockvile.plusos;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/**
 * Websites open here, inside the Blockvile app, instead of in the phone's browser.
 * It is a plain browser window with Close / Back / Reload / "Open outside" buttons.
 * It has no access to Blockvile's own data (separate page, no JavaScript bridge).
 * Links that mean "install this app" (market:// and Play's intent: links) are handed to the real Google Play app,
 * because only Google Play itself can install apps.
 */
public class InAppBrowserActivity extends Activity {
    static final String EXTRA_URL = "url";
    private static final String PLAY_STORE = "com.android.vending";

    private WebView web;
    private TextView title;
    private String current = "";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        String url = getIntent() != null ? getIntent().getStringExtra(EXTRA_URL) : null;
        if (!isWeb(url)) { finish(); return; }
        current = url;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#0f172a"));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.parseColor("#0f172a"));
        bar.addView(button("✕", v -> finish()), new LinearLayout.LayoutParams(dp(48), dp(48)));
        bar.addView(button("‹", v -> { if (web.canGoBack()) web.goBack(); else finish(); }), new LinearLayout.LayoutParams(dp(44), dp(48)));
        title = new TextView(this);
        title.setTextColor(Color.WHITE);
        title.setTextSize(14);
        title.setSingleLine(true);
        title.setText(host(url));
        title.setPadding(dp(6), 0, dp(6), 0);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(button("↻", v -> web.reload()), new LinearLayout.LayoutParams(dp(44), dp(48)));
        bar.addView(button("↗", v -> openOutside()), new LinearLayout.LayoutParams(dp(44), dp(48)));
        root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        web = new WebView(this);
        root.addView(web, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportMultipleWindows(false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handle(request.getUrl());
            }

            @Override
            public void onPageFinished(WebView view, String u) {
                if (u != null) { current = u; title.setText(host(u)); }
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.loadUrl(url);
    }

    /** true = we dealt with the link ourselves, false = let this window load it */
    private boolean handle(Uri u) {
        String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
        if (scheme.equals("http") || scheme.equals("https")) return false;
        try {
            if (scheme.equals("market")) {
                Intent i = new Intent(Intent.ACTION_VIEW, u);
                i.setPackage(PLAY_STORE);
                startActivity(i);                                   // the real Google Play does the installing
            } else if (scheme.equals("intent")) {
                Intent i = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME);
                Uri data = i.getData();
                String pkg = i.getPackage();
                if (pkg != null && validPackage(pkg)) {
                    Intent play = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + Uri.encode(pkg)));
                    play.setPackage(PLAY_STORE);
                    startActivity(play);                            // "get this app" → Google Play
                } else if (data != null && isWeb(data.toString())) {
                    web.loadUrl(data.toString());
                }
            } else if (scheme.equals("tel") || scheme.equals("mailto")) {
                startActivity(new Intent(scheme.equals("tel") ? Intent.ACTION_DIAL : Intent.ACTION_SENDTO, u));
            }                                                       // anything else is ignored
        } catch (ActivityNotFoundException | java.net.URISyntaxException e) {
            Toast.makeText(this, "Can't open that here", Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    private void openOutside() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(current)));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No browser found", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else finish();
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }

    private TextView button(String label, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(Color.WHITE);
        t.setTextSize(20);
        t.setGravity(Gravity.CENTER);
        t.setOnClickListener(l);
        return t;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    static boolean isWeb(String u) {
        if (u == null) return false;
        String l = u.trim().toLowerCase(Locale.ROOT);
        return l.startsWith("https://") || l.startsWith("http://");
    }

    private static boolean validPackage(String p) {
        return p != null && p.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+");
    }

    private static String host(String u) {
        try { String h = Uri.parse(u).getHost(); return h == null ? u : h; } catch (RuntimeException e) { return u; }
    }
}
