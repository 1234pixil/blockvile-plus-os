package com.blockvile.plusos;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * A temporary takeover never survives a restart. When the phone finishes booting, this switches
 * Blockvile's home-screen entry point off again, so the phone starts on its own home screen.
 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            MainActivity.clearTakeover(context);
        }
    }
}
