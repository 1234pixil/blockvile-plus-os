package com.blockvile.plusos;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.role.RoleManager;
import android.content.ComponentName;
import android.content.SharedPreferences;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.DisplayCutout;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import androidx.webkit.WebViewAssetLoader;

import java.util.ArrayList;
import java.util.List;

/**
 * Blockvile Plus OS for Android.
 * Runs the Blockvile web OS (bundled in assets) full-screen, and gives it native powers through
 * {@link AndroidBridge}: listing and launching the phone's real apps, sending installs to Google Play,
 * uninstalling, real device controls, and the temporary takeover.
 *
 * Temporary takeover (only ever started by the user's button): Blockvile becomes the phone's home
 * screen through a separate HOME entry point, {@code .HomeAlias}, that is switched on only for the
 * takeover. It is never permanent: Exit, the Terminal command "application exit", or restarting the
 * phone switches that entry point off again and hands the phone back to its original home screen.
 */
public class MainActivity extends Activity {

    static final String VERSION = "3.35";
    /** Raise only when a release needs a newer Android app (then "Update" sends people to Google Play). */
    static final int NATIVE_API = 1;
    static final String PREFS = "blockvile";
    static final String HOST = "appassets.androidplatform.net";
    static final String START_URL = "https://" + HOST + "/assets/index.html";
    private static final int REQ_FILE = 41;
    private static final int REQ_PERM_MEDIA = 42;
    private static final int REQ_PERM_LOCATION = 43;
    private static final int REQ_ROLE_HOME = 44;
    static final int REQ_PERM_NOTIFY = 45;

    private WebView web;
    private WebViewAssetLoader assetLoader;
    OtaUpdater ota;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingWebPermission;
    private GeolocationPermissions.Callback geoCallback;
    private String geoOrigin;
    private BroadcastReceiver packageReceiver;
    private OnBackInvokedCallback backCallback;
    private float safeTop = 0f, safeBottom = 0f;
    private FrameLayout rootView;
    private View fullscreenVideo;
    private WebChromeClient.CustomViewCallback fullscreenVideoCallback;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        rootView = new FrameLayout(this);
        rootView.setBackgroundColor(Color.BLACK);
        rootView.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(rootView);
        goImmersive();

        ota = new OtaUpdater(this);
        ota.startup();   // drops an update that never started, or one left over from an older app
        final WebViewAssetLoader.PathHandler bundled = new WebViewAssetLoader.AssetsPathHandler(this);
        assetLoader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", path -> {
                    WebResourceResponse updated = ota.open(path);      // a downloaded update wins …
                    return updated != null ? updated : bundled.handle(path);   // … otherwise the files inside the app
                })
                .build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportMultipleWindows(false);
        s.setUserAgentString(s.getUserAgentString() + " BlockvilePlus/" + VERSION);

        web.addJavascriptInterface(new AndroidBridge(this), "BlockvileAndroid");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (!request.isForMainFrame()) return false;          // iframes (Browser, Maps, Cloud Music) load normally
                if (HOST.equals(u.getHost())) return false;            // our own pages
                String sch = String.valueOf(u.getScheme()).toLowerCase(java.util.Locale.ROOT);
                if (sch.equals("http") || sch.equals("https")) {       // websites open inside Blockvile (in-app browser) …
                    Intent i = new Intent(MainActivity.this, InAppBrowserActivity.class);
                    i.putExtra(InAppBrowserActivity.EXTRA_URL, u.toString());
                    startSafely(i);
                } else {
                    openExternal(u.toString());                        // … phone numbers, e-mail and app links go to the right app
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pushSafeArea();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                handleWebPermission(request);
            }

            // Full-screen button in videos (Videos app, Browser)
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (fullscreenVideo != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                fullscreenVideo = view;
                fullscreenVideoCallback = callback;
                rootView.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                web.setVisibility(View.INVISIBLE);
                goImmersive();
            }

            @Override
            public void onHideCustomView() {
                hideFullscreenVideo();
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                    callback.invoke(origin, true, false);
                } else {
                    geoOrigin = origin;
                    geoCallback = callback;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_PERM_LOCATION);
                }
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                }
                try {
                    startActivityForResult(intent, REQ_FILE);
                    return true;
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    return false;
                }
            }
        });

        web.setOnApplyWindowInsetsListener((v, insets) -> {
            readSafeArea(insets);
            pushSafeArea();
            return insets;
        });

        registerBackHandler();
        registerPackageReceiver();
        endTakeoverIfRebooted();
        pendingDeepLink = deepLinkFrom(getIntent());

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(START_URL);
        }
    }

    /* ---------------- Full-screen (Blockvile draws its own status bar) ---------------- */

    @SuppressWarnings("deprecation")
    private void goImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) goImmersive();
    }

    private void readSafeArea(WindowInsets insets) {
        float d = getResources().getDisplayMetrics().density;
        int top = 0, bottom = 0;
        if (Build.VERSION.SDK_INT >= 28) {
            DisplayCutout cut = insets.getDisplayCutout();
            if (cut != null) {
                top = cut.getSafeInsetTop();
                bottom = cut.getSafeInsetBottom();
            }
        }
        safeTop = top / d;
        safeBottom = bottom / d;
    }

    private void pushSafeArea() {
        js("document.documentElement.style.setProperty('--safe-top','" + safeTop + "px');"
                + "document.documentElement.style.setProperty('--safe-bottom','" + safeBottom + "px');");
    }

    /* ---------------- Back button & Home button ---------------- */

    private void registerBackHandler() {
        if (Build.VERSION.SDK_INT >= 33) {
            backCallback = this::handleBack;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, backCallback);
        }
    }

    @SuppressLint({"MissingSuperCall", "GestureBackNavigation"})
    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() { // Android 12 and older
        handleBack();
    }

    private void hideFullscreenVideo() {
        if (fullscreenVideo == null) return;
        rootView.removeView(fullscreenVideo);
        fullscreenVideo = null;
        web.setVisibility(View.VISIBLE);
        if (fullscreenVideoCallback != null) fullscreenVideoCallback.onCustomViewHidden();
        fullscreenVideoCallback = null;
        goImmersive();
    }

    private void handleBack() {
        if (fullscreenVideo != null) {
            hideFullscreenVideo();
            return;
        }
        web.evaluateJavascript(
                "(function(){try{return !!(window.BlockvileOS&&BlockvileOS.handleBack())}catch(e){return false}})()",
                result -> {
                    if (!"true".equals(result) && !isDefaultLauncher()) moveTaskToBack(true);
                });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String deep = deepLinkFrom(intent);
        if (deep != null) {   // coming back from Google / Microsoft sign-in in the phone's browser
            js("window.__bvDeep=" + jsString(deep) + ";window.BV&&BV.auth&&BV.auth.deepLink&&BV.auth.deepLink(window.__bvDeep)");
            return;
        }
        if (intent != null && !intent.hasCategory(Intent.CATEGORY_HOME)) {
            js("window.dispatchEvent(new Event('bv:opened'))"); // opened from its app icon
        }
        if (intent != null && intent.hasCategory(Intent.CATEGORY_HOME)) {
            js("window.BlockvileOS&&BlockvileOS.home()");
        }
    }

    boolean isDefaultLauncher() {
        Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        ResolveInfo ri = getPackageManager().resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY);
        return ri != null && ri.activityInfo != null && getPackageName().equals(ri.activityInfo.packageName);
    }

    /* ---------------- Full-device mode: Blockvile is the phone's system until Exit ---------------- */

    SharedPreferences prefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    /** The HOME entry point declared in the manifest (disabled until full-device mode is turned on). */
    private ComponentName homeAlias() {
        return new ComponentName(getPackageName(), MainActivity.class.getName().replace("MainActivity", "HomeAlias"));
    }

    boolean homeAliasEnabled() {
        return getPackageManager().getComponentEnabledSetting(homeAlias()) == PackageManager.COMPONENT_ENABLED_STATE_ENABLED;
    }

    private void setHomeAlias(boolean on) {
        getPackageManager().setComponentEnabledSetting(homeAlias(),
                on ? PackageManager.COMPONENT_ENABLED_STATE_ENABLED : PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP);
    }

    /** Package of the current default home app, or null if there's no default yet. */
    String currentHomePackage() {
        Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        ResolveInfo ri = getPackageManager().resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY);
        if (ri == null || ri.activityInfo == null) return null;
        String pkg = ri.activityInfo.packageName;
        return "android".equals(pkg) ? null : pkg; // "android" = the system's "choose a home app" screen
    }

    /** When this boot started (ms since 1970). Changes after every restart. */
    static long bootStamp() {
        return System.currentTimeMillis() - SystemClock.elapsedRealtime();
    }

    boolean takeoverActive() {
        return prefs().getBoolean("takeover", false) && homeAliasEnabled();
    }

    /** The user pressed "Temporarily let Blockvile take over this device". Android asks them to confirm. */
    void startTakeover() {
        runOnUiThread(() -> {
            String current = currentHomePackage();
            SharedPreferences.Editor e = prefs().edit().putBoolean("takeover", true).putLong("takeoverBoot", bootStamp());
            if (current != null && !current.equals(getPackageName())) e.putString("previousHome", current);
            e.apply();
            setHomeAlias(true);
            // give the package manager a moment to register the new home screen before asking
            web.postDelayed(this::requestHomeRole, 350);
        });
    }

    private void requestHomeRole() {
        if (isDefaultLauncher()) {
            js("window.dispatchEvent(new Event('bv:takeover'))");
            return;
        }
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = getSystemService(RoleManager.class);
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                try {
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), REQ_ROLE_HOME);
                    return;
                } catch (ActivityNotFoundException ignored) { }
            }
        }
        startWithFallback(new Intent(Settings.ACTION_HOME_SETTINGS), new Intent(Settings.ACTION_SETTINGS));
    }

    /** Switches the takeover off without leaving the screen (used after a restart). */
    static void clearTakeover(Context c) {
        try {
            c.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("takeover", false).apply();
        } catch (IllegalStateException ignored) { } // storage not unlocked yet — the entry point below is what matters
        c.getPackageManager().setComponentEnabledSetting(
                new ComponentName(c.getPackageName(), MainActivity.class.getName().replace("MainActivity", "HomeAlias")),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
    }

    /** A takeover never survives a restart: if the phone has rebooted since it started, end it now. */
    private void endTakeoverIfRebooted() {
        if (!prefs().getBoolean("takeover", false) && !homeAliasEnabled()) return;
        long started = prefs().getLong("takeoverBoot", 0);
        if (prefs().getBoolean("takeover", false) && Math.abs(bootStamp() - started) < 60_000) return;
        boolean wasHome = isDefaultLauncher();
        clearTakeover(this);
        if (wasHome) launchOriginalHome();
    }

    /**
     * Exit / "application exit": end the temporary takeover and give the phone back to its original
     * system. Opens the previous home screen and switches off Blockvile's HOME entry point, so pressing
     * Home no longer opens Blockvile. Nothing is left changed.
     */
    void exitToSystem() {
        runOnUiThread(() -> {
            prefs().edit().putBoolean("takeover", false).apply();
            boolean launched = launchOriginalHome();
            web.postDelayed(() -> {
                if (homeAliasEnabled()) setHomeAlias(false);
                js("window.dispatchEvent(new Event('bv:takeover'))");
                if (!launched) startWithFallback(new Intent(Settings.ACTION_HOME_SETTINGS), new Intent(Settings.ACTION_SETTINGS));
                moveTaskToBack(true);
            }, 300);
        });
    }

    /** Opens the phone's own home screen (the one used before Blockvile). Returns false if none was found. */
    private boolean launchOriginalHome() {
        String preferred = prefs().getString("previousHome", null);
        Intent query = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        List<ResolveInfo> homes = getPackageManager().queryIntentActivities(query, 0);
        ResolveInfo pick = null;
        for (ResolveInfo ri : homes) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            if (pkg.equals(preferred)) { pick = ri; break; }
            // Settings' "FallbackHome" is only used while the phone boots; skip it
            if (pick == null && !"com.android.settings".equals(pkg) && !"android".equals(pkg)) pick = ri;
        }
        if (pick == null) return false;
        Intent go = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .setClassName(pick.activityInfo.packageName, pick.activityInfo.name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try {
            startActivity(go);
            return true;
        } catch (ActivityNotFoundException | SecurityException e) {
            return false;
        }
    }

    String previousHomeLabel() {
        String pkg = prefs().getString("previousHome", null);
        if (pkg == null) return "";
        try {
            return String.valueOf(getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg, 0)));
        } catch (PackageManager.NameNotFoundException e) {
            return "";
        }
    }

    /* ---------------- Screen brightness (this window only — no special permission) ---------------- */

    void setScreenBrightness(int percent) {
        runOnUiThread(() -> {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.screenBrightness = percent < 0 ? WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE : Math.max(0.02f, Math.min(1f, percent / 100f));
            getWindow().setAttributes(lp);
        });
    }

    void keepScreenOn(boolean on) {
        runOnUiThread(() -> {
            if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        });
    }

    void askPermission(String permission, int code) {
        runOnUiThread(() -> requestPermissions(new String[]{permission}, code));
    }

    /* ---------------- App installs / removals (from Google Play or elsewhere) ---------------- */

    private void registerPackageReceiver() {
        packageReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                js("window.dispatchEvent(new Event('bv:packages'))");
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_REPLACED);
        f.addDataScheme("package");
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(packageReceiver, f, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(packageReceiver, f);
        }
    }

    /* ---------------- Opening things outside Blockvile ---------------- */

    void openExternal(String url) {
        runOnUiThread(() -> {
            try {
                Intent i;
                if (url.startsWith("intent:")) {
                    i = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                } else if (url.startsWith("tel:")) {
                    i = new Intent(Intent.ACTION_DIAL, Uri.parse(url));
                } else {
                    i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                }
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
                Toast.makeText(this, "No app can open this link", Toast.LENGTH_SHORT).show();
            }
        });
    }

    void startSafely(Intent i) {
        runOnUiThread(() -> {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this, "Not available on this device", Toast.LENGTH_SHORT).show();
            }
        });
    }

    void startWithFallback(Intent primary, Intent fallback) {
        runOnUiThread(() -> {
            try {
                primary.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(primary);
            } catch (ActivityNotFoundException e) {
                startSafely(fallback);
            }
        });
    }

    /* ---------------- Over-the-air web updates ---------------- */
    void reloadPage() { runOnUiThread(() -> { if (web != null) web.loadUrl(START_URL); }); }

    /* ---------------- Sign-in return link (blockvile://auth) ---------------- */
    private String pendingDeepLink = null;

    private static String deepLinkFrom(Intent intent) {
        if (intent == null || intent.getData() == null) return null;
        String u = intent.getData().toString();
        return u.startsWith("blockvile://auth") ? u : null;
    }

    /** Hands the sign-in return link to the page once (cold start) and forgets it. */
    String takePendingDeepLink() {
        String d = pendingDeepLink;
        pendingDeepLink = null;
        return d;
    }

    private static String jsString(String v) {
        StringBuilder b = new StringBuilder("\"");
        for (char c : v.toCharArray()) {
            if (c == '"' || c == '\\') b.append('\\');
            if (c >= 32) b.append(c);
        }
        return b.append('"').toString();
    }

    void js(String code) {
        runOnUiThread(() -> {
            if (web != null) web.evaluateJavascript(code, null);
        });
    }

    /* ---------------- Camera / microphone / location / file picking for web apps ---------------- */

    private boolean hasPermission(String p) {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private void handleWebPermission(PermissionRequest request) {
        Uri origin = request.getOrigin();
        if (origin == null || !HOST.equals(origin.getHost())) { // only Blockvile itself may use camera/mic
            request.deny();
            return;
        }
        List<String> missing = new ArrayList<>();
        for (String r : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && !hasPermission(Manifest.permission.CAMERA)) {
                missing.add(Manifest.permission.CAMERA);
            }
            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && !hasPermission(Manifest.permission.RECORD_AUDIO)) {
                missing.add(Manifest.permission.RECORD_AUDIO);
            }
        }
        if (missing.isEmpty()) {
            request.grant(request.getResources());
        } else {
            if (pendingWebPermission != null) pendingWebPermission.deny();
            pendingWebPermission = request;
            requestPermissions(missing.toArray(new String[0]), REQ_PERM_MEDIA);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERM_MEDIA && pendingWebPermission != null) {
            List<String> ok = new ArrayList<>();
            for (String r : pendingWebPermission.getResources()) {
                if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && hasPermission(Manifest.permission.CAMERA)) ok.add(r);
                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && hasPermission(Manifest.permission.RECORD_AUDIO)) ok.add(r);
            }
            if (ok.isEmpty()) pendingWebPermission.deny();
            else pendingWebPermission.grant(ok.toArray(new String[0]));
            pendingWebPermission = null;
        }
        if (requestCode == REQ_PERM_LOCATION && geoCallback != null) {
            geoCallback.invoke(geoOrigin, hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION), false);
            geoCallback = null;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_ROLE_HOME) {
            if (!isDefaultLauncher()) {          // the user said no: undo everything, nothing stays switched on
                clearTakeover(this);
            }
            js("window.dispatchEvent(new Event('bv:takeover'))");
            return;
        }
        if (requestCode != REQ_FILE || fileCallback == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                result = new Uri[n];
                for (int i = 0; i < n; i++) result[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
    }

    /* ---------------- Lifecycle ---------------- */

    @Override
    protected void onResume() {
        super.onResume();
        endTakeoverIfRebooted();
        web.onResume();
        goImmersive();
        js("window.dispatchEvent(new Event('bv:resume'))"); // lets the Store notice apps Play just installed
    }

    @Override
    protected void onPause() {
        web.onPause();
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onDestroy() {
        if (packageReceiver != null) {
            try { unregisterReceiver(packageReceiver); } catch (IllegalArgumentException ignored) { }
        }
        if (Build.VERSION.SDK_INT >= 33 && backCallback != null) {
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCallback);
        }
        if (web != null) {
            web.removeJavascriptInterface("BlockvileAndroid");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
