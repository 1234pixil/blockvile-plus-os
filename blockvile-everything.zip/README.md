# Blockvile Plus OS 3.21

A HyperOS-style operating system with Phone, Tablet and Laptop modes, 25+ apps, a real file system and a terminal. It works offline.

It runs three ways:
- **As one single web page:** `blockvile-plus-os.html`. Everything is inside that one file. Open it directly, put it on any website, or embed it in another page.
- **In any browser from the folder version** in `web/`.
- **As a real Android app** that you can publish on Google Play. This is in the `android/` folder.

The Android app can:
- show and launch your phone's real apps
- install new ones through Google Play
- uninstall apps
- **temporarily take over** the phone (below) — never permanent
- control the real phone

## Temporary takeover — Blockvile is your system only until you end it
Tap **Temporarily let Blockvile take over this device** (home screen, Control Centre or Settings). It is **only temporary**: it never starts by itself, is never saved, and there is no permanent mode.

- **End it any time:** type `application exit` in the **Terminal**, press the red **⏻ Exit** button (status bar; menu bar in Laptop mode), tap the takeover button again, use the Control Centre, power menu or Settings, or press `Ctrl+Shift+E`.
- **Terminal commands:** `application takeover`, `application status`, `application exit`.
- **Android app:**
  - Android shows its own "home app" prompt. Say no and nothing changes. While it's on, Home comes back to Blockvile and every phone app is in the **Android Apps** drawer.
  - Ending it (or restarting the phone, or reinstalling) switches Blockvile's home-screen entry off and hands the phone back to its original home screen (Pixel Launcher, One UI Home, …).
  - Controls work on the real phone:
    - brightness, volume and torch change for real
    - Wi-Fi, Bluetooth, mobile data and airplane mode open the phone's own switches
    - notifications appear on the phone while Blockvile is in the background
    - alarms and timers are also set in the phone's Clock app
    - calendar events can be added to the phone's calendar
- **Browser or installed web app:**
  - Blockvile fills the whole screen, hides the browser's bars, keeps the screen awake and captures keys such as Esc, until you end it.
  - If you leave full screen, the next tap brings it back — until you end the takeover. Closing the tab asks first.
  - Reloading the page ends it too.
- When Blockvile is embedded in another page, the page is told with `blockvile:takeover-start` / `blockvile:takeover-end` messages.

## Accounts, Digital SIM and Blockvile AI (optional, needs Supabase)
- **Sign in** with Google, Microsoft or any email (including your own domain). Link devices, open your Google and Microsoft apps (real apps on Android when installed), and see unread mail, next events and recent files (read-only).
- **📶 Digital SIM** — only exists while you're signed in. A Blockvile number (`BV 1234 5678`) for messaging other Blockvile users. It **charges 1% a minute on Wi-Fi** and **banks Wi-Fi data** (5 MB a minute, up to 500 MB) that SIM messages spend when Wi-Fi is off or unavailable; each message uses 2% charge. It is **not a carrier SIM** (no calls/texts to normal numbers, and the data allowance can't create internet — off Wi-Fi it still uses the phone's own connection).
- **✨ Blockvile AI** — device commands work offline ("open notes", "dark mode on"); general answers use a Supabase Edge Function that holds your AI key safely.
- **Setup:** follow **[SUPABASE-SETUP.md](SUPABASE-SETUP.md)**. The database script is `supabase/schema.sql`, the AI function is `supabase/functions/blockvile-ai`.

## Updates — no re-download
Blockvile checks your website for a newer version and sends an **Update available** notification. The separate **⬆️ OS Update** app (also reachable from Settings) has an **Update** tab (version, **Check for updates**, **Update now** with progress and release notes, history) and a **Versions** tab to switch to an older or newer release. **Debug Center** (🐞 app, Terminal `debug`) collects every error; people can copy/save it, send it to you, or attach it to **Feedback**, which now also takes screenshots/files. Run `supabase/debug-and-files.sql` once (also inside schema.sql); reports land in Supabase → Table Editor → `debug_reports`, files in Storage → `feedback-files`. Updater ↔ OS link: see **`updater-app/`** (a separate app for its own repo) and `supabase/updater-link.sql`. There is also a fully separate installable web app, **`updater.html`** (Blockvile Updater, its own icon), for updating or switching versions without opening the OS. In the Terminal: `switch version` (list), `switch version 3.15 now`, `switch version latest now`. Updates are **manual**: a card appears on the home screen and nothing installs until the user taps **Update now**. See **[UPDATING.md](UPDATING.md)**.

👉 **To publish on Google Play, follow [PLAY-STORE-GUIDE.md](PLAY-STORE-GUIDE.md).**

## Use the one-file version
- **Open it:** double-click `blockvile-plus-os.html`.
- **Put it online:** upload that one file to any web host (GitHub Pages, Netlify, your own site). Nothing else is needed.
- **Embed it in another page** (Google Sites, a blog, your own site), with an iframe like this:
```html
<iframe src="https://YOUR-SITE/blockvile-plus-os.html"
        style="width:100%;height:720px;border:0"
        allow="fullscreen; camera; microphone; geolocation; autoplay; clipboard-write; encrypted-media; picture-in-picture"></iframe>
```
  - When embedded, Blockvile fills the frame instead of drawing a phone around itself. It picks Phone, Tablet or Laptop mode from the frame's size.
  - The `allow=` part lets the Camera, Recorder, location, full screen and videos work inside the frame. Leave out anything you don't want.
  - If the host site blocks saving (some sandboxed embeds do), Blockvile still works. It keeps everything in memory and shows a notice that changes won't be saved after closing.
  - Embeds that block pop-up boxes are fine too, because Blockvile uses its own dialogs.
  - **Google Sites:** Insert → Embed → "By URL", and paste the link to your hosted `blockvile-plus-os.html`.
  - **Talking to the page around it:** Blockvile sends `{type: "blockvile:exit"}` to the embedding page when Exit is pressed, and `{type: "blockvile:enter"}` when it starts again. The page can send the same messages to Blockvile to close or reopen it:
    ```js
    addEventListener("message", e => { if (e.data?.type === "blockvile:exit") myFrame.style.display = "none"; });
    myFrame.contentWindow.postMessage({ type: "blockvile:enter" }, "*");
    ```
- **After editing files in `web/`**, rebuild the one-file version with `python3 tools/build-single-file.py`. The GitHub website workflow also builds it automatically.

## Start the web version
- **Quick:** double-click `web/index.html`.
- **Best:** double-click `start-windows.bat` (Windows) or run `./start-mac-linux.sh` (Mac/Linux). These need Python and open `http://localhost:8080`. Running it this way turns on the offline cache and lets you install it as an app.
- **Phone or tablet:** upload the folder to a free host such as GitHub Pages or Netlify. Open it in your browser and choose **Add to Home screen**.

## Three device modes
| Mode | Feels like |
|---|---|
| 📱 Phone | Android/HyperOS: home screen, dock, gesture bar, swipe-down panels, rotate to landscape |
| 📲 Tablet | Android tablet: split-screen for the two most recent apps, side panels |
| 💻 Laptop | macOS/Windows: menu bar, dock/taskbar, start launcher, draggable/resizable windows, window snapping, right-click menus |

## System features
- **Spotlight search** (`Ctrl+K`) finds apps, files, settings and actions. You can also type a sum like `12*7`, or search the web.
- **Control Centre** has Wi-Fi, data, brightness, volume, Bluetooth, dark mode, airplane mode, torch, Do Not Disturb, night light, battery saver, rotate, mode tiles, a power button and **Exit OS**.
- **Notifications** use heads-up banners and app icon badges. They also show on the lock screen, and tapping one opens its app. Do Not Disturb silences them.
- **Lock screen** has an optional PIN, auto-lock after a set idle time, plus torch and camera shortcuts.
- **Power menu** has Lock, Sleep, Restart, Shut down and Exit.
- **Multitasking:** recents/app switcher, Back and Home. Gestures are swipe up for home and a longer swipe up for recents.
- **Windows (laptop):** drag a window to the left or right edge to snap it to half the screen, or to the top to maximise. `Alt+arrow keys` also snap. You can also minimise, maximise and resize.
- **Personalise:** dark/light or follow system, 7 accent colours, 4 wallpapers, or your own photo as wallpaper.
- **Accessibility:** large text, reduce motion and high contrast.
- **Storage:**
  - Files, notes, contacts and so on are saved in your browser's storage.
  - Photos, music and recordings are kept in your browser's database.
- **Play Store** (Play-Store-style):
  - Tabs for For you, Top charts (ranked by what you open most), Categories and Library, plus search.
  - App detail pages show size, permissions and features, with an install progress bar and an "installed" notification.
  - Install extra apps: **2048**, **Tic-Tac-Toe** (with an unbeatable AI) and **Converter**.
  - **Android tab** for getting real Android apps through Google Play:
    - **In the Android app:** **Install** opens the app in Google Play, which installs it. When you come back, Blockvile has already found the new app and added it to your home screen. Installed apps show **Open**.
    - **In a browser:** **Get** opens the app's page on play.google.com.
    - Search Google Play, or paste a Play link or package name (e.g. `com.duolingo`).
    - Popular apps that have a web version can be added to your home screen with **＋ Web**. These open in a new browser tab.
    - In the Android app, the **Android Apps** drawer lists every app on the phone. Tap to open; long-press to pin to the Blockvile home screen, view in Play, see app info or uninstall.
    - In the browser version, Android apps can't run.
  - **Add any website as an app** from the Library tab. Tick “Open in a new browser tab” for sites that block being shown inside apps.
  - Right-click (or long-press) any app to pin it to the dock or uninstall it.
- **YouTube:** watch YouTube with YouTube's official embedded player.
  - Paste any YouTube link (videos, Shorts, live, playlists, links with a start time) and it plays.
  - Save favourites, see your watch history, and get an "Up next" list.
  - **The app is the Tube page** (`web/tube.html`): trending and search results are real YouTube results, with lengths and view counts. Videos play in YouTube's own player. Likes, subscriptions, watch later and history are saved on the device.
  - **Your YouTube key stays on your server**: the app never contains it. Search calls the `blockvile-youtube` Supabase Edge Function (`supabase/functions/blockvile-youtube`), which needs sign-in, validates input, and has per-user and total daily limits. See SUPABASE-SETUP.md → YouTube.
- **Feedback:** send bug reports, ideas, praise or questions, with a star rating and optional device details. You choose where feedback goes in `web/js/config.js`:
  - a free form service such as Formspree (sent straight from the app), or
  - your email address (opens the user's email app with everything filled in).
  - Until either is set, feedback is saved on the device and can be copied or saved as a file.
- **Help:** a searchable guide covering getting started, modes, the temporary takeover, Exit, installing and every app.
- **Touch feedback:** a light vibration when you tap (on by default on touch screens), and optional click sounds. Both are in Settings → Sound & notifications.
- **Install and offline:** Settings, Help and the menus have **Install on this device**.
  - On a website, this installs Blockvile with its own icon. It opens full screen and works offline.
  - It also offers the one-file version as a download you can keep and open offline.
- **Cloud Music:** stream SoundCloud tracks, playlists and artists with SoundCloud's official player.
  - Paste a link to play it, then save it to your library and skip back and forth through it.
  - Discover searches SoundCloud in a new tab. Copy any link from there and paste it back to play.

## Apps
| | |
|---|---|
| System | Settings, Files, Terminal, Text Editor, App Store, Task Manager, About |
| Productivity | Notes, Calculator, Clock (world clock, alarms, stopwatch, timer), Calendar (with event alerts), Reminders |
| Communication | Phone (keypad, recents, contacts — calls go to your device's dialer) |
| Media | YouTube, Gallery, Camera, Music player, Cloud Music (SoundCloud), Voice Recorder, Paint |
| Internet | Browser, Maps (OpenStreetMap), Weather (live, Open-Meteo) |
| Games | Snake, plus 2048 and Tic-Tac-Toe from the Store |
| Tools | Converter (from the Store), any website you add as a web app |

Terminal commands: `help`, `ls`, `cd`, `cat`, `mkdir`, `touch`, `rm`, `mv`, `cp`, `echo > file`, `edit`, `open`, `apps`, `theme`, `mode`, `calc`, `notify`, `weather`, `neofetch`, `history`, `lock`, `reboot`, `shutdown`, `exit`.

## Keyboard shortcuts
| Keys | Action |
|---|---|
| `Ctrl+Shift+D` | Dark mode on/off |
| `Ctrl+Shift+E` | Exit OS / come back (toggle) |
| `Ctrl+K` | Search |
| `Ctrl+/` | Show all shortcuts |
| `Ctrl+Shift+M` | Next mode |
| `Ctrl+Shift+1 / 2 / 3` | Phone / Tablet / Laptop |
| `Ctrl+Shift+C` | Control Centre |
| `Ctrl+Shift+N` | Notifications |
| `Ctrl+Shift+A` | App switcher |
| `Ctrl+Shift+H` | Home |
| `Ctrl+Shift+Q` | Close app |
| `Ctrl+Shift+L` | Lock |
| `Ctrl+Shift+P` | Power menu |
| `Ctrl+Shift+↑ / ↓` | Volume |
| `Ctrl+Shift+← / →` | Brightness |
| `Alt+← / → / ↑ / ↓` | Snap left / right / maximise / minimise (laptop) |
| `Esc` | Close panel / back / unlock |

There's always a red **⏻ Exit** button in the status bar (and in the menu bar in Laptop mode). The corner buttons for **Dark mode**, **Mode** and **Exit** show on the home screen.

## Make your own app
Add this to `js/apps.js`:
```js
window.BV_APPS.push({
  id: "hello", name: "Hello", icon: "👋", bg: "#2f6bff", cat: "Other",
  render(body, os) { body.innerHTML = "<h2>Hi!</h2>"; os.notify({ app: "hello", icon: "👋", title: "Hi", text: "My app works" }); }
});
```
`os` gives your app access to `fs`, `store`, `idb`, `notify`, `toast`, `open`, `close`, `setMode`, `toggleDark` and more (see `js/os.js`).

## Files
```
web/                     the OS itself (also packed into the Android app)
  index.html, privacy.html, css/style.css
  js/lib.js              storage, file system, helpers
  js/android.js          Android integration (real apps, Play installs, home screen)
  js/accounts.js         Sign-in (Google, Microsoft, email), device linking, Google/Microsoft services
  js/apps-sim-ai.js      Digital SIM and Blockvile AI
  js/os.js               the shell: modes, windows, search, notifications, lock, power, shortcuts
  js/apps.js             system & productivity apps
  js/apps-media.js       media, internet & game apps
  js/apps-store.js       Play Store, Cloud Music, web apps, 2048, Tic-Tac-Toe, Converter
  js/apps-video.js       YouTube (and the Tube search page, web/tube.html)
blockvile-plus-os.html   the whole OS in one file (built from web/)
tools/build-single-file.py   rebuilds blockvile-plus-os.html after you edit web/
android/                 Android app project (Java, Gradle)
  app/src/main/java/…    MainActivity (full-screen OS + launcher) and AndroidBridge
.github/workflows/       cloud builds: Android APK/AAB, and the website on GitHub Pages
store-listing/           Google Play icon, feature graphic, screenshots, listing text
PLAY-STORE-GUIDE.md      step-by-step publishing guide
```

## Limits
- It can't be flashed onto a phone as firmware. The Android app runs as a normal app, or temporarily as your home screen while you choose.
- In the Android app, installs always go through Google Play, because Play's rules don't let apps install other apps by themselves.
- Wi-Fi and Bluetooth toggles are visual only.
- Alarms only ring while the page is open.
- Some websites refuse to load inside the built-in Browser. Use the ↗ button to open them in your real browser.
- YouTube needs internet. If you open `blockvile-plus-os.html` straight from your computer and a video shows an error, put the file on a website instead; YouTube sometimes refuses to play in pages opened from a file. The ↗ YouTube button always works.
- Some videos can't be embedded, because their owners turned that off. Use ↗ YouTube for those.
- Cloud Music needs internet. Searching happens on SoundCloud's website, because searching inside the app would need a SoundCloud developer key.
- The PIN only protects the OS screen. It is not strong security.
