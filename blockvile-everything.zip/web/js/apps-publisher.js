/* Blockvile Plus OS — Publisher app.
   The app IS your Publisher Pad (publisher.html, the exact page you made: zip upload, add/remove files, many coding languages, Netlify, GitHub Pages, instant links)
   plus extra places to publish: the Game Center (game or app), the Blockvile Browser, and a browser-extension zip.
   Your Blockvile login is handed to it, so there is no second login. Approving what people send is in Shop & Quests -> Review. */
(() => {
  const A = window.BV_APPS;
  const decodeB64 = t => new TextDecoder().decode(Uint8Array.from(atob(t.trim()), c => c.charCodeAt(0)));
  // give the page the OS login (access token only: the OS keeps refreshing it, so the two never fight over the refresh token)
  const pass = () => {
    try {
      const s = window.BV.auth?.session;
      if (s?.access_token) localStorage.setItem("launchpad-session", JSON.stringify({ access_token: s.access_token, refresh_token: "", email: s.user?.email || "", fromOS: true }));
      else { const cur = JSON.parse(localStorage.getItem("launchpad-session") || "null"); if (cur?.fromOS) localStorage.removeItem("launchpad-session"); }
    } catch { }
  };
  A.push({
    id: "publisher", name: "Blockvile Publisher", icon: "🚀", bg: "linear-gradient(135deg,#0d7152,#3cc497)", cat: "Create", dock: true, size: [1100, 720], net: true,
    keywords: "publisher pad publish upload zip github netlify files code project extension game center browser app instant link",
    render(body, os) {
      body.style.padding = "0"; body.style.overflow = "hidden";
      pass();
      const onAuth = () => { if (!body.isConnected) return window.removeEventListener("bv:auth", onAuth); pass(); };
      window.addEventListener("bv:auth", onAuth);
      body.innerHTML = `<iframe data-pub title="Blockvile Publisher" style="width:100%;height:100%;border:0;background:#f1f3ef;display:block" allow="clipboard-write; fullscreen"
        sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-modals allow-downloads allow-pointer-lock allow-presentation"></iframe>`;
      const frame = body.querySelector("[data-pub]"), el = document.getElementById("bv-pub-src");
      let html = ""; if (el) { try { html = decodeB64(el.textContent); } catch { } }
      if (html) frame.srcdoc = html; else frame.src = "publisher.html";
      return () => window.removeEventListener("bv:auth", onAuth);
    }
  });
})();
