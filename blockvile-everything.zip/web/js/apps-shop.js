/* Blockvile Plus OS — Shop: Orbs, avatars, Quests, Friends (play together), Watch to earn, and Blockvile Plus.
   Everything is kept in your own Supabase (run supabase/blockvile-plus.sql once). Orbs are counted by the server, not the app, so they can't be faked. */
(() => {
  const { esc } = window.BV;
  const A = window.BV_APPS;
  const P = () => window.BV.profile;
  const ads = () => (window.BV_CONFIG || {}).ads || {};
  const gameName = id => (window.BV_GAMES || []).find(g => g.id === id)?.title || id;

  // a quiet check for game invites from friends while you're signed in
  let invPoll = null, seenInv = new Set();
  function startInvites() {
    if (invPoll) return;
    invPoll = setInterval(async () => {
      if (document.hidden || !P()?.data) return;
      try { const list = await P().rpc("bv_invites_in"); (list || []).forEach(i => { if (!seenInv.has(i.id)) { seenInv.add(i.id); window.BlockvileOS?.toast("👥 " + i.from + " invited you to play " + gameName(i.game) + " — open the Shop → Friends"); } }); } catch { }
    }, 45000);
  }
  window.addEventListener("bv:profile", () => { if (P()?.data) startInvites(); });

  A.push({
    id: "shop", name: "Shop & Quests", icon: "🛍️", bg: "linear-gradient(135deg,#ffb020,#ff5d8f)", cat: "Rewards", dock: true, size: [900, 680], net: true,
    keywords: "shop quests orbs avatar friends plus rewards watch earn store play together discord",
    render(body, os, args) {
      let tab = args?.tab || "shop", msg = "", busy = false, items = [], quests = [], prog = {}, friends = [], invites = [], countdown = 0, timer = null;
      body.style.padding = "0"; body.style.overflow = "auto";
      const prof = () => P()?.data;
      const say = (t, bad) => { msg = (bad ? "⚠️ " : "") + t; draw(); };
      const css = `<style>.sh{padding:12px;display:flex;flex-direction:column;gap:12px;font-size:14px}.sh .top{display:flex;align-items:center;gap:12px;flex-wrap:wrap}
      .sh .av{width:52px;height:52px;border-radius:16px;background:linear-gradient(135deg,#7a4dff,#ff4f9a);display:grid;place-items:center;font-size:30px}
      .sh .orbs{margin-left:auto;padding:8px 14px;border-radius:999px;background:rgba(255,176,32,.18);font-weight:700}.sh .tabs{display:flex;gap:6px;flex-wrap:wrap}
      .sh .tabs button[aria-pressed=true]{background:#7a4dff;color:#fff;border-color:#7a4dff}.sh .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px}
      .sh .it{border:1px solid var(--line,rgba(120,120,140,.3));border-radius:14px;padding:12px;text-align:center;background:var(--card,rgba(120,120,140,.08))}.sh .it .e{font-size:40px}
      .sh .qrow{display:flex;gap:10px;align-items:center;padding:10px;border:1px solid var(--line,rgba(120,120,140,.3));border-radius:12px;margin-bottom:8px;background:var(--card,rgba(120,120,140,.08));flex-wrap:wrap}
      .sh .bar{height:8px;border-radius:6px;background:rgba(120,120,140,.25);overflow:hidden;margin-top:6px}.sh .bar i{display:block;height:100%;background:linear-gradient(90deg,#7a4dff,#ff4f9a)}
      .sh .note{padding:8px 10px;border-radius:8px;background:rgba(122,107,255,.15)}.sh input.f{border-radius:8px;border:1px solid var(--line,rgba(120,120,140,.3));background:rgba(0,0,0,.12);color:inherit;padding:8px;font:inherit;min-width:0}
      .sh .plus{background:linear-gradient(135deg,rgba(255,176,32,.25),rgba(255,79,143,.25));border-radius:16px;padding:16px}.sh h3{margin:0 0 8px}</style>`;

      async function loadAll() {
        if (!prof()) return;
        try { const c = await window.BV.auth.client();
          const [it, qs, pr] = await Promise.all([c.from("bv_shop_items").select("*").order("sort"), c.from("bv_quests").select("*").order("sort"), c.from("bv_quest_progress").select("quest_id,seconds,claimed").eq("day", new Date().toISOString().slice(0, 10))]);
          items = it.data || []; quests = qs.data || []; prog = {}; (pr.data || []).forEach(r => prog[r.quest_id] = r);
          if (tab === "friends") { friends = (await P().rpc("bv_friend_list")) || []; invites = (await P().rpc("bv_invites_in")) || []; }
        } catch (e) { msg = "⚠️ The Shop isn't set up yet. Run supabase/blockvile-plus.sql in your Supabase SQL Editor."; }
        draw();
      }
      const refresh = async () => { await P().load(); await loadAll(); };

      const head = () => `<div class="top"><div class="av">${esc(prof().avatar || "🙂")}</div><div><b>${esc(prof().username || "Choose a username")}</b> ${prof().plus ? `<span title="Blockvile Plus">⭐ Plus</span>` : ""}<br><button class="btn ghost" data-a="username" style="padding:2px 8px;font-size:12px">${prof().username ? "Change name" : "Set username"}</button></div><div class="orbs">🔮 ${prof().orbs} Orbs</div></div>
        <div class="tabs">${[["shop", "🛍 Shop"], ["quests", "🎯 Quests"], ["friends", "👥 Friends"], ["watch", "📺 Watch & earn"], ["plus", "⭐ Plus"]].map(([k, n]) => `<button class="btn ghost" data-tab="${k}" aria-pressed="${k === tab}">${n}</button>`).join("")}</div>`;

      const shopV = () => `<h3>Avatars</h3><div class="grid">${items.map(i => { const own = (prof().owned || []).includes(i.id), on = prof().avatar === i.emoji;
        return `<div class="it"><div class="e">${esc(i.emoji)}</div><b>${esc(i.name)}</b><br>${i.plus_only ? `<small>⭐ Plus only</small><br>` : ""}${own ? `<button class="btn ${on ? "" : "ghost"}" data-equip="${esc(i.id)}" ${on ? "disabled" : ""}>${on ? "Wearing" : "Wear"}</button>` : `<button class="btn" data-buy="${esc(i.id)}" ${busy ? "disabled" : ""}>${i.plus_only && !i.price ? "Unlock with Plus" : "🔮 " + i.price}</button>`}</div>`; }).join("") || `<p class="muted">Nothing for sale yet.</p>`}</div>
        <p class="muted" style="font-size:12px">Earn Orbs from Quests and by watching. New items appear here when the owner adds them.</p>`;

      const questV = () => `<h3>Daily quests</h3><p class="muted" style="margin:0 0 10px;font-size:13px">Play games in Blockvile's Game Center to fill each bar, then claim your Orbs. They reset every day.${prof().plus ? " ⭐ Plus pays double." : ""}</p>` + (quests.map(q => {
        const pr = prog[q.id] || { seconds: 0, claimed: false }, need = q.minutes * 60, pct = q.kind === "friends" ? (pr.claimed ? 100 : 0) : Math.min(100, Math.round(pr.seconds / need * 100)), done = pct >= 100 && !pr.claimed;
        return `<div class="qrow"><span style="font-size:28px">${esc(q.icon)}</span><div style="flex:1;min-width:150px"><b>${esc(q.title)}</b> <small class="muted">🔮 ${q.reward * (prof().plus ? 2 : 1)}</small><br><small class="muted">${esc(q.description)}</small><div class="bar"><i style="width:${pct}%"></i></div></div>
          ${pr.claimed ? `<span class="muted">✔ Claimed</span>` : q.kind === "play" ? `<button class="btn ${pct >= 100 ? "" : "ghost"}" data-claim="${esc(q.id)}">${pct >= 100 ? "Claim" : Math.floor(pr.seconds / 60) + "/" + q.minutes + " min"}</button><button class="btn ghost" data-play="${esc(q.game_id || "")}">Play</button>` : `<button class="btn" data-claim="${esc(q.id)}">Claim</button><button class="btn ghost" data-tab="friends">Friends</button>`}</div>`; }).join("") || `<p class="muted">No quests right now.</p>`)
        + `<p class="muted" style="font-size:12px">Quests only count games played inside Blockvile. Games on other platforms (like Steam or Epic) can't be seen from here.</p>`;

      const friendsV = () => `<h3>Friends</h3><div class="top" style="margin-bottom:8px"><input class="f" data-c="fname" placeholder="Friend's username" maxlength="20" style="flex:1"><button class="btn" data-a="addfriend">Send request</button></div>
        ${invites.length ? `<h3>Invites for you</h3>` + invites.map(i => `<div class="qrow"><span style="font-size:26px">${esc(i.avatar)}</span><div style="flex:1"><b>${esc(i.from)}</b> invited you to play <b>${esc(gameName(i.game))}</b></div><button class="btn" data-join="${i.id}" data-g="${esc(i.game)}">Join</button><button class="btn ghost" data-decline="${i.id}">No thanks</button></div>`).join("") : ""}
        ${friends.filter(f => f.status === "pending" && f.incoming).map(f => `<div class="qrow"><span style="font-size:26px">${esc(f.avatar)}</span><div style="flex:1"><b>${esc(f.username || "player")}</b> wants to be friends</div><button class="btn" data-fr="${f.rel}" data-ok="1">Accept</button><button class="btn ghost" data-fr="${f.rel}">Decline</button></div>`).join("")}
        ${friends.filter(f => f.status === "accepted").map(f => `<div class="qrow"><span style="font-size:26px">${esc(f.avatar)}</span><div style="flex:1"><b>${esc(f.username || "player")}</b><br><small class="muted">${f.online ? "🟢 Online" : "⚪ Offline"}</small></div>
          <select class="f" data-g2="${esc(f.uid)}">${(window.BV_GAMES || []).filter(g => g.multi || g.feat).map(g => `<option value="${esc(g.id)}">${esc(g.title)}</option>`).join("")}</select><button class="btn" data-inv="${esc(f.uid)}">Invite to play</button><button class="btn ghost" data-unf="${f.rel}">✕</button></div>`).join("") || `<p class="muted">No friends yet. Ask a friend for their username and send a request.</p>`}
        ${friends.filter(f => f.status === "pending" && !f.incoming).map(f => `<p class="muted">⏳ Waiting for ${esc(f.username || "player")} to accept</p>`).join("")}
        <p class="muted" style="font-size:12px">Invite a friend and when they press Join, you both open the game. Finish the "Better together" quest for Orbs.</p>`;

      const watchV = () => { const on = ads().enabled;
        return `<h3>Watch & earn</h3>` + (on ? `<p>Watch a short ad to earn <b>🔮 ${prof().plus ? 10 : 5}</b> Orbs. Up to 6 a day.</p><div class="it" style="min-height:120px" data-c="adslot">${ads().client ? `<ins class="adsbygoogle" style="display:block" data-ad-client="${esc(ads().client)}" data-ad-slot="${esc(ads().slot || "")}" data-ad-format="auto"></ins>` : `<p class="muted">Ad appears here</p>`}</div>
          <div class="top" style="margin-top:10px"><button class="btn" data-a="watch" ${countdown || busy ? "disabled" : ""}>${countdown ? "Keep watching… " + countdown + "s" : "▶ Watch an ad"}</button></div>`
          : `<div class="note">📺 Watch-to-earn is built and ready, but ads are <b>not switched on yet</b>. When the ad account is set up (the money setup comes later), this tab starts showing ads and giving Orbs.</div>`); };

      const plusV = () => `<div class="plus"><h3>⭐ Blockvile Plus</h3><ul style="margin:0 0 10px;padding-left:20px"><li>Double Orbs from every quest and ad</li><li>Plus-only avatars in the Shop</li><li>⭐ badge next to your name</li></ul>
        ${prof().plus ? `<b>✔ You have Blockvile Plus.</b>` : `<button class="btn" disabled>Get Plus — coming soon</button><p class="muted" style="font-size:12px;margin:8px 0 0">Payments aren't switched on yet. For now the owner can give Plus to anyone.</p>`}</div>`;

      function draw() {
        if (!window.BV.auth?.signedIn?.()) { body.innerHTML = css + `<div class="sh"><div class="note">Sign in to earn Orbs, finish quests and buy avatars.</div><button class="btn" data-a="signin" style="align-self:flex-start">Open Accounts</button></div>`; return; }
        if (!prof()) { body.innerHTML = css + `<div class="sh"><div class="note">${msg || "Loading…"}</div></div>`; return; }
        body.innerHTML = css + `<div class="sh">${head()}${msg ? `<div class="note">${esc(msg)}</div>` : ""}${tab === "shop" ? shopV() : tab === "quests" ? questV() : tab === "friends" ? friendsV() : tab === "watch" ? watchV() : plusV()}</div>`;
      }
      const act = async (fn, okMsg) => { busy = true; try { const r = await fn(); busy = false; if (typeof r === "string" && r !== "ok" && !r.startsWith("ok:")) { say(r === "suspended" ? "Your account is suspended." : r, true); return r; } msg = okMsg ? okMsg(r) : ""; await refresh(); return r; } catch (e) { busy = false; say("Something went wrong: " + String(e.message || e), true); } };

      body.addEventListener("click", async e => {
        const t = e.target, g = s => t.closest(s);
        if (g("[data-tab]")) { tab = g("[data-tab]").dataset.tab; msg = ""; draw(); if (tab !== "shop") loadAll(); return; }
        const a = g("[data-a]")?.dataset.a;
        if (a === "signin") return os.open("accounts");
        if (a === "username") { const n = await window.BV.ask("Choose a username (3–20 letters, numbers or _)", prof().username || ""); if (n) act(() => P().rpc("bv_set_username", { u: n }), () => "Username saved"); return; }
        if (g("[data-buy]")) return act(() => P().rpc("bv_buy", { item: g("[data-buy]").dataset.buy }), () => "Bought! Now press Wear.");
        if (g("[data-equip]")) return act(() => P().rpc("bv_equip", { item: g("[data-equip]").dataset.equip }), () => "Avatar changed");
        if (g("[data-claim]")) return act(() => P().rpc("bv_quest_claim", { qid: g("[data-claim]").dataset.claim }), r => "🎉 +" + String(r).split(":")[1] + " Orbs!");
        if (g("[data-play]")) { const id = g("[data-play]").dataset.play; return id && window.BV.gcGoto ? window.BV.gcGoto(id) : os.open("gamecenter"); }
        if (a === "addfriend") { const n = body.querySelector("[data-c=fname]").value.trim(); if (n) act(() => P().rpc("bv_friend_request", { u: n }), () => "Request sent to " + n); return; }
        if (g("[data-fr]")) return act(() => P().rpc("bv_friend_respond", { rel: +g("[data-fr]").dataset.fr, accept: !!g("[data-fr]").dataset.ok }), () => "Done");
        if (g("[data-unf]")) { if (await window.BV.confirm("Remove this friend?", { ok: "Remove", danger: true })) act(() => P().rpc("bv_unfriend", { rel: +g("[data-unf]").dataset.unf })); return; }
        if (g("[data-inv]")) { const uid = g("[data-inv]").dataset.inv, game = body.querySelector(`[data-g2="${uid}"]`).value; const r = await act(() => P().rpc("bv_invite", { friend: uid, game }), () => "Invite sent! Open the game and wait for them."); if (r === "ok" && window.BV.gcGoto) window.BV.gcGoto(game); return; }
        if (g("[data-join]")) { const id = g("[data-join]").dataset.join, game = g("[data-join]").dataset.g; await act(() => P().rpc("bv_invite_respond", { inv: +id, join_it: true }), () => "Joining…"); if (window.BV.gcGoto) window.BV.gcGoto(game); return; }
        if (g("[data-decline]")) return act(() => P().rpc("bv_invite_respond", { inv: +g("[data-decline]").dataset.decline, join_it: false }));
        if (a === "watch") {
          countdown = 30; draw(); try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch { }
          timer = setInterval(async () => { countdown--; if (countdown > 0) { draw(); return; } clearInterval(timer); timer = null; countdown = 0; act(() => P().rpc("bv_ad_claim"), r => "🎉 +" + String(r).split(":")[1] + " Orbs for watching!"); }, 1000);
        }
      });
      const onP = () => { if (!body.isConnected) { window.removeEventListener("bv:profile", onP); window.removeEventListener("bv:quests", onQ); return; } draw(); if (prof() && !items.length) loadAll(); };
      const onQ = () => { if (body.isConnected && tab === "quests") loadAll(); };
      window.addEventListener("bv:profile", onP); window.addEventListener("bv:quests", onQ);
      if (ads().enabled && ads().client && !document.getElementById("bv-adsense")) { const s = document.createElement("script"); s.id = "bv-adsense"; s.async = true; s.crossOrigin = "anonymous"; s.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=" + encodeURIComponent(ads().client); document.head.appendChild(s); }
      draw(); if (window.BV.auth?.signedIn?.()) { P().load().then(() => loadAll()); }
      return () => { if (timer) clearInterval(timer); };
    }
  });
})();
