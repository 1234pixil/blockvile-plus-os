/* Blockvile Plus OS — Shop: Orbs, avatars, Quests, Friends (play together), Watch to earn, and Blockvile Plus.
   Everything is kept in your own Supabase (run supabase/blockvile-plus.sql once). Orbs are counted by the server, not the app, so they can't be faked. */
(() => {
  const { esc } = window.BV;
  const A = window.BV_APPS;
  const P = () => window.BV.profile;
  const ads = () => (window.BV_CONFIG || {}).ads || {};
  const gameName = id => (window.BV_GAMES || []).find(g => g.id === id)?.title || id;

  // a quiet check for game invites from friends while you're signed in
  let invPoll = null, seenInv = new Set();
  function startInvites() {
    if (invPoll) return;
    invPoll = setInterval(async () => {
      if (document.hidden || !P()?.data) return;
      try { const list = await P().rpc("bv_invites_in"); (list || []).forEach(i => { if (!seenInv.has(i.id)) { seenInv.add(i.id); window.BlockvileOS?.toast("👥 " + i.from + " invited you to play " + gameName(i.game) + " — open the Shop → Friends"); } }); } catch { }
    }, 45000);
  }
  window.addEventListener("bv:profile", () => { if (P()?.data) startInvites(); });

  A.push({
    id: "shop", name: "Shop & Quests", icon: "🛍️", bg: "linear-gradient(135deg,#ffb020,#ff5d8f)", cat: "Rewards", dock: true, size: [900, 680], net: true,
    keywords: "shop quests orbs avatar friends plus rewards watch earn store play together discord",
    render(body, os, args) {
      let tab = args?.tab || "shop", msg = "", busy = false, items = [], quests = [], prog = {}, friends = [], invites = [], countdown = 0, timer = null, market = [], sale = null, mine = [], pending = [], isAdmin = false, form = { kind: "avatar2d", name: "", price: 50, img: null, thumb: null, model: null, fname: "" };
      body.style.padding = "0"; body.style.overflow = "auto";
      const prof = () => P()?.data;
      const say = (t, bad) => { msg = (bad ? "⚠️ " : "") + t; draw(); };
      const css = `<style>.sh{padding:12px;display:flex;flex-direction:column;gap:12px;font-size:14px}.sh .top{display:flex;align-items:center;gap:12px;flex-wrap:wrap}
      .sh .av{width:52px;height:52px;border-radius:16px;background:linear-gradient(135deg,#7a4dff,#ff4f9a);display:grid;place-items:center;font-size:30px}
      .sh .orbs{margin-left:auto;padding:8px 14px;border-radius:999px;background:rgba(255,176,32,.18);font-weight:700}.sh .tabs{display:flex;gap:6px;flex-wrap:wrap}
      .sh .tabs button[aria-pressed=true]{background:#7a4dff;color:#fff;border-color:#7a4dff}.sh .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px}
      .sh .it{border:1px solid var(--line,rgba(120,120,140,.3));border-radius:14px;padding:12px;text-align:center;background:var(--card,rgba(120,120,140,.08))}.sh .it .e{font-size:40px}
      .sh .qrow{display:flex;gap:10px;align-items:center;padding:10px;border:1px solid var(--line,rgba(120,120,140,.3));border-radius:12px;margin-bottom:8px;background:var(--card,rgba(120,120,140,.08));flex-wrap:wrap}
      .sh .bar{height:8px;border-radius:6px;background:rgba(120,120,140,.25);overflow:hidden;margin-top:6px}.sh .bar i{display:block;height:100%;background:linear-gradient(90deg,#7a4dff,#ff4f9a)}
      .sh .note{padding:8px 10px;border-radius:8px;background:rgba(122,107,255,.15)}.sh input.f{border-radius:8px;border:1px solid var(--line,rgba(120,120,140,.3));background:rgba(0,0,0,.12);color:inherit;padding:8px;font:inherit;min-width:0}
      .sh .plus{background:linear-gradient(135deg,rgba(255,176,32,.25),rgba(255,79,143,.25));border-radius:16px;padding:16px}.sh h3{margin:0 0 8px}.sh .av img{width:100%;height:100%;object-fit:cover;border-radius:16px}.sh .it .e img{width:64px;height:64px;object-fit:cover;border-radius:12px}.sh s{opacity:.55}.sh .sale{padding:10px 14px;border-radius:12px;background:linear-gradient(90deg,#ff4f9a,#ffb020);color:#111;font-weight:700}.sh .modal{position:fixed;inset:0;background:rgba(0,0,0,.6);display:grid;place-items:center;z-index:5}.sh .modal>div{background:var(--bg,#1b1433);border-radius:16px;padding:12px;width:min(420px,92vw)}</style>`;

      async function loadAll() {
        if (!prof()) return;
        try { const c = await window.BV.auth.client();
          const [it, qs, pr] = await Promise.all([c.from("bv_shop_items").select("*").order("sort"), c.from("bv_quests").select("*").order("sort"), c.from("bv_quest_progress").select("quest_id,seconds,claimed").eq("day", new Date().toISOString().slice(0, 10))]);
          items = it.data || []; quests = qs.data || []; prog = {}; (pr.data || []).forEach(r => prog[r.quest_id] = r);
          try { sale = await P().rpc("bv_sale"); market = (await P().rpc("bv_market")) || [];
            const mm = await c.from("bv_creations").select("id,kind,name,price,discount_pct,discount_until,thumb,approved,sales,earned").order("created_at", { ascending: false }); mine = mm.data || [];
            const ad = await c.from("gc_admins").select("user_id").eq("user_id", window.BV.auth.user.id).maybeSingle(); isAdmin = !!ad.data;
            if (isAdmin) pending = (await P().rpc("bv_creations_pending")) || []; } catch { /* costume tables not added yet */ }
          if (tab === "friends") { friends = (await P().rpc("bv_friend_list")) || []; invites = (await P().rpc("bv_invites_in")) || []; }
        } catch (e) { msg = "⚠️ The Shop isn't set up yet. Run supabase/blockvile-plus.sql in your Supabase SQL Editor."; }
        draw();
      }
      const refresh = async () => { await P().load(); await loadAll(); };

      const head = () => `<div class="top"><div class="av" ${prof().ref ? `data-a="wear3d" style="cursor:pointer" title="${prof().ref_kind === "avatar3d" ? "Tap to see your 3D avatar" : ""}"` : ""}>${prof().ref_img ? `<img src="${esc(prof().ref_img)}" alt="">` : esc(prof().avatar || "🙂")}</div><div><b>${esc(prof().username || "Choose a username")}</b> ${prof().plus ? `<span title="Blockvile Plus">⭐ Plus</span>` : ""}<br><button class="btn ghost" data-a="username" style="padding:2px 8px;font-size:12px">${prof().username ? "Change name" : "Set username"}</button></div><div class="orbs">🔮 ${prof().orbs} Orbs</div></div>
        <div class="tabs">${[["shop", "🛍 Shop"], ["quests", "🎯 Quests"], ["friends", "👥 Friends"], ["create", "🎨 Create"], ["watch", "📺 Watch & earn"], ["plus", "⭐ Plus"]].concat(isAdmin ? [["review", "🛡 Review" + (pending.length ? " (" + pending.length + ")" : "")]] : []).map(([k, n]) => `<button class="btn ghost" data-tab="${k}" aria-pressed="${k === tab}">${n}</button>`).join("")}</div>`;

      let pct = 0; const price = n => pct ? `<s>🔮 ${n}</s> 🔮 ${Math.ceil(n * (100 - pct) / 100)}` : "🔮 " + n;
      const mprice = m => m.pct ? `<s>🔮 ${m.price}</s> 🔮 ${Math.ceil(m.price * (100 - m.pct) / 100)} <small>(-${m.pct}%)</small>` : m.price ? "🔮 " + m.price : "Free";
      const thumbOf = m => m.thumb ? `<img src="${esc(m.thumb)}" alt="">` : (m.kind === "avatar3d" ? "🧊" : "🖼️");
      const marketV = () => `<h3 style="margin-top:16px">Community costumes <small class="muted">made by Blockvile Plus members</small></h3><div class="grid">${market.map(m => `<div class="it"><div class="e">${thumbOf(m)}</div><b>${esc(m.name)}</b><br><small class="muted">${m.kind === "avatar3d" ? "3D" : "2D"} · by ${esc(m.creator)}</small><br>${m.owned ? `<button class="btn" data-wearc="${m.id}">${prof().ref === m.id ? "Wearing" : "Wear"}</button>${m.kind === "avatar3d" ? `<button class="btn ghost" data-view3d="${m.id}">View 3D</button>` : ""}` : `<div style="margin:4px 0">${mprice(m)}</div><button class="btn" data-buyc="${m.id}">Buy</button>`}</div>`).join("") || `<p class="muted">No costumes yet. Plus members can make the first ones in the 🎨 Create tab.</p>`}</div>`;
      const shopV = () => (pct ? `<div class="sale">🔥 ${esc(sale.title)}: ${pct}% off everything! Ends ${new Date(sale.ends).toLocaleDateString()}</div>` : "") + `<h3>Avatars</h3><div class="grid">${items.map(i => { const own = (prof().owned || []).includes(i.id), on = prof().avatar === i.emoji;
        return `<div class="it"><div class="e">${esc(i.emoji)}</div><b>${esc(i.name)}</b><br>${i.plus_only ? `<small>⭐ Plus only</small><br>` : ""}${own ? `<button class="btn ${on ? "" : "ghost"}" data-equip="${esc(i.id)}" ${on ? "disabled" : ""}>${on ? "Wearing" : "Wear"}</button>` : `<button class="btn" data-buy="${esc(i.id)}" ${busy ? "disabled" : ""}>${i.plus_only && !i.price ? "Unlock with Plus" : price(i.price)}</button>`}</div>`; }).join("") || `<p class="muted">Nothing for sale yet.</p>`}</div>
        <p class="muted" style="font-size:12px">Earn Orbs from Quests and by watching. New items appear here when the owner adds them.</p>` + marketV();

      const questV = () => `<h3>Daily quests</h3><p class="muted" style="margin:0 0 10px;font-size:13px">Play games in Blockvile's Game Center to fill each bar, then claim your Orbs. They reset every day.${prof().plus ? " ⭐ Plus pays double." : ""}</p>` + (quests.map(q => {
        const pr = prog[q.id] || { seconds: 0, claimed: false }, need = q.minutes * 60, pct = q.kind === "friends" ? (pr.claimed ? 100 : 0) : Math.min(100, Math.round(pr.seconds / need * 100)), done = pct >= 100 && !pr.claimed;
        return `<div class="qrow"><span style="font-size:28px">${esc(q.icon)}</span><div style="flex:1;min-width:150px"><b>${esc(q.title)}</b> <small class="muted">🔮 ${q.reward * (prof().plus ? 2 : 1)}</small><br><small class="muted">${esc(q.description)}</small><div class="bar"><i style="width:${pct}%"></i></div></div>
          ${pr.claimed ? `<span class="muted">✔ Claimed</span>` : q.kind === "play" ? `<button class="btn ${pct >= 100 ? "" : "ghost"}" data-claim="${esc(q.id)}">${pct >= 100 ? "Claim" : Math.floor(pr.seconds / 60) + "/" + q.minutes + " min"}</button><button class="btn ghost" data-play="${esc(q.game_id || "")}">Play</button>` : `<button class="btn" data-claim="${esc(q.id)}">Claim</button><button class="btn ghost" data-tab="friends">Friends</button>`}</div>`; }).join("") || `<p class="muted">No quests right now.</p>`)
        + `<p class="muted" style="font-size:12px">Quests only count games played inside Blockvile. Games on other platforms (like Steam or Epic) can't be seen from here.</p>`;

      const friendsV = () => `<h3>Friends</h3><div class="top" style="margin-bottom:8px"><input class="f" data-c="fname" placeholder="Friend's username" maxlength="20" style="flex:1"><button class="btn" data-a="addfriend">Send request</button></div>
        ${invites.length ? `<h3>Invites for you</h3>` + invites.map(i => `<div class="qrow"><span style="font-size:26px">${esc(i.avatar)}</span><div style="flex:1"><b>${esc(i.from)}</b> invited you to play <b>${esc(gameName(i.game))}</b></div><button class="btn" data-join="${i.id}" data-g="${esc(i.game)}">Join</button><button class="btn ghost" data-decline="${i.id}">No thanks</button></div>`).join("") : ""}
        ${friends.filter(f => f.status === "pending" && f.incoming).map(f => `<div class="qrow"><span style="font-size:26px">${esc(f.avatar)}</span><div style="flex:1"><b>${esc(f.username || "player")}</b> wants to be friends</div><button class="btn" data-fr="${f.rel}" data-ok="1">Accept</button><button class="btn ghost" data-fr="${f.rel}">Decline</button></div>`).join("")}
        ${friends.filter(f => f.status === "accepted").map(f => `<div class="qrow"><span style="font-size:26px">${esc(f.avatar)}</span><div style="flex:1"><b>${esc(f.username || "player")}</b><br><small class="muted">${f.online ? "🟢 Online" : "⚪ Offline"}</small></div>
          <select class="f" data-g2="${esc(f.uid)}">${(window.BV_GAMES || []).filter(g => g.multi || g.feat).map(g => `<option value="${esc(g.id)}">${esc(g.title)}</option>`).join("")}</select><button class="btn" data-inv="${esc(f.uid)}">Invite to play</button><button class="btn ghost" data-unf="${f.rel}">✕</button></div>`).join("") || `<p class="muted">No friends yet. Ask a friend for their username and send a request.</p>`}
        ${friends.filter(f => f.status === "pending" && !f.incoming).map(f => `<p class="muted">⏳ Waiting for ${esc(f.username || "player")} to accept</p>`).join("")}
        <p class="muted" style="font-size:12px">Invite a friend and when they press Join, you both open the game. Finish the "Better together" quest for Orbs.</p>`;

      const createV = () => { if (!prof().plus) return `<div class="plus"><h3>🎨 Make your own costumes</h3><p>Blockvile Plus members can upload their own <b>pictures, GIFs and custom emojis</b> or a <b>3D avatar (.glb file)</b>, wear them on their profile, and sell them for Orbs (you keep 70%).</p><button class="btn" data-tab="plus">See Plus</button></div>`;
        return `<h3>Make a costume</h3><div class="qrow" style="display:block"><div class="top" style="margin-bottom:8px"><select class="f" data-f="kind"><option value="avatar2d" ${form.kind === "avatar2d" ? "selected" : ""}>2D picture / GIF / emoji</option><option value="avatar3d" ${form.kind === "avatar3d" ? "selected" : ""}>3D avatar (.glb)</option></select>
          <input class="f" data-f="name" placeholder="Name" maxlength="30" value="${esc(form.name)}" style="flex:1;min-width:120px"><input class="f" data-f="price" type="number" min="0" max="5000" value="${form.price}" style="width:90px" title="Price in Orbs (0 = free)"><span class="muted">Orbs</span></div>
          <div class="top"><button class="btn ghost" data-a="pickimg">${form.kind === "avatar2d" ? "🖼 Choose picture / GIF" : "🖼 Preview picture (optional)"}</button>${form.kind === "avatar3d" ? `<button class="btn ghost" data-a="pickmodel">🧊 Choose .glb file</button>` : ""}<small class="muted">${esc(form.fname || (form.kind === "avatar2d" ? "PNG, JPG, GIF or WebP under 250 KB" : ".glb under 2.5 MB"))}</small></div>
          <input type="file" data-in="img" accept="image/png,image/jpeg,image/gif,image/webp" hidden><input type="file" data-in="model" accept=".glb,model/gltf-binary" hidden>
          ${form.thumb ? `<div style="margin:8px 0"><img src="${esc(form.thumb)}" style="width:72px;height:72px;object-fit:cover;border-radius:12px" alt=""></div>` : ""}
          <button class="btn" data-a="submitc" ${busy ? "disabled" : ""}>Send for approval</button> <small class="muted">Everyone else sees it once the owner approves it.</small></div>
          <h3 style="margin-top:14px">My costumes</h3>` + (mine.map(m => `<div class="qrow"><span style="font-size:28px">${m.thumb ? `<img src="${esc(m.thumb)}" style="width:44px;height:44px;object-fit:cover;border-radius:10px" alt="">` : m.kind === "avatar3d" ? "🧊" : "🖼️"}</span><div style="flex:1;min-width:140px"><b>${esc(m.name)}</b> <small class="muted">${m.kind === "avatar3d" ? "3D" : "2D"} · 🔮 ${m.price}${m.discount_pct ? ` · -${m.discount_pct}%` : ""}</small><br><small class="muted">${m.approved ? "✔ Approved · " + m.sales + " sold · earned 🔮 " + m.earned : "⏳ Waiting for approval"}</small></div>
          <button class="btn ghost" data-wearc="${m.id}">Wear</button>${m.approved ? `<button class="btn ghost" data-disc="${m.id}">Discount</button>` : ""}<button class="btn ghost" data-delc="${m.id}">Delete</button></div>`).join("") || `<p class="muted">Nothing yet.</p>`); };
      const reviewV = () => `<h3>Costumes waiting for approval</h3>` + (pending.map(m => `<div class="qrow"><span style="font-size:28px">${m.thumb ? `<img src="${esc(m.thumb)}" style="width:48px;height:48px;object-fit:cover;border-radius:10px" alt="">` : m.kind === "avatar3d" ? "🧊" : "🖼️"}</span><div style="flex:1;min-width:140px"><b>${esc(m.name)}</b> <small class="muted">${m.kind === "avatar3d" ? "3D" : "2D"} by ${esc(m.creator)} · 🔮 ${m.price}</small></div><button class="btn ghost" data-prevc="${m.id}" data-k="${m.kind}">👁 Look</button><button class="btn" data-dec="${m.id}" data-ok="1">Approve</button><button class="btn ghost" data-dec="${m.id}">Reject</button></div>`).join("") || `<p class="muted">Nothing waiting.</p>`);
      const watchV = () => { const on = ads().enabled;
        return `<h3>Watch & earn</h3>` + (on ? `<p>Watch a short ad to earn <b>🔮 ${prof().plus ? 10 : 5}</b> Orbs. Up to 6 a day.</p><div class="it" style="min-height:120px" data-c="adslot">${ads().client ? `<ins class="adsbygoogle" style="display:block" data-ad-client="${esc(ads().client)}" data-ad-slot="${esc(ads().slot || "")}" data-ad-format="auto"></ins>` : `<p class="muted">Ad appears here</p>`}</div>
          <div class="top" style="margin-top:10px"><button class="btn" data-a="watch" ${countdown || busy ? "disabled" : ""}>${countdown ? "Keep watching… " + countdown + "s" : "▶ Watch an ad"}</button></div>`
          : `<div class="note">📺 Watch-to-earn is built and ready, but ads are <b>not switched on yet</b>. When the ad account is set up (the money setup comes later), this tab starts showing ads and giving Orbs.</div>`); };

      const plusV = () => `<div class="plus"><h3>⭐ Blockvile Plus</h3><ul style="margin:0 0 10px;padding-left:20px"><li>Double Orbs from every quest and ad</li><li>Plus-only avatars in the Shop</li><li>⭐ badge next to your name</li></ul>
        ${prof().plus ? `<b>✔ You have Blockvile Plus.</b>` : `<button class="btn" disabled>Get Plus — coming soon</button><p class="muted" style="font-size:12px;margin:8px 0 0">Payments aren't switched on yet. For now the owner can give Plus to anyone.</p>`}</div>`;

      let modal = "";
      function draw() {
        pct = sale && sale.percent ? sale.percent : 0;
        if (!window.BV.auth?.signedIn?.()) { body.innerHTML = css + `<div class="sh"><div class="note">Sign in to earn Orbs, finish quests and buy avatars.</div><button class="btn" data-a="signin" style="align-self:flex-start">Open Accounts</button></div>`; return; }
        if (!prof()) { body.innerHTML = css + `<div class="sh"><div class="note">${msg || "Loading…"}</div></div>`; return; }
        body.innerHTML = css + `<div class="sh">${head()}${msg ? `<div class="note">${esc(msg)}</div>` : ""}${tab === "shop" ? shopV() : tab === "quests" ? questV() : tab === "friends" ? friendsV() : tab === "watch" ? watchV() : tab === "create" ? createV() : tab === "review" ? reviewV() : plusV()}${modal}</div>`;
      }
      const act = async (fn, okMsg) => { busy = true; try { const r = await fn(); busy = false; if (typeof r === "string" && r !== "ok" && !r.startsWith("ok:")) { say(r === "suspended" ? "Your account is suspended." : r, true); return r; } msg = okMsg ? okMsg(r) : ""; await refresh(); return r; } catch (e) { busy = false; say("Something went wrong: " + String(e.message || e), true); } };

      /* ---- costumes: 3D viewer (loaded only when needed), file reading, thumbnails ---- */
      let mvP = null;
      const loadMV = () => mvP || (mvP = new Promise((res, rej) => {
        if (window.customElements?.get("model-viewer")) return res();
        const add = (src, next) => { const el = document.createElement("script"); el.src = src; el.onload = res; el.onerror = () => next ? next() : rej(new Error("3D viewer didn't load")); document.head.appendChild(el); };
        const emb = document.getElementById("bv-mv-lib");
        if (emb) { try { return add(URL.createObjectURL(new Blob([Uint8Array.from(atob(emb.textContent.trim()), c => c.charCodeAt(0))], { type: "text/javascript" })), () => add("js/vendor/model-viewer.js")); } catch { } }
        add("js/vendor/model-viewer.js");
      }));
      async function show3d(data, name) {
        modal = `<div class="modal" data-a="closemodal"><div data-keep><b>${esc(name || "3D avatar")}</b> <button class="btn ghost" data-a="closemodal" style="float:right">✕</button><p class="muted" data-c="mvmsg">Loading…</p><div data-c="mvbox"></div></div></div>`; draw();
        try { await loadMV(); const box = body.querySelector("[data-c=mvbox]"); if (!box) return; const mv = document.createElement("model-viewer"); mv.setAttribute("camera-controls", ""); mv.setAttribute("auto-rotate", ""); mv.setAttribute("shadow-intensity", "1"); mv.style.cssText = "width:100%;height:340px;background:rgba(120,120,140,.15);border-radius:12px"; mv.src = data; box.appendChild(mv); body.querySelector("[data-c=mvmsg]").textContent = "Drag to turn it around."; }
        catch (er) { const m = body.querySelector("[data-c=mvmsg]"); if (m) m.textContent = "Couldn't show the 3D model: " + (er.message || er); }
      }
      const readURL = f => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(new Error("Couldn't read that file")); r.readAsDataURL(f); });
      async function makeThumb(dataUrl) {
        return new Promise(res => { const im = new Image(); im.onload = () => { try { const c = document.createElement("canvas"), n = 128, sc = Math.min(1, n / Math.max(im.width, im.height)); c.width = Math.max(1, Math.round(im.width * sc)); c.height = Math.max(1, Math.round(im.height * sc)); c.getContext("2d").drawImage(im, 0, 0, c.width, c.height); let out = c.toDataURL("image/png"); if (out.length > 55000) out = c.toDataURL("image/jpeg", .8); res(out.length < 59000 ? out : null); } catch { res(null); } }; im.onerror = () => res(null); im.src = dataUrl; });
      }
      body.addEventListener("input", e => { const f = e.target.dataset?.f; if (!f) return; form[f] = f === "price" ? Math.max(0, Math.min(5000, parseInt(e.target.value || "0", 10) || 0)) : e.target.value; });
      body.addEventListener("change", async e => {
        const f = e.target.dataset?.f; if (f === "kind") { form.kind = e.target.value; form.img = form.thumb = form.model = null; form.fname = ""; draw(); return; }
        const inp = e.target.dataset?.in; if (!inp || !e.target.files?.[0]) return; const file = e.target.files[0]; e.target.value = "";
        try {
          if (inp === "img") { if (file.size > 250 * 1024) return say("That picture is over 250 KB. Make it smaller.", true); if (!/^image\/(png|jpeg|gif|webp)$/.test(file.type)) return say("Use a PNG, JPG, GIF or WebP picture.", true); form.img = await readURL(file); form.thumb = await makeThumb(form.img); form.fname = file.name; }
          if (inp === "model") { if (file.size > 2.5 * 1024 * 1024) return say("That 3D file is over 2.5 MB.", true); if (!/\.glb$/i.test(file.name)) return say("Use a .glb file.", true); form.model = (await readURL(file)).replace(/^data:[^;]*;/, "data:model/gltf-binary;"); form.fname = (form.fname ? form.fname + " + " : "") + file.name; }
          msg = ""; draw();
        } catch (er) { say(String(er.message || er), true); }
      });
      body.addEventListener("click", async e => {
        const t = e.target, g = s => t.closest(s);
        if (g("[data-a=closemodal]") && !(g("[data-keep]") && !t.closest("button"))) { modal = ""; draw(); return; }
        if (g("[data-keep]")) return;
        const a0 = g("[data-a]")?.dataset.a;
        if (a0 === "wear3d" && prof().ref_kind === "avatar3d") { const d = await P().rpc("bv_creation_data", { cid: prof().ref }); if (d?.model) show3d(d.model, d.name); return; }
        if (a0 === "pickimg") return body.querySelector("[data-in=img]").click();
        if (a0 === "pickmodel") return body.querySelector("[data-in=model]").click();
        if (a0 === "submitc") {
          if (form.name.trim().length < 2) return say("Give it a name first.", true);
          if (form.kind === "avatar2d" && !form.img) return say("Choose a picture first.", true);
          if (form.kind === "avatar3d" && !form.model) return say("Choose a .glb file first.", true);
          const r = await act(() => P().rpc("bv_create", { k: form.kind, nm: form.name.trim(), pr: form.price, th: form.thumb, img: form.kind === "avatar2d" ? form.img : null, mdl: form.kind === "avatar3d" ? form.model : null }), () => "Sent! It shows in the Shop once approved.");
          if (r === "ok") form = { kind: form.kind, name: "", price: 50, img: null, thumb: null, model: null, fname: "" }; return;
        }
        if (g("[data-buyc]")) return act(() => P().rpc("bv_buy_creation", { cid: g("[data-buyc]").dataset.buyc }), () => "Bought! Press Wear.");
        if (g("[data-wearc]")) return act(() => P().rpc("bv_equip_creation", { cid: g("[data-wearc]").dataset.wearc }), () => "You're wearing it");
        if (g("[data-view3d]")) { const d = await P().rpc("bv_creation_data", { cid: g("[data-view3d]").dataset.view3d }); if (d?.model) show3d(d.model, d.name); else say("Buy it to see it in 3D.", true); return; }
        if (g("[data-delc]")) { if (await window.BV.confirm("Delete this costume?", { ok: "Delete", danger: true })) act(() => P().rpc("bv_creation_delete", { cid: g("[data-delc]").dataset.delc }), () => "Deleted"); return; }
        if (g("[data-disc]")) { const n = await window.BV.ask("Discount percent (0 to 90, 0 removes it). It lasts 3 days.", "20"); if (n !== null && n !== undefined && n !== "") act(() => P().rpc("bv_creation_discount", { cid: g("[data-disc]").dataset.disc, pct: parseInt(n, 10) || 0, days: 3 }), () => "Discount set"); return; }
        if (g("[data-prevc]")) { const d = await P().rpc("bv_creation_data", { cid: g("[data-prevc]").dataset.prevc }); if (d?.kind === "avatar3d" && d.model) show3d(d.model, d.name); else if (d?.image) { modal = `<div class="modal" data-a="closemodal"><div data-keep><b>${esc(d.name)}</b> <button class="btn ghost" data-a="closemodal" style="float:right">✕</button><p><img src="${esc(d.image)}" style="max-width:100%;max-height:340px;border-radius:12px" alt=""></p></div></div>`; draw(); } return; }
        if (g("[data-dec]")) { const ok = !!g("[data-dec]").dataset.ok; return act(() => P().rpc("bv_creation_decide", { cid: g("[data-dec]").dataset.dec, ok }), () => ok ? "Approved" : "Rejected"); }
        if (g("[data-tab]")) { tab = g("[data-tab]").dataset.tab; msg = ""; draw(); if (tab !== "shop") loadAll(); return; }
        const a = g("[data-a]")?.dataset.a;
        if (a === "signin") return os.open("accounts");
        if (a === "username") { const n = await window.BV.ask("Choose a username (3–20 letters, numbers or _)", prof().username || ""); if (n) act(() => P().rpc("bv_set_username", { u: n }), () => "Username saved"); return; }
        if (g("[data-buy]")) return act(() => P().rpc("bv_buy", { item: g("[data-buy]").dataset.buy }), () => "Bought! Now press Wear.");
        if (g("[data-equip]")) return act(() => P().rpc("bv_equip", { item: g("[data-equip]").dataset.equip }), () => "Avatar changed");
        if (g("[data-claim]")) return act(() => P().rpc("bv_quest_claim", { qid: g("[data-claim]").dataset.claim }), r => "🎉 +" + String(r).split(":")[1] + " Orbs!");
        if (g("[data-play]")) { const id = g("[data-play]").dataset.play; return id && window.BV.gcGoto ? window.BV.gcGoto(id) : os.open("gamecenter"); }
        if (a === "addfriend") { const n = body.querySelector("[data-c=fname]").value.trim(); if (n) act(() => P().rpc("bv_friend_request", { u: n }), () => "Request sent to " + n); return; }
        if (g("[data-fr]")) return act(() => P().rpc("bv_friend_respond", { rel: +g("[data-fr]").dataset.fr, accept: !!g("[data-fr]").dataset.ok }), () => "Done");
        if (g("[data-unf]")) { if (await window.BV.confirm("Remove this friend?", { ok: "Remove", danger: true })) act(() => P().rpc("bv_unfriend", { rel: +g("[data-unf]").dataset.unf })); return; }
        if (g("[data-inv]")) { const uid = g("[data-inv]").dataset.inv, game = body.querySelector(`[data-g2="${uid}"]`).value; const r = await act(() => P().rpc("bv_invite", { friend: uid, game }), () => "Invite sent! Open the game and wait for them."); if (r === "ok" && window.BV.gcGoto) window.BV.gcGoto(game); return; }
        if (g("[data-join]")) { const id = g("[data-join]").dataset.join, game = g("[data-join]").dataset.g; await act(() => P().rpc("bv_invite_respond", { inv: +id, join_it: true }), () => "Joining…"); if (window.BV.gcGoto) window.BV.gcGoto(game); return; }
        if (g("[data-decline]")) return act(() => P().rpc("bv_invite_respond", { inv: +g("[data-decline]").dataset.decline, join_it: false }));
        if (a === "watch") {
          countdown = 30; draw(); try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch { }
          timer = setInterval(async () => { countdown--; if (countdown > 0) { draw(); return; } clearInterval(timer); timer = null; countdown = 0; act(() => P().rpc("bv_ad_claim"), r => "🎉 +" + String(r).split(":")[1] + " Orbs for watching!"); }, 1000);
        }
      });
      const onP = () => { if (!body.isConnected) { window.removeEventListener("bv:profile", onP); window.removeEventListener("bv:quests", onQ); return; } draw(); if (prof() && !items.length) loadAll(); };
      const onQ = () => { if (body.isConnected && tab === "quests") loadAll(); };
      window.addEventListener("bv:profile", onP); window.addEventListener("bv:quests", onQ);
      if (ads().enabled && ads().client && !document.getElementById("bv-adsense")) { const s = document.createElement("script"); s.id = "bv-adsense"; s.async = true; s.crossOrigin = "anonymous"; s.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=" + encodeURIComponent(ads().client); document.head.appendChild(s); }
      draw(); if (window.BV.auth?.signedIn?.()) { P().load().then(() => loadAll()); }
      return () => { if (timer) clearInterval(timer); };
    }
  });
})();
