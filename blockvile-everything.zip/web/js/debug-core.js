/* Blockvile Plus OS — Debug Center (collector). Loads first, so errors while Blockvile starts are caught too.
   It keeps the last 200 problems on this device (secrets are blanked out). Nothing leaves the device unless the person
   taps "Send to developer" or turns on "Share errors automatically" in the Debug Center app. */
(() => {
  const KEY = "bv:dbg", MAX = 200;
  let buf = []; try { buf = JSON.parse(localStorage.getItem(KEY) || "[]"); if (!Array.isArray(buf)) buf = []; } catch { buf = []; }
  const redact = s => String(s == null ? "" : s)
    .replace(/eyJ[\w-]{8,}\.[\w-]{8,}\.[\w-]{4,}/g, "[hidden]")
    .replace(/sb_(publishable|secret)_[\w-]+/g, "[hidden]")
    .replace(/AIza[\w-]{20,}/g, "[hidden]")
    .replace(/(access_token|refresh_token|provider_token|apikey|key|password|code|token)=[^&\s"']+/gi, "$1=[hidden]")
    .replace(/\b[A-Za-z0-9_-]{40,}\b/g, "[hidden]");
  let timer = 0; const save = () => { clearTimeout(timer); timer = setTimeout(() => { try { localStorage.setItem(KEY, JSON.stringify(buf)); } catch { } }, 500); };
  const listeners = []; let busy = false;
  function log(kind, source, message, stack) {
    if (busy) return; busy = true;
    try {
      const e = { t: Date.now(), kind, source: redact(source).slice(0, 80), msg: redact(message).slice(0, 600), stack: stack ? redact(stack).slice(0, 1500) : "", ver: (window.BV_CONFIG || {}).version || "" };
      const last = buf[buf.length - 1];
      if (last && last.kind === kind && last.msg === e.msg && last.source === e.source && e.t - last.t < 3000) last.n = (last.n || 1) + 1; else buf.push(e);
      if (buf.length > MAX) buf = buf.slice(-MAX);
      save(); listeners.forEach(f => { try { f(e); } catch { } });
    } finally { busy = false; }
  }
  const clean = u => { try { const x = new URL(u, location.href); return x.host + x.pathname; } catch { return String(u).split("?")[0]; } };

  addEventListener("error", ev => {
    const t = ev.target;
    if (t && t !== window && (t.src || t.href)) return log("resource", (t.tagName || "").toLowerCase(), "Failed to load " + clean(t.src || t.href));
    log("error", clean(ev.filename || "") + (ev.lineno ? ":" + ev.lineno : ""), ev.message || "Script error", ev.error && ev.error.stack);
  }, true);
  addEventListener("unhandledrejection", ev => { const r = ev.reason; log("error", "promise", (r && r.message) || r || "Unhandled promise rejection", r && r.stack); });
  ["error", "warn"].forEach(k => { const orig = console[k]; console[k] = function (...a) { try { log(k === "error" ? "error" : "warn", "console", a.map(x => x instanceof Error ? x.message : typeof x === "object" ? (() => { try { return JSON.stringify(x); } catch { return String(x); } })() : x).join(" "), a.find(x => x instanceof Error)?.stack); } catch { } return orig.apply(this, a); }; });
  const of = window.fetch;
  if (of) window.fetch = function (input, init) {
    const url = typeof input === "string" ? input : input && input.url || "";
    if (/debug_reports|\/ping/.test(url)) return of.apply(this, arguments);
    return of.apply(this, arguments).then(r => {
      try { const same = clean(url).startsWith(location.host) || /supabase\.co/.test(url); if (r.status >= 500 || (r.status >= 400 && same)) log("network", clean(url), "HTTP " + r.status + (r.statusText ? " " + r.statusText : "")); } catch { }
      return r;
    }, err => { try { if (err && err.name !== "AbortError") log("network", clean(url), (err && err.message) || "Network request failed"); } catch { } throw err; });
  };

  window.BV_DEBUG = {
    log, redact,
    list: () => buf.slice(),
    clear() { buf = []; try { localStorage.removeItem(KEY); } catch { } listeners.forEach(f => { try { f(null); } catch { } }); },
    on: f => listeners.push(f),
    mark(sent) { sent.forEach(e => { e.sent = true; }); save(); },
  };
})();
