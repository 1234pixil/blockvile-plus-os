/* Blockvile Plus OS — the catalog of every game we have made (used by the Game Center and by the Blockvile Browser search). */
(function(){
var D0=Date.UTC(2026,8,20);
window.BV_GAMES=[
 {id:'bedwars',title:'Bed Wars',cat:['Multiplayer','Action','3D'],icon:'🛏️',c1:'#ff5a5f',c2:'#6d28d9',multi:1,feat:1,badge:'o',added:D0+90,
  desc:'Defend your bed and break everyone else\'s. Four floating islands, resource generators, a shop, blocks to build bridges and real players online. Practise against bots first.',
  how:'WASD move · Space jump · Mouse look · Left click attack · Right click build · E shop · Esc pause. Sign in inside the game to play online.',tags:['pvp','minecraft','teams','online']},
 {id:'skybedwars',title:'SkyBedwars',cat:['Multiplayer','Action','3D'],icon:'☁️',c1:'#38bdf8',c2:'#4338ca',multi:1,feat:1,badge:'o',added:D0+80,
  desc:'Own the sky. Collect iron, gold and emeralds, build bridges between islands and protect your team\'s bed. Offline practice is built in.',
  how:'WASD move · Space jump · Mouse look · Left click attack/mine · B build · E shop · Esc release mouse.',tags:['pvp','sky','online']},
 {id:'tidebreaker',title:'Tidebreaker Seas',cat:['Adventure','3D'],icon:'⚓',c1:'#0ea5e9',c2:'#0f766e',feat:1,badge:'o',added:D0+70,
  desc:'Sail between islands, take bounties, level up and eat strange fruits that grant elemental powers. Every island has a three-part quest chain ending in a boss.',
  how:'WASD move · Space jump · B boat · Click attack · Q E R skills · Right-drag camera · Scroll zoom.',tags:['pirates','rpg','open world','quests']},
 {id:'defense',title:'Blockville Defense',cat:['Strategy','3D'],icon:'🏰',c1:'#84cc16',c2:'#15803d',feat:1,badge:'o',added:D0+60,
  desc:'The noobs are marching on your village! Build blocky towers and stop 20 waves before they reach your house. Make your own maps and bosses in the editor.',
  how:'Tap a tower, then tap the grass to build. Drag to spin the view, pinch or scroll to zoom.',tags:['tower defense','waves','editor']},
 {id:'obby',title:'Blockville Obby',cat:['Obby','3D'],icon:'🧱',c1:'#51cf66',c2:'#0d9488',feat:1,badge:'o',added:D0+50,
  desc:'Run, jump and swing through blocky obstacle courses. Beat the clock, grab every coin and build your own levels in the editor.',
  how:'WASD or the on-screen stick to move · Space or the jump button to jump.',tags:['parkour','platformer','roblox']},
 {id:'buttondash',title:'Button Dash UK',cat:['Learning','Puzzle'],icon:'🎯',c1:'#f59e0b',c2:'#dc2626',badge:'o',added:D0+40,
  desc:'Pick your school stage, a country or a subject, then hit the right button as many times as you can before the clock runs out. Includes mini lessons.',
  how:'Click or tap the button with the right answer. Stars and scores are saved on this device.',tags:['quiz','school','maths','countries']},
 {id:'blockhop',title:'Block Hop',cat:['Arcade'],icon:'🐥',c1:'#74c0fc',c2:'#2563eb',added:D0+30,
  desc:'Tap or press Space to hop through the gaps. How many colourful towers can you clear?',how:'Tap or Space to hop.',tags:['flappy','one button']},
 {id:'coincatcher',title:'Coin Catcher',cat:['Arcade'],icon:'🪙',c1:'#b197fc',c2:'#7c3aed',added:D0+20,
  desc:'Slide the basket to catch falling coins and dodge the bombs. It gets faster the longer you last.',how:'Move the mouse or finger, or use the arrow keys.',tags:['catch','reflex']},
 {id:'memory',title:'Memory Blocks',cat:['Puzzle'],icon:'🧠',c1:'#ffd166',c2:'#f97316',added:D0+10,
  desc:'Flip the blocks and match all eight pairs in as few moves as you can.',how:'Click or tap two blocks to flip them.',tags:['cards','brain']},
 {id:'snake',title:'Snake Blocks',cat:['Arcade'],icon:'🐍',c1:'#2bd48f',c2:'#047857',added:D0+5,
  desc:'Classic snake with chunky blocks. Swipe or use the arrow keys, and do not bite your own tail.',how:'Arrow keys or swipe.',tags:['classic','retro']},
 {id:'os:snake',type:'app',app:'snake',title:'Snake (Blockvile app)',cat:['Arcade'],icon:'🐍',c1:'#22c55e',c2:'#166534',badge:'a',added:D0,
  desc:'The snake game built into Blockvile Plus OS. Best score is saved.',how:'Arrow keys, buttons or swipe.',tags:['classic','os app']},
 {id:'os:g2048',type:'app',app:'g2048',title:'2048',cat:['Puzzle'],icon:'🔢',c1:'#f59e0b',c2:'#ea580c',badge:'a',added:D0,
  desc:'Slide and merge the tiles to reach 2048.',how:'Arrow keys or swipe.',tags:['numbers','os app']},
 {id:'os:tictactoe',type:'app',app:'tictactoe',title:'Tic-Tac-Toe',cat:['Puzzle'],icon:'⭕',c1:'#6366f1',c2:'#ec4899',badge:'a',added:D0,
  desc:'Three in a row wins. Play a friend or the computer.',how:'Click a square.',tags:['two player','os app']}
];
})();
