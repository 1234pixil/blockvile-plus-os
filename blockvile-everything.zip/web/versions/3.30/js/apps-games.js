/* Blockvile Plus OS — Game Center app.
   The app IS the Game Center page (gamecenter.html): a CrazyGames / blox.io style store with every game we have made.
   The games live in the games/ folder (or inside the one-file copy). The page asks this app for a game's code and runs it in a sandboxed frame. */
(() => {
  const gameCache = new Map();
  const ID = /^[a-z0-9]{2,24}$/;
  const decodeB64 = t => new TextDecoder().decode(Uint8Array.from(atob(t.trim()), c => c.charCodeAt(0)));
  async function gameCode(id) {
    if (!ID.test(id)) throw new Error("bad id");
    if (gameCache.has(id)) return gameCache.get(id);
    let html = "";
    const el = document.getElementById("bv-game-" + id);        // the one-file copy carries the games inside itself
    if (el) { try { html = decodeB64(el.textContent); } catch { } }
    if (!html) { const r = await fetch("games/" + id + ".html"); if (!r.ok) throw new Error("missing"); html = await r.text(); }
    gameCache.set(id, html); return html;
  }
  const OSAPPS = new Set(["snake", "g2048", "tictactoe"]);

  window.BV_APPS.push({
    id: "gamecenter", name: "Game Center", icon: "🎮", bg: "linear-gradient(135deg,#7a4dff,#ff4f9a)", cat: "Games", dock: true, net: true, size: [1100, 700],
    keywords: "games game center play blox crazy games bedwars minecraft obby arcade multiplayer store",
    render(body, os) {
      body.style.padding = "0"; body.style.overflow = "hidden";
      let frame = null;
      async function onMsg(e) {
        if (!frame || e.source !== frame.contentWindow || !e.data || typeof e.data.bv !== "string") return;
        const d = e.data;
        if (d.bv === "gc-code" && typeof d.id === "string" && typeof d.n === "string") {
          let html = ""; try { html = await gameCode(d.id); } catch (err) { window.BV_DEBUG?.log("error", "Game Center " + d.id, String(err?.message || err)); }
          try { frame.contentWindow.postMessage({ bv: "gc-code", n: d.n, html }, "*"); } catch { }
        }
        if (d.bv === "gc-app" && OSAPPS.has(d.app)) {
          try { if (!os.isInstalled(d.app)) os.install(d.app, true); os.open(d.app); } catch { }
        }
      }
      window.addEventListener("message", onMsg);
      body.innerHTML = `<iframe data-gc title="Blockvile Game Center" style="width:100%;height:100%;border:0;background:#150d29;display:block" allow="autoplay; fullscreen; gamepad; clipboard-write; encrypted-media"
        referrerpolicy="strict-origin-when-cross-origin" sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-modals allow-pointer-lock allow-presentation"></iframe>`;
      frame = body.querySelector("[data-gc]");
      const el = document.getElementById("bv-gc-src");
      let html = ""; if (el) { try { html = decodeB64(el.textContent); } catch { } }
      if (html) frame.srcdoc = html; else frame.src = "gamecenter.html";
      return () => window.removeEventListener("message", onMsg);
    }
  });
})();
