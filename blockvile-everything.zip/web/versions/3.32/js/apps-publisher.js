/* Blockvile Plus OS — Blockvile Publisher (an app inside the OS).
   Build a project: add files, drop a .zip, add/rename/remove files and edit them (HTML, CSS, JS, JSON, Markdown, Python, Lua, anything).
   Then publish it into Blockvile: the Game Center (as a game or an app), the Blockvile Browser (searchable page),
   or make a browser-extension zip. Publishing needs a Blockvile login (Accounts app). Everything stays in the OS. */
(() => {
  const { esc } = window.BV;
  const A = window.BV_APPS;
  const enc = new TextEncoder(), dec = new TextDecoder();
  const TEXT = /\.(html?|css|js|mjs|json|md|txt|svg|xml|py|lua|ts|tsx|jsx|java|c|cpp|h|cs|go|rs|rb|php|sh|bat|sql|yml|yaml|toml|csv|ini)$/i;
  const MIME = { html: "text/html", htm: "text/html", css: "text/css", js: "text/javascript", mjs: "text/javascript", json: "application/json", svg: "image/svg+xml", png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif", webp: "image/webp", mp3: "audio/mpeg", wav: "audio/wav", ogg: "audio/ogg", woff2: "font/woff2", woff: "font/woff", ttf: "font/ttf" };
  const LANG = { html: "HTML", htm: "HTML", css: "CSS", js: "JavaScript", mjs: "JavaScript", json: "JSON", md: "Markdown", py: "Python", lua: "Lua", ts: "TypeScript", java: "Java", c: "C", cpp: "C++", cs: "C#", go: "Go", rs: "Rust", rb: "Ruby", php: "PHP", sh: "Shell", sql: "SQL", txt: "Text" };
  const ext = p => (/\.([a-z0-9]+)$/i.exec(p) || [, ""])[1].toLowerCase();
  const mimeOf = p => MIME[ext(p)] || "application/octet-stream";
  const b64 = u8 => { let s = ""; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
  const cleanPath = p => String(p || "").replace(/\\/g, "/").replace(/^\/+/, "").split("/").filter(x => x && x !== "." && x !== "..").join("/");
  const slug = s => String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 30);
  const LIMIT = 400000, MAXFILES = 300, MAXTOTAL = 12 * 1024 * 1024;

  /* ---- zip reading (no library) and writing ---- */
  async function unzip(buf) {
    const u8 = new Uint8Array(buf), dv = new DataView(buf), out = [];
    let e = -1; for (let i = u8.length - 22; i >= Math.max(0, u8.length - 66000); i--) if (dv.getUint32(i, true) === 0x06054b50) { e = i; break; }
    if (e < 0) throw new Error("That doesn't look like a zip file.");
    const n = dv.getUint16(e + 10, true); let p = dv.getUint32(e + 16, true);
    for (let k = 0; k < n && out.length < MAXFILES; k++) {
      if (dv.getUint32(p, true) !== 0x02014b50) break;
      const method = dv.getUint16(p + 10, true), csize = dv.getUint32(p + 20, true), nl = dv.getUint16(p + 28, true), xl = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true), lo = dv.getUint32(p + 42, true);
      const name = dec.decode(u8.subarray(p + 46, p + 46 + nl)); p += 46 + nl + xl + cl;
      if (name.endsWith("/") || /(^|\/)(__MACOSX|\.git)\//.test(name) || /\.DS_Store$/.test(name)) continue;
      const lnl = dv.getUint16(lo + 26, true), lxl = dv.getUint16(lo + 28, true), start = lo + 30 + lnl + lxl, raw = u8.subarray(start, start + csize);
      let data;
      if (method === 0) data = raw.slice();
      else if (method === 8) data = new Uint8Array(await new Response(new Blob([raw]).stream().pipeThrough(new DecompressionStream("deflate-raw"))).arrayBuffer());
      else continue;
      out.push({ path: cleanPath(name), bytes: data });
    }
    return out;
  }
  const CRC = (() => { const t = []; for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  const crc32 = b => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  function makeZip(files) {
    const parts = [], cd = []; let off = 0;
    const u16 = v => [v & 255, (v >> 8) & 255], u32 = v => [v & 255, (v >> 8) & 255, (v >> 16) & 255, (v >>> 24) & 255];
    files.forEach(f => {
      const nm = enc.encode(f.name), d = f.data, crc = crc32(d);
      const lh = [0x50, 0x4b, 3, 4, ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0), ...u16(0x21), ...u32(crc), ...u32(d.length), ...u32(d.length), ...u16(nm.length), ...u16(0)];
      parts.push(new Uint8Array(lh), nm, d);
      cd.push(new Uint8Array([0x50, 0x4b, 1, 2, ...u16(20), ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0), ...u16(0x21), ...u32(crc), ...u32(d.length), ...u32(d.length), ...u16(nm.length), ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(off)]), nm);
      off += lh.length + nm.length + d.length;
    });
    const cdLen = cd.reduce((a, b) => a + b.length, 0);
    return new Blob([...parts, ...cd, new Uint8Array([0x50, 0x4b, 5, 6, ...u16(0), ...u16(0), ...u16(files.length), ...u16(files.length), ...u32(cdLen), ...u32(off), ...u16(0)])], { type: "application/zip" });
  }

  /* ---- turn a project into one self-contained page (css/js/images inlined) ---- */
  function resolve(from, ref, files) {
    ref = String(ref).split("#")[0].split("?")[0]; if (!ref || /^(https?:|data:|blob:|\/\/|mailto:|#)/i.test(ref)) return null;
    const base = from.split("/").slice(0, -1); const parts = ref.startsWith("/") ? [] : base;
    for (const seg of ref.split("/")) { if (seg === "..") parts.pop(); else if (seg && seg !== ".") parts.push(seg); }
    const p = parts.join("/"); return files.has(p) ? p : null;
  }
  function bundle(files, entry) {
    let html = dec.decode(files.get(entry));
    const text = p => dec.decode(files.get(p)), uri = p => "data:" + mimeOf(p) + ";base64," + b64(files.get(p));
    html = html.replace(/<link\b[^>]*>/gi, tag => { const h = /href\s*=\s*["']([^"']+)["']/i.exec(tag); if (!h || !/stylesheet/i.test(tag)) return tag; const p = resolve(entry, h[1], files); return p ? "<style>" + text(p).replace(/<\/style/gi, "<\\/style") + "</style>" : tag; });
    html = html.replace(/<script\b([^>]*)\bsrc\s*=\s*["']([^"']+)["']([^>]*)>\s*<\/script>/gi, (m, a, src, b) => { const p = resolve(entry, src, files); return p ? "<script" + a + b + ">" + text(p).replace(/<\/script/gi, "<\\/script") + "<\/script>" : m; });
    html = html.replace(/\b(src|poster)\s*=\s*["']([^"']+)["']/gi, (m, k, v) => { const p = resolve(entry, v, files); return p ? k + '="' + uri(p) + '"' : m; });
    html = html.replace(/url\(\s*["']?([^"')]+)["']?\s*\)/gi, (m, v) => { const p = resolve(entry, v, files); return p ? 'url("' + uri(p) + '")' : m; });
    return html;
  }

  A.push({
    id: "publisher", name: "Blockvile Publisher", icon: "🚀", bg: "linear-gradient(135deg,#5b4bff,#b06bff)", cat: "Create", dock: true, size: [1000, 680], keywords: "publisher publish pad upload zip github files code project extension game center browser app",
    render(body, os) {
      const store = window.BV.store, auth = () => window.BV.auth;
      const P = { files: new Map(), sel: "", entry: "", dirty: false };
      try { const sv = JSON.parse(store.get("pubProject") || "null"); if (sv?.files) { Object.entries(sv.files).forEach(([k, v]) => P.files.set(k, enc.encode(v))); P.sel = sv.sel || ""; } } catch { }
      let dest = "gc";
      body.style.padding = "0"; body.style.overflow = "auto";
      const css = `<style>.pb{display:flex;flex-direction:column;gap:10px;padding:12px;font-size:14px}.pb h4{margin:0 0 6px;font-size:13px;letter-spacing:.04em;text-transform:uppercase;opacity:.7}.pb .row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
      .pb .cols{display:grid;grid-template-columns:minmax(200px,260px) 1fr;gap:10px}@media(max-width:700px){.pb .cols{grid-template-columns:1fr}}
      .pb .card{border:1px solid var(--line,rgba(120,120,140,.3));border-radius:12px;padding:10px;background:var(--card,rgba(120,120,140,.08))}
      .pb .fl{max-height:300px;overflow:auto;display:flex;flex-direction:column;gap:3px;margin-top:8px}.pb .fi{display:flex;align-items:center;gap:6px;padding:5px 8px;border-radius:8px;cursor:pointer;border:1px solid transparent}.pb .fi.on{border-color:#7a6bff;background:rgba(122,107,255,.15)}
      .pb .fi span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.pb .fi small{opacity:.6}.pb .fi button{background:none;border:0;color:inherit;cursor:pointer;opacity:.7;font-size:15px}
      .pb textarea{width:100%;min-height:260px;font:12px/1.5 ui-monospace,Menlo,Consolas,monospace;border-radius:8px;border:1px solid var(--line,rgba(120,120,140,.3));background:rgba(0,0,0,.18);color:inherit;padding:8px;resize:vertical;box-sizing:border-box}
      .pb input.f,.pb select.f,.pb textarea.f{border-radius:8px;border:1px solid var(--line,rgba(120,120,140,.3));background:rgba(0,0,0,.12);color:inherit;padding:8px;font:inherit;min-width:0;box-sizing:border-box}
      .pb .dst{display:flex;gap:6px;flex-wrap:wrap}.pb .dst button[aria-pressed=true]{background:#5b4bff;color:#fff;border-color:#5b4bff}
      .pb .msg{padding:8px 10px;border-radius:8px}.pb .msg.ok{background:rgba(60,200,120,.18)}.pb .msg.err{background:rgba(255,90,90,.2)}</style>`;
      body.innerHTML = css + `<div class="pb">
        <div class="card"><h4>1 · Your project</h4>
          <div class="row"><button class="btn" data-a="addfiles">＋ Add files</button><button class="btn" data-a="addzip">📦 Add a .zip</button><button class="btn ghost" data-a="newfile">New file</button><button class="btn ghost" data-a="clear">Clear all</button><small class="muted" data-c="count"></small></div>
          <input type="file" data-in="files" multiple hidden><input type="file" data-in="zip" accept=".zip,application/zip" hidden>
          <div class="cols" style="margin-top:8px"><div><div class="fl" data-c="list"></div></div>
            <div><div class="row" style="margin-bottom:6px"><b data-c="fname">No file selected</b><small class="muted" data-c="lang"></small><span style="flex:1"></span><button class="btn ghost" data-a="rename">Rename</button><button class="btn ghost" data-a="entry">Use as main page</button></div>
              <textarea data-c="ed" spellcheck="false" placeholder="Add files or a zip, or press New file and start typing. Any language works; the main page must be HTML." hidden></textarea><p class="muted" data-c="hint" style="margin:0">Drop nothing here yet.</p></div></div></div>
        <div class="card"><h4>2 · Where to publish</h4>
          <div class="dst"><button class="btn ghost" data-d="gc">🎮 Game Center · game</button><button class="btn ghost" data-d="gcapp">🧩 Game Center · app</button><button class="btn ghost" data-d="page">🌐 Blockvile Browser</button><button class="btn ghost" data-d="ext">🧰 Browser extension</button><button class="btn ghost" data-d="zip">📦 Save project .zip</button></div>
          <p class="muted" data-c="dhint" style="margin:8px 0"></p>
          <div class="row"><input class="f" data-f="name" placeholder="Name (e.g. Lava Jumpers)" maxlength="40" style="flex:1;min-width:160px"><select class="f" data-f="cat"><option>Arcade</option><option>3D</option><option>Action</option><option>Adventure</option><option>Learning</option><option>Obby</option><option>Puzzle</option><option>Strategy</option><option>Sandbox</option><option>Other</option></select><select class="f" data-f="icon">${["🎮", "🧱", "🚀", "🐸", "👾", "🏎️", "⚔️", "🧩", "🐉", "🍕", "🌈", "💎", "🦖", "🛸", "⚽", "🎯", "📄"].map(i => `<option>${i}</option>`).join("")}</select></div>
          <textarea class="f" data-f="desc" rows="2" maxlength="400" placeholder="Describe it (people search this text)" style="width:100%;margin-top:8px;min-height:50px"></textarea>
          <div class="row" style="margin-top:8px"><button class="btn" data-a="publish">Publish</button><small class="muted" data-c="who"></small></div>
          <div data-c="msg" style="margin-top:8px"></div></div></div>`;
      const q = s => body.querySelector(s), c = n => q(`[data-c=${n}]`), f = n => q(`[data-f=${n}]`);
      const msg = (k, t) => { c("msg").innerHTML = t ? `<div class="msg ${k}">${t}</div>` : ""; };
      const total = () => { let t = 0; P.files.forEach(v => t += v.length); return t; };
      const isText = p => TEXT.test(p);
      const pickEntry = () => { if (P.files.has(P.entry)) return; P.entry = P.files.has("index.html") ? "index.html" : [...P.files.keys()].find(k => /\.html?$/i.test(k) && !k.includes("/")) || [...P.files.keys()].find(k => /\.html?$/i.test(k)) || ""; };
      const save = () => { try { const o = {}; P.files.forEach((v, k) => { if (isText(k) && v.length < 300000) o[k] = dec.decode(v); }); store.set("pubProject", JSON.stringify({ files: o, sel: P.sel })); } catch { } };
      const DH = { gc: "Adds your project to the Game Center as a game, next to Bed Wars. Needs login. Shows for everyone once approved.", gcapp: "Adds it to the Game Center with an APP badge. Needs login.", page: "Makes your page findable by searching in the Blockvile Browser. Needs login.", ext: "Makes a zip you load in Chrome, Edge or Brave (chrome://extensions → Developer mode → Load unpacked).", zip: "Saves every file in the project as one .zip." };
      function draw() {
        pickEntry();
        c("count").textContent = P.files.size ? P.files.size + " file" + (P.files.size > 1 ? "s" : "") + " · " + window.BV.fmtSize(total()) : "";
        const names = [...P.files.keys()].sort();
        c("list").innerHTML = names.length ? names.map(n => `<div class="fi ${n === P.sel ? "on" : ""}" data-p="${esc(n)}"><span>${n === P.entry ? "⭐ " : ""}${esc(n)}</span><small>${window.BV.fmtSize(P.files.get(n).length)}</small><button data-rm="${esc(n)}" title="Remove">✕</button></div>`).join("") : `<p class="muted">No files yet.</p>`;
        const ed = c("ed"), sel = P.files.has(P.sel);
        c("fname").textContent = sel ? P.sel : "No file selected"; c("lang").textContent = sel ? (LANG[ext(P.sel)] || ext(P.sel).toUpperCase() || "File") : "";
        ed.hidden = !sel || !isText(P.sel); c("hint").hidden = sel && isText(P.sel);
        c("hint").textContent = sel ? "Binary file (image, sound…). It travels with the project but can't be edited here." : "Pick a file on the left, or add some.";
        if (sel && isText(P.sel)) ed.value = dec.decode(P.files.get(P.sel));
        c("dhint").textContent = DH[dest];
        body.querySelectorAll("[data-d]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.d === dest)));
        f("cat").hidden = dest === "page" || dest === "ext" || dest === "zip"; f("icon").hidden = dest === "ext" || dest === "zip";
        const a = auth(); c("who").textContent = (dest === "ext" || dest === "zip") ? "No login needed." : a?.signedIn?.() ? "Logged in as " + a.email() : "Not logged in — open the Accounts app first.";
        save();
      }
      function addFiles(list) {
        let n = 0, skip = 0;
        list.forEach(({ path, bytes }) => { path = cleanPath(path); if (!path) return; if ((!P.files.has(path) && P.files.size >= MAXFILES) || total() + bytes.length > MAXTOTAL) { skip++; return; } P.files.set(path, bytes); n++; if (!P.sel || !P.files.has(P.sel)) P.sel = path; });
        if (n && !f("name").value) f("name").value = ((P.files.get(P.entry) && /<title[^>]*>([^<]+)/i.exec(dec.decode(P.files.get(P.entry)))?.[1]) || "").trim().slice(0, 40);
        draw(); msg(skip ? "err" : "ok", `Added ${n} file${n === 1 ? "" : "s"}.` + (skip ? ` ${skip} skipped (too many or too big).` : ""));
      }
      async function readPicked(files) {
        const out = [];
        for (const fl of files) {
          const buf = await fl.arrayBuffer();
          if (/\.zip$/i.test(fl.name)) { try { out.push(...await unzip(buf)); } catch (e) { msg("err", esc(e.message || "Couldn't read that zip.")); } }
          else out.push({ path: fl.webkitRelativePath || fl.name, bytes: new Uint8Array(buf) });
        }
        // a zip that wraps everything in one folder: drop the folder
        const tops = new Set(out.map(o => o.path.split("/")[0])); if (out.length && tops.size === 1 && out.every(o => o.path.includes("/"))) out.forEach(o => o.path = o.path.split("/").slice(1).join("/"));
        addFiles(out);
      }
      body.addEventListener("click", async e => {
        const t = e.target;
        const rm = t.closest("[data-rm]"); if (rm) { e.stopPropagation(); const p = rm.dataset.rm; if (await window.BV.confirm("Remove " + p + "?", { ok: "Remove", danger: true })) { P.files.delete(p); if (P.sel === p) P.sel = [...P.files.keys()][0] || ""; draw(); } return; }
        const fi = t.closest("[data-p]"); if (fi) { P.sel = fi.dataset.p; draw(); return; }
        const d = t.closest("[data-d]"); if (d) { dest = d.dataset.d; draw(); msg("", ""); return; }
        const a = t.closest("[data-a]")?.dataset.a; if (!a) return;
        if (a === "addfiles") q("[data-in=files]").click();
        if (a === "addzip") q("[data-in=zip]").click();
        if (a === "newfile") { const n = cleanPath(await window.BV.ask("New file name (like index.html, game.js, main.py)", "index.html")); if (!n) return; if (P.files.has(n)) { msg("err", "That file already exists."); return; } P.files.set(n, enc.encode(/\.html?$/i.test(n) ? '<!DOCTYPE html>\n<html>\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1">\n<title>My page</title>\n</head>\n<body>\n<h1>Hello Blockvile</h1>\n<\/body>\n<\/html>\n' : "")); P.sel = n; draw(); }
        if (a === "rename" && P.files.has(P.sel)) { const n = cleanPath(await window.BV.ask("New name for " + P.sel, P.sel)); if (!n || n === P.sel) return; if (P.files.has(n)) { msg("err", "That name is taken."); return; } P.files.set(n, P.files.get(P.sel)); P.files.delete(P.sel); if (P.entry === P.sel) P.entry = n; P.sel = n; draw(); }
        if (a === "entry" && P.files.has(P.sel)) { if (!/\.html?$/i.test(P.sel)) { msg("err", "The main page has to be an .html file."); return; } P.entry = P.sel; draw(); msg("ok", P.sel + " is now the main page."); }
        if (a === "clear" && P.files.size && await window.BV.confirm("Remove every file from this project?", { ok: "Clear", danger: true })) { P.files.clear(); P.sel = ""; P.entry = ""; draw(); }
        if (a === "publish") publish();
      });
      c("ed").addEventListener("input", () => { if (P.files.has(P.sel)) { P.files.set(P.sel, enc.encode(c("ed").value)); c("count").textContent = P.files.size + " files · " + window.BV.fmtSize(total()); save(); } });
      q("[data-in=files]").addEventListener("change", e => { readPicked([...e.target.files]); e.target.value = ""; });
      q("[data-in=zip]").addEventListener("change", e => { readPicked([...e.target.files]); e.target.value = ""; });
      body.addEventListener("dragover", e => e.preventDefault());
      body.addEventListener("drop", e => { e.preventDefault(); if (e.dataTransfer?.files?.length) readPicked([...e.dataTransfer.files]); });

      async function publish() {
        const name = f("name").value.replace(/\s+/g, " ").trim().slice(0, 40);
        if (!P.files.size) return msg("err", "Add some files first.");
        if (dest === "zip") { window.BV.download(makeZip([...P.files].map(([n, d]) => ({ name: n, data: d }))), (slug(name) || "project") + ".zip"); return msg("ok", "Saved the project as a .zip."); }
        pickEntry(); if (!P.entry) return msg("err", "Add an HTML page first (for example index.html) and set it as the main page.");
        if (name.length < 2) return msg("err", "Give it a name (at least 2 characters).");
        if (dest === "ext") {
          const manifest = JSON.stringify({ manifest_version: 3, name, version: "1.0", description: (f("desc").value || "Made with Blockvile Publisher").slice(0, 130), action: { default_popup: "popup.html", default_title: name } }, null, 2);
          const list = [{ name: "manifest.json", data: enc.encode(manifest) }];
          P.files.forEach((d, n) => list.push({ name: n === P.entry ? "popup.html" : n, data: d }));
          list.push({ name: "README.txt", data: enc.encode("Unzip this folder, open chrome://extensions, turn on Developer mode, press Load unpacked and choose this folder.\nExtensions can't run inline scripts, so keep scripts in their own .js files.\n") });
          window.BV.download(makeZip(list), (slug(name) || "extension") + "-extension.zip"); return msg("ok", "Saved your extension zip. Unzip it, open <b>chrome://extensions</b>, switch on Developer mode, press <b>Load unpacked</b> and pick the folder.");
        }
        const a = auth();
        if (!a?.configured?.()) return msg("err", "Blockvile accounts aren't set up yet.");
        if (!a.signedIn()) { msg("err", "Log in first (Accounts app), then press Publish again."); os.open("accounts"); return; }
        let html; try { html = bundle(P.files, P.entry); } catch (e) { return msg("err", "Couldn't prepare the project: " + esc(e.message || "")); }
        if (html.length < 40) return msg("err", "The main page is empty.");
        if (html.length > LIMIT) return msg("err", "Too big to publish (" + window.BV.fmtSize(html.length) + "). The limit is about 400 KB. Remove big images or sounds.");
        const kind = dest === "page" ? "page" : dest === "gcapp" ? "app" : "game", where = kind === "page" ? "the Blockvile Browser" : "the Game Center";
        msg("", ""); c("msg").innerHTML = `<div class="msg">Publishing…</div>`;
        try {
          const cl = await a.client(), uid = String(a.user.id).replace(/[^a-z0-9]/gi, "").toLowerCase().slice(0, 8);
          const row = { id: ("u" + uid + "-" + (slug(name) || "item")).slice(0, 60), title: name, description: f("desc").value.slice(0, 400), category: kind === "page" ? "Other" : f("cat").value, icon: f("icon").value, color: "#74c0fc", kind, code: html, author_name: String(a.name() || "player").slice(0, 30) };
          const { error } = await cl.from("gc_games").upsert(row, { onConflict: "id" });
          if (error) throw error;
          msg("ok", `<b>${esc(name)}</b> is published to ${where}. ${kind === "page" ? "Search for it in the Blockvile Browser." : "Open the Game Center and look under Community."} Everyone else sees it once it's approved.`);
        } catch (e) {
          const m = String(e?.message || e); window.BV_DEBUG?.log("error", "Publisher", m);
          msg("err", /kind/.test(m) && /column|schema/i.test(m) ? "The database needs one update: run <b>supabase/game-center.sql</b> in your Supabase SQL Editor." : /gc_games/.test(m) && /exist|find/i.test(m) ? "The Game Center table is missing. Run <b>supabase/game-center.sql</b> in your Supabase SQL Editor once." : /up to 25/.test(m) ? "You already have 25 published. Remove one first." : "Couldn't publish: " + esc(m));
        }
      }
      draw();
    }
  });
})();
