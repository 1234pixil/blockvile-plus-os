/* Blockvile Plus OS — Game Center app.
   The app IS the Game Center page (gamecenter.html): a CrazyGames / blox.io style store with every game we have made.
   The games live in the games/ folder (or inside the one-file copy). The page asks this app for a game's code and runs it in a sandboxed frame. */
(() => {
  const gameCache = new Map();
  const ID = /^[a-z0-9]{2,24}$/;
  const decodeB64 = t => new TextDecoder().decode(Uint8Array.from(atob(t.trim()), c => c.charCodeAt(0)));
  async function gameCode(id) {
    if (!ID.test(id)) throw new Error("bad id");
    if (gameCache.has(id)) return gameCache.get(id);
    let html = "";
    const el = document.getElementById("bv-game-" + id);        // the one-file copy carries the games inside itself
    if (el) { try { html = decodeB64(el.textContent); } catch { } }
    if (!html) { const r = await fetch("games/" + id + ".html"); if (!r.ok) throw new Error("missing"); html = await r.text(); }
    gameCache.set(id, html); return html;
  }
  const OSAPPS = new Set(["snake", "g2048", "tictactoe"]);
  const COM_ID = /^[a-z0-9-]{3,60}$/, COM_CATS = ["3D", "Action", "Adventure", "Arcade", "Learning", "Obby", "Puzzle", "Strategy", "Sandbox", "Other"];
  const sb = async () => { const a = window.BV.auth; if (!a?.configured?.()) throw new Error("Accounts aren't set up"); return a.client(); };
  // games players published for everyone (Publisher Pad or the Publish button), kept in the owner's own Supabase
  async function comList() {
    try {
      const c = await sb(), a = window.BV.auth;
      const { data, error } = await c.from("gc_games").select("id,title,description,category,icon,color,author_name,approved,owner,created_at,kind").in("kind", ["game", "app"]).order("created_at", { ascending: false }).limit(80);
      if (error) throw error;
      return { games: data || [], uid: a.user?.id || null, signedIn: a.signedIn() };
    } catch (e) { window.BV_DEBUG?.log("warn", "Game Center list", String(e?.message || e)); return { games: [], uid: null, signedIn: !!window.BV.auth?.signedIn?.() }; }
  }
  async function comCode(id) {
    if (!COM_ID.test(id)) throw new Error("bad id");
    const c = await sb(), { data, error } = await c.from("gc_games").select("code").eq("id", id).maybeSingle();
    if (error || !data?.code) throw new Error("missing");
    return data.code;
  }
  async function comShare(g) {
    const a = window.BV.auth;
    if (!a?.configured?.()) return { ok: false, msg: "Sharing needs Blockvile accounts to be set up." };
    if (!a.signedIn()) return { ok: false, msg: "Sign in (Accounts app) to share a game with everyone.", signin: true };
    const title = String(g?.title || "").trim().slice(0, 40), code = String(g?.code || "");
    if (title.length < 2 || code.length < 40 || code.length > 400000) return { ok: false, msg: "That game can't be shared (name or code is missing or too big)." };
    const id = "u" + String(a.user.id).replace(/[^a-z0-9]/gi, "").toLowerCase().slice(0, 8) + "-" + String(g.localId || "g").toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 24);
    const row = { id, title, description: String(g.desc || "").slice(0, 400), category: COM_CATS.includes(g.cat) ? g.cat : "Other", icon: String(g.icon || "🎮").slice(0, 8),
      color: /^#[0-9a-f]{6}$/i.test(g.color || "") ? g.color : "#74c0fc", code, author_name: String(a.name() || "player").slice(0, 30) };
    try {
      const c = await a.client(), { error } = await c.from("gc_games").upsert(row, { onConflict: "id" });
      if (error) throw error;
      return { ok: true, id, msg: "Shared! It shows for everyone once it's approved." };
    } catch (e) { window.BV_DEBUG?.log("error", "Game Center share", String(e?.message || e)); return { ok: false, msg: "Couldn't share it: " + String(e?.message || "try again later") }; }
  }
  async function comDelete(id) {
    try { if (!COM_ID.test(id)) return false; const c = await sb(); const { error } = await c.from("gc_games").delete().eq("id", id); return !error; } catch { return false; }
  }

  // pages people published for the Blockvile Browser (Blockvile Publisher -> "Blockvile Browser"): searched by the Browser app
  const clean = q => String(q || "").normalize("NFKD").replace(/[^\p{L}\p{N} ]/gu, " ").replace(/\s+/g, " ").trim().slice(0, 40);
  let gcFrameWin = null, gcWant = null;
  const gcSend = () => { if (gcWant && gcFrameWin) { try { gcFrameWin.postMessage({ bv: "gc-goto", id: gcWant }, "*"); gcWant = null; } catch { } } };
  window.BV.gcGoto = id => { gcWant = String(id); gcFrameWin ? gcSend() : null; (window.BlockvileOS || {}).open?.("gamecenter"); setTimeout(gcSend, 400); };
  window.BV.published = {
    async pages(q) {
      try {
        const c = await sb(), t = clean(q);
        let qr = c.from("gc_games").select("id,title,description,icon,color,author_name,created_at").eq("kind", "page").order("created_at", { ascending: false }).limit(30);
        if (t) qr = qr.or(`title.ilike.%${t}%,description.ilike.%${t}%`);
        const { data, error } = await qr; if (error) throw error; return data || [];
      } catch (e) { window.BV_DEBUG?.log("warn", "Published pages", String(e?.message || e)); return []; }
    },
    code: comCode,
  };

  window.BV_APPS.push({
    id: "gamecenter", name: "Game Center", icon: "🎮", bg: "linear-gradient(135deg,#7a4dff,#ff4f9a)", cat: "Games", dock: true, net: true, size: [1100, 700],
    keywords: "games game center play blox crazy games bedwars minecraft obby arcade multiplayer store",
    render(body, os) {
      body.style.padding = "0"; body.style.overflow = "hidden";
      let frame = null;
      async function onMsg(e) {
        if (!frame || e.source !== frame.contentWindow || !e.data || typeof e.data.bv !== "string") return;
        const d = e.data;
        if (d.bv === "gc-ready") { gcFrameWin = frame.contentWindow; gcSend(); }
        if (d.bv === "gc-code" && typeof d.id === "string" && typeof d.n === "string") {
          let html = ""; try { html = await gameCode(d.id); } catch (err) { window.BV_DEBUG?.log("error", "Game Center " + d.id, String(err?.message || err)); }
          try { frame.contentWindow.postMessage({ bv: "gc-code", n: d.n, html }, "*"); } catch { }
        }
        const reply = m => { try { frame.contentWindow.postMessage({ ...m, n: d.n }, "*"); } catch { } };
        if (d.bv === "gc-list") reply({ bv: "gc-list", ...(await comList()) });
        if (d.bv === "gc-comcode" && typeof d.id === "string") { let html = ""; try { html = await comCode(d.id); } catch (err) { window.BV_DEBUG?.log("error", "Game Center " + d.id, String(err?.message || err)); } reply({ bv: "gc-code", html }); }
        if (d.bv === "gc-share" && d.game && typeof d.game === "object") reply({ bv: "gc-share-result", ...(await comShare(d.game)) });
        if (d.bv === "gc-unshare" && typeof d.id === "string") reply({ bv: "gc-unshare-result", ok: await comDelete(d.id) });
        if (d.bv === "gc-signin") os.open("accounts");
        if (d.bv === "gc-app" && OSAPPS.has(d.app)) {
          try { if (!os.isInstalled(d.app)) os.install(d.app, true); os.open(d.app); } catch { }
        }
      }
      window.addEventListener("message", onMsg);
      body.innerHTML = `<iframe data-gc title="Blockvile Game Center" style="width:100%;height:100%;border:0;background:#150d29;display:block" allow="autoplay; fullscreen; gamepad; clipboard-write; encrypted-media"
        referrerpolicy="strict-origin-when-cross-origin" sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-modals allow-pointer-lock allow-presentation"></iframe>`;
      frame = body.querySelector("[data-gc]");
      const el = document.getElementById("bv-gc-src");
      let html = ""; if (el) { try { html = decodeB64(el.textContent); } catch { } }
      if (html) frame.srcdoc = html; else frame.src = "gamecenter.html";
      return () => { window.removeEventListener("message", onMsg); gcFrameWin = null; };
    }
  });
})();
