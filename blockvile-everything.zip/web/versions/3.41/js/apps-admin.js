/* Blockvile Plus OS — Admin apps: Approvals, Suspicious Logs, Account Moderation.
   They only appear for an admin account (the one in gc_admins, e.g. ethanabraham09092014@gmail.com). The server checks admin on every action too. */
(() => {
  const { esc } = window.BV;
  const A = window.BV_APPS;
  const P = () => window.BV.profile;
  const isAdmin = () => !!P()?.data?.admin;
  const KINDN = { game: "Game", page: "Page", app: "App", store: "Play Store app" };
  const css = `<style>.ad{padding:12px;display:flex;flex-direction:column;gap:10px;font-size:14px}.ad h3{margin:0}.ad .row{display:flex;gap:10px;align-items:center;padding:10px;border:1px solid var(--line,rgba(120,120,140,.3));border-radius:12px;background:var(--card,rgba(120,120,140,.08));flex-wrap:wrap}
  .ad .row>.g{flex:1;min-width:150px}.ad .top{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.ad .note{padding:8px 10px;border-radius:8px;background:rgba(122,107,255,.15)}
  .ad input.f,.ad select.f{border-radius:8px;border:1px solid var(--line,rgba(120,120,140,.3));background:rgba(0,0,0,.12);color:inherit;padding:8px;font:inherit;min-width:0}
  .ad .lv{display:inline-block;padding:2px 8px;border-radius:999px;font-size:12px;font-weight:700}.ad .lv.high{background:#ff4d4d;color:#fff}.ad .lv.warn{background:#ffb020;color:#222}.ad .lv.info{background:rgba(120,120,140,.3)}
  .ad .tabs{display:flex;gap:6px;flex-wrap:wrap}.ad .tabs button[aria-pressed=true]{background:#7a4dff;color:#fff;border-color:#7a4dff}
  .ad .modal{position:fixed;inset:0;background:rgba(0,0,0,.55);display:grid;place-items:center;z-index:50}.ad .modal>div{background:var(--bg,#1d1d28);color:inherit;border-radius:14px;padding:14px;max-width:96vw;max-height:94vh;overflow:auto}</style>`;
  const ago = t => { const m = Math.max(0, Math.round((Date.now() - new Date(t)) / 60000)); return m < 1 ? "just now" : m < 60 ? m + " min ago" : m < 1440 ? Math.round(m / 60) + " h ago" : Math.round(m / 1440) + " d ago"; };
  const guard = body => { if (isAdmin()) return false; body.innerHTML = css + `<div class="ad"><h3>🔒 Admins only</h3><p>Sign in with the admin account to use this app.</p></div>`; return true; };
  const shell = (body, state) => {
    body.style.padding = "0"; body.style.overflow = "auto";
    const onP = () => { if (!body.isConnected) return window.removeEventListener("bv:profile", onP); state.draw(); };
    window.addEventListener("bv:profile", onP);
    return () => window.removeEventListener("bv:profile", onP);
  };

  A.push({
    id: "approvals", name: "Approvals", icon: "✅", bg: "linear-gradient(135deg,#2bb673,#1b8f9e)", cat: "Admin", dock: true, hidden: true, size: [900, 660], net: true,
    keywords: "approvals approve apps games pages costumes review admin",
    render(body, os) {
      let games = [], costumes = [], msg = "", modal = "", loaded = false;
      const st = { draw: () => draw() };
      const cleanup = shell(body, st);
      const load = async () => {
        if (!isAdmin()) return draw();
        try {
          const c = await window.BV.auth.client();
          const pg = await c.from("gc_games").select("id,title,description,kind,icon,author_name,created_at").eq("approved", false).order("created_at", { ascending: false }).limit(80);
          games = pg.data || [];
          costumes = (await P().rpc("bv_creations_pending")) || [];
        } catch (e) { msg = "Couldn't load: " + (e.message || e); }
        loaded = true; draw();
      };
      function draw() {
        if (guard(body)) return;
        const n = games.length + costumes.length;
        body.innerHTML = css + `<div class="ad"><div class="top"><h3>✅ Approvals ${n ? `(${n} waiting)` : ""}</h3><button class="btn ghost" data-a="reload" style="margin-left:auto">↻ Refresh</button></div>${msg ? `<div class="note">${esc(msg)}</div>` : ""}
        <h4 style="margin:6px 0 0">Games, apps and pages</h4>
        ${loaded ? (games.map(m => `<div class="row"><span style="font-size:28px">${esc(m.icon || "📄")}</span><div class="g"><b>${esc(m.title)}</b> <small class="muted">${KINDN[m.kind] || ""} by ${esc(m.author_name || "?")} · ${ago(m.created_at)}</small><br><small class="muted">${esc((m.description || "").slice(0, 140))}</small></div><button class="btn ghost" data-gp="${esc(m.id)}">👁 Play / look</button><button class="btn" data-gd="${esc(m.id)}" data-ok="1">Approve</button><button class="btn ghost" data-gd="${esc(m.id)}">Reject</button></div>`).join("") || `<p class="muted">Nothing waiting.</p>`) : `<p class="muted">Loading…</p>`}
        <h4 style="margin:10px 0 0">Costumes (2D and 3D)</h4>
        ${loaded ? (costumes.map(m => `<div class="row"><span>${m.thumb ? `<img src="${esc(m.thumb)}" style="width:48px;height:48px;object-fit:cover;border-radius:10px" alt="">` : `<span style="font-size:28px">${m.kind === "avatar3d" ? "🧊" : "🖼️"}</span>`}</span><div class="g"><b>${esc(m.name)}</b> <small class="muted">${m.kind === "avatar3d" ? "3D" : "2D"} by ${esc(m.creator)} · 🔮 ${m.price}</small></div><button class="btn ghost" data-cp="${m.id}">👁 Look</button><button class="btn" data-cd="${m.id}" data-ok="1">Approve</button><button class="btn ghost" data-cd="${m.id}">Reject</button></div>`).join("") || `<p class="muted">Nothing waiting.</p>`) : ""}
        </div>${modal}`;
      }
      body.addEventListener("click", async e => {
        const g = s => e.target.closest(s);
        const done = (t) => { msg = t; modal = ""; load(); };
        try {
          if (g("[data-a=close]") && !(g("[data-keep]") && !e.target.closest("button"))) { modal = ""; return draw(); }
          if (g("[data-a=reload]")) return load();
          if (g("[data-gp]")) {
            const c = await window.BV.auth.client(), { data } = await c.from("gc_games").select("code,title").eq("id", g("[data-gp]").dataset.gp).maybeSingle();
            if (!data) { msg = "Couldn't load it"; return draw(); }
            modal = `<div class="modal" data-a="close"><div data-keep style="width:min(760px,96vw)"><b>${esc(data.title)}</b> <button class="btn ghost" data-a="close" style="float:right">✕</button><iframe data-c="pf" style="width:100%;height:430px;border:1px solid rgba(120,120,140,.3);border-radius:10px;background:#fff;margin-top:8px" sandbox="allow-scripts allow-forms allow-popups allow-modals allow-pointer-lock"></iframe></div></div>`;
            draw(); body.querySelector("[data-c=pf]").srcdoc = data.code; return;
          }
          if (g("[data-gd]")) {
            const id = g("[data-gd]").dataset.gd, ok = !!g("[data-gd]").dataset.ok, c = await window.BV.auth.client();
            const r = ok ? await c.from("gc_games").update({ approved: true }).eq("id", id) : await c.from("gc_games").delete().eq("id", id);
            return r.error ? (msg = "Couldn't do that: " + r.error.message, draw()) : done(ok ? "Approved ✔" : "Rejected");
          }
          if (g("[data-cp]")) {
            const d = await P().rpc("bv_creation_data", { cid: g("[data-cp]").dataset.cp });
            if (d?.kind === "avatar3d" && d.model && window.BlockvileOS) { msg = "3D costumes: look at it in Shop & Quests (the model viewer is there)."; return draw(); }
            if (d?.image) { modal = `<div class="modal" data-a="close"><div data-keep><b>${esc(d.name || "")}</b> <button class="btn ghost" data-a="close" style="float:right">✕</button><br><img src="${esc(d.image)}" style="max-width:min(420px,90vw);margin-top:8px;border-radius:12px" alt=""></div></div>`; return draw(); }
            msg = "Nothing to show"; return draw();
          }
          if (g("[data-cd]")) { const ok = !!g("[data-cd]").dataset.ok; const r = await P().rpc("bv_creation_decide", { cid: g("[data-cd]").dataset.cd, ok }); return done(typeof r === "string" && r !== "ok" ? r : ok ? "Approved ✔" : "Rejected"); }
        } catch (er) { msg = "Something went wrong: " + (er.message || er); draw(); }
      });
      draw(); load();
      return cleanup;
    }
  });

  A.push({
    id: "suspiciouslogs", name: "Suspicious Logs", icon: "🚨", bg: "linear-gradient(135deg,#ff5a4f,#9b1c4a)", cat: "Admin", dock: true, hidden: true, size: [900, 660], net: true,
    keywords: "suspicious logs security alerts admin failed login spam",
    render(body, os) {
      let lvl = "", rows = [], msg = "", loaded = false;
      const cleanup = shell(body, { draw: () => draw() });
      const KN = { failed_login: "Wrong password", password_guessing: "Password guessing", many_new_accounts: "Many new accounts", new_account: "New account", suspended_attempt: "Suspended user tried to act", ad_claim_too_fast: "Ad reward too fast", ad_daily_limit: "Ad daily limit", friend_request_flood: "Friend request spam", invite_flood: "Invite spam", admin_suspended: "Admin suspended someone", admin_active: "Admin reactivated someone", admin_orbs: "Admin changed Orbs" };
      const load = async () => {
        if (!isAdmin()) return draw();
        try { rows = (await P().rpc("bv_admin_logs", { lim: 150, lvl: lvl || null })) || []; msg = ""; } catch (e) { msg = "Couldn't load: " + (e.message || e); }
        loaded = true; draw();
      };
      function draw() {
        if (guard(body)) return;
        body.innerHTML = css + `<div class="ad"><div class="top"><h3>🚨 Suspicious Logs</h3><button class="btn ghost" data-a="reload" style="margin-left:auto">↻ Refresh</button></div>
        <div class="tabs">${[["", "All"], ["high", "🔴 High"], ["warn", "🟠 Warning"], ["info", "⚪ Info"]].map(([k, n]) => `<button class="btn ghost" data-lv="${k}" aria-pressed="${k === lvl}">${n}</button>`).join("")}</div>
        ${msg ? `<div class="note">${esc(msg)}</div>` : ""}
        ${loaded ? (rows.map(r => `<div class="row"><span class="lv ${esc(r.level)}">${esc(r.level.toUpperCase())}</span><div class="g"><b>${esc(KN[r.kind] || r.kind)}</b> <small class="muted">${ago(r.at)}</small><br><small>${esc(r.email || "unknown")}</small> <small class="muted">${esc(r.detail || "")}</small></div>${r.email ? `<button class="btn ghost" data-mod="${esc(r.email)}">Open in Moderation</button>` : ""}</div>`).join("") || `<p class="muted">All quiet — nothing to show.</p>`) : `<p class="muted">Loading…</p>`}</div>`;
      }
      body.addEventListener("click", e => {
        const g = s => e.target.closest(s);
        if (g("[data-a=reload]")) return load();
        if (g("[data-lv]")) { lvl = g("[data-lv]").dataset.lv; return load(); }
        if (g("[data-mod]")) return os.open("moderation", { q: g("[data-mod]").dataset.mod });
      });
      draw(); load();
      return cleanup;
    }
  });

  A.push({
    id: "moderation", name: "Account Moderation", icon: "🛡️", bg: "linear-gradient(135deg,#6a4dff,#2c2f7a)", cat: "Admin", dock: true, hidden: true, size: [940, 680], net: true,
    keywords: "account moderation suspend ban plus orbs users admin",
    render(body, os, args) {
      let q = args?.q || "", users = [], msg = "", open = null, loaded = false;
      const cleanup = shell(body, { draw: () => draw() });
      const load = async () => {
        if (!isAdmin()) return draw();
        try { users = (await P().rpc("bv_admin_users", { q })) || []; } catch (e) { msg = "Couldn't load: " + (e.message || e); }
        loaded = true; draw();
      };
      const rpc = async (name, a, okText) => { try { const r = await P().rpc(name, a); if (r && r !== "ok") msg = "⚠️ " + r; else msg = okText; } catch (e) { msg = "⚠️ " + (e.message || e); } await load(); };
      function draw() {
        if (guard(body)) return;
        const u = users.find(x => x.id === open);
        body.innerHTML = css + `<div class="ad"><div class="top"><h3>🛡️ Account Moderation</h3></div>
        <div class="top"><input class="f" data-c="q" placeholder="Search email or username" value="${esc(q)}" style="flex:1"><button class="btn" data-a="search">Search</button></div>
        ${msg ? `<div class="note">${esc(msg)}</div>` : ""}
        ${u ? userV(u) : loaded ? (users.map(x => `<div class="row"><div class="g"><b>${esc(x.username || "(no name)")}</b> <small class="muted">${esc(x.email)}</small><br><small class="muted">${x.status === "suspended" ? "⛔ Suspended" : "Active"}${x.plus ? " · ⭐ Plus" : ""} · 🔮 ${x.orbs}${x.is_admin ? " · 🛡 admin" : ""} · joined ${ago(x.created_at)}</small></div><button class="btn ghost" data-open="${x.id}">Manage</button></div>`).join("") || `<p class="muted">No accounts found.</p>`) : `<p class="muted">Loading…</p>`}</div>`;
      }
      const userV = u => `<div class="top"><button class="btn ghost" data-a="back">← Back</button></div>
        <div class="row"><div class="g"><b style="font-size:16px">${esc(u.username || "(no name)")}</b><br><small>${esc(u.email)}</small><br><small class="muted">${u.status === "suspended" ? "⛔ Suspended" + (u.suspended_reason ? " — " + esc(u.suspended_reason) : "") : "✅ Active"}${u.plus ? " · ⭐ Plus" + (u.plus_until ? " until " + new Date(u.plus_until).toLocaleDateString() : "") : ""} · 🔮 ${u.orbs}${u.last_seen ? " · seen " + ago(u.last_seen) : ""}</small></div></div>
        ${u.is_admin ? `<p class="muted">This is an admin account — it can't be suspended.</p>` : u.status === "suspended"
          ? `<div class="row"><div class="g"><b>Reactivate</b><br><small class="muted">They can sign in again.</small></div><button class="btn" data-a="activate">Reactivate</button></div>`
          : `<div class="row"><div class="g"><b>Suspend</b><br><input class="f" data-c="why" placeholder="Reason (they will see it)" style="width:100%;margin-top:4px"></div><button class="btn" data-a="suspend">Suspend</button></div>`}
        <div class="row"><div class="g"><b>Blockvile Plus</b><br><small class="muted">Days (empty = no end date)</small> <input class="f" data-c="days" type="number" min="1" style="width:90px"></div><button class="btn" data-a="plus1">Give Plus</button><button class="btn ghost" data-a="plus0">Remove Plus</button></div>
        <div class="row"><div class="g"><b>Orbs</b><br><input class="f" data-c="orbs" type="number" value="50" style="width:100px"> <small class="muted">use a minus number to take away</small></div><button class="btn" data-a="orbs">Change Orbs</button></div>
        <div class="row"><div class="g"><b>Role &amp; notes</b><br><input class="f" data-c="role" placeholder="Role" value="${esc(u.role || "")}" style="width:140px"> <input class="f" data-c="notes" placeholder="Private notes" value="${esc(u.notes || "")}" style="width:100%;margin-top:4px"></div><button class="btn" data-a="notes">Save</button></div>`;
      const val = c => body.querySelector(`[data-c=${c}]`)?.value;
      body.addEventListener("click", e => {
        const g = s => e.target.closest(s);
        if (g("[data-a=search]")) { q = val("q") || ""; open = null; return load(); }
        if (g("[data-open]")) { open = g("[data-open]").dataset.open; msg = ""; return draw(); }
        if (g("[data-a=back]")) { open = null; return load(); }
        if (!open) return;
        const a = g("[data-a]")?.dataset.a;
        if (a === "suspend") return rpc("bv_admin_set_status", { uid: open, st: "suspended", why: val("why") || "" }, "Suspended");
        if (a === "activate") return rpc("bv_admin_set_status", { uid: open, st: "active", why: "" }, "Reactivated");
        if (a === "plus1") return rpc("bv_admin_set_plus", { uid: open, on_: true, days: +val("days") || null }, "Plus given");
        if (a === "plus0") return rpc("bv_admin_set_plus", { uid: open, on_: false, days: null }, "Plus removed");
        if (a === "orbs") return rpc("bv_admin_add_orbs", { uid: open, delta: parseInt(val("orbs"), 10) || 0 }, "Orbs changed");
        if (a === "notes") return rpc("bv_admin_set_notes", { uid: open, r: val("role") || "", n: val("notes") || "" }, "Saved");
      });
      body.addEventListener("keydown", e => { if (e.key === "Enter" && e.target.matches("[data-c=q]")) { q = e.target.value; open = null; load(); } });
      draw(); load();
      return cleanup;
    }
  });

  // show the admin apps only to an admin, and say what is waiting
  let told = false;
  const sync = async () => {
    const ids = ["approvals", "suspiciouslogs", "moderation"], on = isAdmin();
    let changed = false;
    A.forEach(a => { if (ids.includes(a.id) && a.hidden === on) { a.hidden = !on; changed = true; } });
    if (changed) window.BlockvileOS?.refreshApps();
    if (on && !told) {
      told = true;
      try {
        const n = await P().rpc("bv_admin_counts");
        if (n) { const bits = []; if (n.apps + n.costumes) bits.push((n.apps + n.costumes) + " waiting for approval"); if (n.high) bits.push(n.high + " serious alert" + (n.high > 1 ? "s" : "")); if (bits.length) window.BlockvileOS?.toast("🛡 " + bits.join(" · ")); }
      } catch { }
    }
    if (!on) told = false;
  };
  window.addEventListener("bv:profile", sync);
})();
