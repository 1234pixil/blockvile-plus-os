/* Blockvile Plus OS — accounts: sign in with Google, Microsoft or any email (Supabase), link this device,
   and open / read your Google and Microsoft services. Powers BV.auth, used by the Digital SIM and Blockvile AI. */
(() => {
  const { esc, store } = window.BV;
  const CFG = () => window.BV_CONFIG || {};
  const LIB = "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.min.js";
  const isAndroid = () => !!window.BV.android?.available;

  /* ---------- tiny helpers ---------- */
  const ss = { get(k) { try { return sessionStorage.getItem(k); } catch { return null; } }, set(k, v) { try { v == null ? sessionStorage.removeItem(k) : sessionStorage.setItem(k, v); } catch { } } };
  const emit = () => window.dispatchEvent(new Event("bv:auth"));

  /* ---------- Supabase settings: the publisher's config.js wins; otherwise what the user pasted in Accounts → Setup ---------- */
  const settings = () => {
    const c = CFG().supabase || {}, fromConfig = !!(c.url && c.anonKey);
    // When the publisher's config.js has a project, sign-in ALWAYS uses that one (never a project someone typed in or an old saved one).
    if (fromConfig) { if (store.get("supabaseCfg", null)) store.del("supabaseCfg"); return { url: c.url.trim().replace(/\/+$/, ""), key: c.anonKey.trim(), fn: c.aiFunction || "blockvile-ai", yt: c.youtubeFunction || "blockvile-youtube", fromConfig: true }; }
    const mine = store.get("supabaseCfg", {});
    return { url: (mine.url || "").trim().replace(/\/+$/, ""), key: (mine.anonKey || "").trim(), fn: c.aiFunction || "blockvile-ai", yt: c.youtubeFunction || "blockvile-youtube", fromConfig: false };
  };
  const validUrl = u => /^https:\/\/[a-z0-9-]+\.supabase\.(co|in)$/i.test(u);
  const configured = () => { const s = settings(); return validUrl(s.url) && s.key.length > 20 && !/service_role/i.test(s.key); };

  /* ---------- load the Supabase library only when it's needed ---------- */
  let libPromise = null, sb = null;
  const loadLib = () => libPromise || (libPromise = new Promise((res, rej) => {
    if (window.supabase?.createClient) return res();
    const add = (src, next) => { const el = document.createElement("script"); el.src = src; el.async = true;
      el.onload = () => (window.supabase?.createClient ? res() : next ? next() : rej(new Error("Sign-in library didn't start")));
      el.onerror = () => next ? next() : (libPromise = null, rej(new Error("Couldn't load the sign-in library — check your internet connection")));
      document.head.appendChild(el); };
    const cdn = () => add(LIB), local = () => add("js/vendor/supabase.js", cdn);
    // the one-file copy carries the library inside itself, so sign-in works even when the CDN is blocked
    const emb = document.getElementById("bv-sb-lib");
    if (emb) { try { const u = URL.createObjectURL(new Blob([Uint8Array.from(atob(emb.textContent.trim()), c => c.charCodeAt(0))], { type: "text/javascript" })); return add(u, local); } catch { } }
    local();
  }));
  const storage = { getItem: k => store.get("sb:" + k, null), setItem: (k, v) => store.set("sb:" + k, v), removeItem: k => store.set("sb:" + k, null) };
  async function client() {
    if (!configured()) throw new Error("Sign-in isn't set up yet — open Accounts → Setup");
    if (sb) return sb;
    await loadLib();
    const s = settings();
    sb = window.supabase.createClient(s.url, s.key, { auth: { storage, persistSession: true, autoRefreshToken: true, detectSessionInUrl: false, flowType: "pkce" } });
    sb.auth.onAuthStateChange((ev, session) => {
      if (session?.provider_token) { ss.set("bv:ptoken", session.provider_token); ss.set("bv:pprovider", session.user?.app_metadata?.provider || ""); }
      if (ev === "PASSWORD_RECOVERY") { auth.recovering = true; window.BlockvileOS?.open("accounts"); }
      auth.user = session?.user || null; auth.session = session || null; syncApps(); emit();
      if (session?.user && ev !== "TOKEN_REFRESHED") setTimeout(() => profile.load(), 0); else if (!session) profile.data = null;
    });
    return sb;
  }

  /* ---------- my Blockvile profile: Orbs, avatar, Plus, and active / suspended ---------- */
  const profile = {
    data: null,
    async load() {
      if (!auth.user) { profile.data = null; return null; }
      try {
        const c = await auth.client(), { data, error } = await c.rpc("bv_me"); if (error) throw error;
        profile.data = data;
        if (data?.status === "suspended") { auth.suspended = data.reason || "Your account is suspended. Contact ethanabraham09092014@gmail.com."; profile.data = null; await auth.signOut(); window.BlockvileOS?.toast("⛔ " + auth.suspended); }
      } catch (e) { /* the SQL isn't run yet: Orbs and the Shop stay off */ }
      window.dispatchEvent(new Event("bv:profile")); return profile.data;
    },
    async rpc(name, args) { const c = await auth.client(), { data, error } = await c.rpc(name, args || {}); if (error) throw error; return data; },
  };
  window.BV.profile = profile;

  /* ---------- the public auth object ---------- */
  const redirectTo = () => isAndroid() ? "blockvile://auth" : location.origin + location.pathname;
  const canRedirect = () => isAndroid() || /^https?:$/.test(location.protocol);
  const auth = {
    user: null, session: null, recovering: false, suspended: null,
    configured, settings,
    signedIn: () => !!auth.user,
    email: () => auth.user?.email || "",
    name: () => auth.user?.user_metadata?.full_name || auth.user?.user_metadata?.name || (auth.user?.email || "").split("@")[0],
    provider: () => auth.user?.app_metadata?.provider || "email",
    providerToken: () => ss.get("bv:ptoken"),
    providerOfToken: () => ss.get("bv:pprovider"),
    client,
    // which sign-in buttons are really switched on in Supabase (so we never show one that fails)
    provs: null,
    async providers() {
      if (auth.provs) return auth.provs;
      try {
        const cfg = settings(); if (!cfg.url || !cfg.key) return null;
        const r = await fetch(cfg.url + "/auth/v1/settings", { headers: { apikey: cfg.key } });
        if (!r.ok) return null;
        const j = await r.json(), x = j.external || {};
        auth.provs = { google: !!x.google, azure: !!x.azure, github: !!x.github, email: x.email !== false };
      } catch { return null; }
      return auth.provs;
    },
    async init() {
      if (auth.takeRecovery(location.href)) { auth.recovering = true; try { history.replaceState(null, "", location.pathname + location.search); } catch { } window.BlockvileOS?.open("accounts"); emit(); }
      if (!configured()) return;
      const c = await client();
      const { data } = await c.auth.getSession();
      auth.user = data.session?.user || null; auth.session = data.session || null; syncApps(); emit();
      // Returning from Google / Microsoft in a normal browser
      const u = new URL(location.href);
      if (u.searchParams.get("code") && !isAndroid()) await auth.deepLink(location.href, true);
      const pending = window.__bvDeep || window.BV.android?.pendingDeepLink?.();
      if (pending) await auth.deepLink(pending);
    },
    // Called when Google/Microsoft sends the user back (browser address, or blockvile://auth on Android)
    async deepLink(url, clean) {
      try {
        const c = await client(), u = new URL(url), code = u.searchParams.get("code");
        if (auth.takeRecovery(url)) { auth.recovering = true; window.BlockvileOS?.open("accounts"); emit(); return; }
        const err = u.searchParams.get("error_description") || u.searchParams.get("error");
        if (err) throw new Error(err);
        if (code) { const { error } = await c.auth.exchangeCodeForSession(code); if (error) throw error; window.BlockvileOS?.toast("✅ Signed in"); }
      } catch (e) { window.BlockvileOS?.toast("⚠️ " + (e.message || "Sign-in didn't finish")); }
      finally { window.__bvDeep = null; if (clean) try { history.replaceState(null, "", location.pathname); } catch { } }
    },
    async signUp(email, password, name) {
      const c = await client();
      const { data, error } = await c.auth.signUp({ email, password, options: { data: { full_name: name || "" }, emailRedirectTo: redirectTo() } });
      if (error) throw error;
      return { needsConfirm: !data.session };
    },
    async newPassword(password) { const c = await client(); const { error } = await c.auth.updateUser({ password }); if (error) throw error; auth.recovering = false; await auth.signOut(); },
    async signIn(email, password) { auth.suspended = null; const c = await client(); const { error } = await c.auth.signInWithPassword({ email, password }); if (error) { try { c.rpc("bv_report_login_fail", { mail: email }).then(() => { }, () => { }); } catch { } throw error; } },
    // Password reset: the email link works in any browser or phone (no auto sign-in). The link only lets you choose a new password.
    recToken: null,
    async reset(email) {
      const s = settings(); if (!configured()) throw new Error("Sign-in isn't set up yet — open Accounts → Setup");
      const r = await fetch(s.url + "/auth/v1/recover?redirect_to=" + encodeURIComponent(redirectTo()), { method: "POST", headers: { apikey: s.key, "Content-Type": "application/json" }, body: JSON.stringify({ email }) });
      if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(j.msg || j.message || j.error_description || "Couldn't send the reset email"); }
    },
    // read the #access_token&type=recovery part of the reset link
    takeRecovery(url) {
      try {
        const h = new URL(url, location.href).hash.replace(/^#/, ""); if (!h) return false;
        const q = new URLSearchParams(h);
        if (q.get("error_description") || q.get("error")) { auth.recError = (q.get("error_description") || q.get("error")).replace(/\+/g, " "); return true; }
        if (q.get("type") === "recovery" && q.get("access_token")) { auth.recToken = q.get("access_token"); auth.recError = null; return true; }
      } catch { }
      return false;
    },
    async setNewPassword(password) {
      const s = settings(); if (!auth.recToken) throw new Error("That reset link has expired. Press Forgot password to get a new one.");
      const r = await fetch(s.url + "/auth/v1/user", { method: "PUT", headers: { apikey: s.key, Authorization: "Bearer " + auth.recToken, "Content-Type": "application/json" }, body: JSON.stringify({ password }) });
      if (!r.ok) { const j = await r.json().catch(() => ({})); const m = j.msg || j.message || j.error_description || ""; if (/same/i.test(m)) throw new Error("Choose a different password from your old one."); if (r.status === 401 || r.status === 403) { auth.recToken = null; throw new Error("That reset link has expired. Press Forgot password to get a new one."); } throw new Error(m || "Couldn't change the password"); }
      auth.recToken = null; auth.recovering = false;
    },
    // signed in: change password properly (asks for the current one first)
    async changePassword(current, password) {
      const c = await client(); if (!auth.user) throw new Error("Sign in first");
      const { error: e1 } = await c.auth.signInWithPassword({ email: auth.user.email, password: current }); if (e1) throw new Error("Your current password isn't right");
      const { error } = await c.auth.updateUser({ password }); if (error) throw error;
    },
    // provider: "google" | "azure" | "github". "extra" asks for permission to read mail, calendar and files too.
    async oauth(provider, extra) {
      if (!canRedirect()) throw new Error("Google, Microsoft and GitHub sign-in need the hosted website or the Android app (not a file opened from your computer)");
      const c = await client(), gh = provider === "github", p = gh ? null : SERVICES[provider === "azure" ? "microsoft" : "google"];
      const { data, error } = await c.auth.signInWithOAuth({
        provider, options: {
          redirectTo: redirectTo(), skipBrowserRedirect: true,
          scopes: gh ? "read:user user:email" : extra ? p.scopes.join(" ") : p.basic.join(" "),
          queryParams: gh ? {} : provider === "google" ? { access_type: "offline", prompt: "consent" } : { prompt: "select_account" },
        }
      });
      if (error) throw error;
      // Google refuses to load inside a frame or an app's built-in browser, so it always opens on its own
      if (isAndroid() || BV.embedded) window.open(data.url, "_blank", "noopener"); else location.assign(data.url);
    },
    async signOut() {
      try { const c = await client(); await c.auth.signOut(); } catch { }
      auth.user = null; auth.session = null; ss.set("bv:ptoken", null); ss.set("bv:pprovider", null); syncApps(); emit();
    },
  };

  /* ---------- Google & Microsoft services ---------- */
  const SERVICES = {
    google: {
      name: "Google", icon: "🟦", provider: "google",
      basic: ["openid", "email", "profile"],
      scopes: ["openid", "email", "profile", "https://www.googleapis.com/auth/gmail.readonly", "https://www.googleapis.com/auth/calendar.readonly", "https://www.googleapis.com/auth/drive.readonly"],
      apps: [
        ["📧", "Gmail", "com.google.android.gm", "https://mail.google.com/"], ["📁", "Drive", "com.google.android.apps.docs", "https://drive.google.com/"],
        ["📄", "Docs", "com.google.android.apps.docs.editors.docs", "https://docs.google.com/document/"], ["📊", "Sheets", "com.google.android.apps.docs.editors.sheets", "https://docs.google.com/spreadsheets/"],
        ["📽", "Slides", "com.google.android.apps.docs.editors.slides", "https://docs.google.com/presentation/"], ["📅", "Calendar", "com.google.android.calendar", "https://calendar.google.com/"],
        ["🎥", "Meet", "com.google.android.apps.tachyon", "https://meet.google.com/"], ["🖼", "Photos", "com.google.android.apps.photos", "https://photos.google.com/"],
        ["🗺", "Maps", "com.google.android.apps.maps", "https://maps.google.com/"], ["▶️", "YouTube", "com.google.android.youtube", "https://www.youtube.com/"],
        ["👥", "Contacts", "com.google.android.contacts", "https://contacts.google.com/"], ["🗒", "Keep", "com.google.android.keep", "https://keep.google.com/"],
        ["🌐", "Translate", "com.google.android.apps.translate", "https://translate.google.com/"], ["👤", "My Account", "", "https://myaccount.google.com/"],
      ],
    },
    microsoft: {
      name: "Microsoft", icon: "🟧", provider: "azure",
      basic: ["openid", "email", "profile", "offline_access"],
      scopes: ["openid", "email", "profile", "offline_access", "User.Read", "Mail.Read", "Calendars.Read", "Files.Read"],
      apps: [
        ["📧", "Outlook", "com.microsoft.office.outlook", "https://outlook.live.com/mail/"], ["☁️", "OneDrive", "com.microsoft.skydrive", "https://onedrive.live.com/"],
        ["📄", "Word", "com.microsoft.office.word", "https://www.office.com/launch/word"], ["📊", "Excel", "com.microsoft.office.excel", "https://www.office.com/launch/excel"],
        ["📽", "PowerPoint", "com.microsoft.office.powerpoint", "https://www.office.com/launch/powerpoint"], ["💬", "Teams", "com.microsoft.teams", "https://teams.microsoft.com/"],
        ["📓", "OneNote", "com.microsoft.office.onenote", "https://www.onenote.com/notebooks"], ["✅", "To Do", "com.microsoft.todos", "https://to-do.live.com/"],
        ["📅", "Calendar", "com.microsoft.office.outlook", "https://outlook.live.com/calendar/"], ["👥", "People", "", "https://outlook.live.com/people/"],
        ["🧩", "Microsoft 365", "com.microsoft.office.officehubrow", "https://www.office.com/"], ["👤", "My Account", "", "https://account.microsoft.com/"],
      ],
    },
  };
  // Opens the real app on Android if it's installed, otherwise the website
  function openService(pkg, url) {
    const a = window.BV.android;
    if (a?.available && pkg && a.installed(pkg)) return a.launch(pkg);
    window.BV.openWeb(url);   // websites open inside Blockvile
  }
  // What we can read once the user has allowed it (token lives for this visit only and is never saved)
  async function get(url, token) {
    const r = await fetch(url, { headers: { Authorization: "Bearer " + token } });
    if (r.status === 401 || r.status === 403) throw new Error("denied");
    if (!r.ok) throw new Error("failed");
    return r.json();
  }
  const DATA = {
    google: async t => {
      const [mail, cal, drv] = await Promise.allSettled([
        get("https://gmail.googleapis.com/gmail/v1/users/me/labels/INBOX", t),
        get("https://www.googleapis.com/calendar/v3/calendars/primary/events?maxResults=4&singleEvents=true&orderBy=startTime&timeMin=" + encodeURIComponent(new Date().toISOString()), t),
        get("https://www.googleapis.com/drive/v3/files?pageSize=4&orderBy=modifiedTime%20desc&fields=files(id,name,webViewLink)", t)]);
      const v = x => x.status === "fulfilled" ? x.value : null;
      return {
        unread: v(mail)?.messagesUnread ?? null,
        events: (v(cal)?.items || []).map(e => ({ title: e.summary || "(no title)", when: e.start?.dateTime || e.start?.date, url: e.htmlLink })),
        files: (v(drv)?.files || []).map(f => ({ title: f.name, url: f.webViewLink })),
        denied: [mail, cal, drv].every(x => x.status === "rejected"),
      };
    },
    microsoft: async t => {
      const now = new Date(), end = new Date(now.getTime() + 7 * 864e5);
      const [mail, cal, drv] = await Promise.allSettled([
        get("https://graph.microsoft.com/v1.0/me/mailFolders/inbox?$select=unreadItemCount", t),
        get(`https://graph.microsoft.com/v1.0/me/calendarview?startdatetime=${now.toISOString()}&enddatetime=${end.toISOString()}&$top=4&$orderby=start/dateTime&$select=subject,start,webLink`, t),
        get("https://graph.microsoft.com/v1.0/me/drive/recent?$top=4", t)]);
      const v = x => x.status === "fulfilled" ? x.value : null;
      return {
        unread: v(mail)?.unreadItemCount ?? null,
        events: (v(cal)?.value || []).map(e => ({ title: e.subject || "(no title)", when: e.start?.dateTime ? e.start.dateTime + "Z" : "", url: e.webLink })),
        files: (v(drv)?.value || []).map(f => ({ title: f.name, url: f.webUrl })),
        denied: [mail, cal, drv].every(x => x.status === "rejected"),
      };
    },
  };

  /* ---------- link this device to the account ---------- */
  const deviceKey = () => { let k = store.get("deviceKey", ""); if (!k) { k = (crypto.randomUUID?.() || Date.now().toString(36) + Math.random().toString(36).slice(2)); store.set("deviceKey", k); } return k; };
  const deviceName = () => {
    const d = window.BV.android?.device?.() || {};
    if (d.model) return d.model;
    const ua = navigator.userAgent;
    const os = /Windows/.test(ua) ? "Windows" : /Android/.test(ua) ? "Android" : /iPhone|iPad/.test(ua) ? "iOS" : /Mac OS/.test(ua) ? "Mac" : /CrOS/.test(ua) ? "Chromebook" : /Linux/.test(ua) ? "Linux" : "device";
    const br = /Edg\//.test(ua) ? "Edge" : /Chrome\//.test(ua) ? "Chrome" : /Firefox\//.test(ua) ? "Firefox" : /Safari\//.test(ua) ? "Safari" : "browser";
    return `${os} · ${br}`;
  };
  const devices = {
    async list() { const c = await client(); const { data, error } = await c.from("devices").select("*").order("last_seen", { ascending: false }); if (error) throw error; return data; },
    async link() {
      const c = await client();
      const { error } = await c.from("devices").upsert({ user_id: auth.user.id, device_key: deviceKey(), name: deviceName(), platform: isAndroid() ? "android" : "web", last_seen: new Date().toISOString() }, { onConflict: "user_id,device_key" });
      if (error) throw error; store.set("deviceLinked:" + auth.user.id, true);
    },
    async unlink(id) { const c = await client(); const { error } = await c.from("devices").delete().eq("id", id); if (error) throw error; },
    isThis: d => d.device_key === deviceKey(),
    isLinked: () => !!(auth.user && store.get("deviceLinked:" + auth.user.id, false)),
    async touch() { if (devices.isLinked()) try { await devices.link(); } catch { } },
  };

  /* ---------- the Digital SIM only exists while signed in ---------- */
  function syncApps() {
    const os = window.BlockvileOS; if (!os?.registerApp) return;
    const has = !!os.apps().find(a => a.id === "sim");
    if (auth.user && !has) os.registerApp(SIM_APP());
    if (!auth.user && has) os.unregisterApp("sim");
  }

  window.BV.auth = auth; window.BV.services = { SERVICES, openService, DATA, devices, deviceName, deviceKey };
  window.BV.accountsInternals = { SIM_APP: null };
  const SIM_APP = () => window.BV.simApp;

  /* ================= Accounts app ================= */
  window.BV_APPS.push({
    id: "accounts", name: "Accounts", icon: "👤", bg: "linear-gradient(135deg,#6366f1,#22d3ee)", cat: "System", system: true, size: [520, 600],
    keywords: "account sign in login google microsoft email supabase link device gmail outlook onedrive drive services",
    render(body, os, args) {
      let draft = null, tab = args?.tab || "in", busy = false, note = "", devs = null, svcData = {}, setup = false;
      const flash = (m, bad) => { note = (bad ? "⚠️ " : "") + m; draw(); };
      const btn = (act, label, cls = "") => `<button class="btn ${cls}" data-do="${act}" ${busy ? "disabled" : ""}>${label}</button>`;
      const err = e => { const m = String(e?.message || e || "");
        if (/Invalid login/i.test(m)) return "Wrong email or password";
        if (/provider is not enabled|Unsupported provider/i.test(m)) return "That sign-in isn't switched on yet. Use your email and password below.";
        if (/already registered|already been registered/i.test(m)) return "That email already has an account. Tap Sign in instead.";
        if (/not confirmed/i.test(m)) return "Please open the email we sent and confirm your address, then sign in.";
        if (/rate limit|too many/i.test(m)) return "Too many tries. Wait a minute and try again.";
        if (/failed to fetch|networkerror|load failed/i.test(m)) return "Can't reach the database. Check your internet and try again.";
        if (/password.*(short|least|weak)/i.test(m)) return "Use a longer password (at least 8 characters).";
        return m; };

      const setupBox = () => `<details class="ac-setup" ${setup || !auth.configured() ? "open" : ""}><summary><b>Setup</b> — connect your Supabase project</summary>
        <p class="muted" style="font-size:13px">Make a free project at supabase.com, run <code>supabase/schema.sql</code> in its SQL Editor, then paste the two values from <b>Project Settings → API</b>. Use the <b>anon / publishable</b> key — never the service_role key.</p>
        ${auth.settings().fromConfig ? `<p class="muted">✅ Set by the publisher of this copy of Blockvile.</p>` : `
          <input class="field" data-su placeholder="Project URL  https://xxxx.supabase.co" value="${esc(draft ? draft.url : auth.settings().url)}" style="margin-bottom:8px">
          <input class="field" data-sk placeholder="anon / publishable key" value="${esc(draft ? draft.key : auth.settings().key)}" style="margin-bottom:8px">
          ${btn("savecfg", "Save")}`}
        <p class="muted" style="font-size:12px;margin-top:10px">For Google/Microsoft/GitHub sign-in, turn the providers on in Supabase → Authentication → Providers, and add <code>${esc(redirectTo())}</code> to Redirect URLs.</p></details>`;

      const signedOut = () => `
        ${auth.suspended ? `<div class="tip" style="margin-bottom:10px">⛔ ${esc(auth.suspended)}</div>` : ""}
        <div class="seg"><button data-tab="in" class="${tab === "in" ? "on" : ""}">Sign in</button><button data-tab="up" class="${tab === "up" ? "on" : ""}">Create account</button></div>
        ${(() => { const pv = auth.provs || {}; const bs = [pv.google ? `<button class="btn ghost ac-g" data-do="google" ${busy ? "disabled" : ""}><b style="color:#4285f4">G</b> Continue with Google</button>` : "",
          pv.azure ? `<button class="btn ghost ac-m" data-do="azure" ${busy ? "disabled" : ""}><b style="color:#f25022">▪</b> Continue with Microsoft</button>` : "",
          pv.github ? `<button class="btn ghost ac-h" data-do="github" ${busy ? "disabled" : ""}><b>🐙</b> Continue with GitHub</button>` : ""].join("");
          return bs ? `<div class="ac-oauth">${bs}</div><p class="muted" style="text-align:center;margin:14px 0">or use any email address</p>` : `<p class="muted" style="text-align:center;margin:10px 0 14px">Sign in with your email address</p>`; })()}
        <form data-form>
          ${tab === "up" ? `<input class="field" name="name" placeholder="Your name" autocomplete="name" style="margin-bottom:8px">` : ""}
          <input class="field" name="email" type="email" placeholder="Email (Gmail, Outlook, your own…)" autocomplete="email" required style="margin-bottom:8px">
          <input class="field" name="password" type="password" placeholder="Password${tab === "up" ? " (at least 8 characters)" : ""}" autocomplete="${tab === "up" ? "new-password" : "current-password"}" minlength="${tab === "up" ? 8 : 1}" required style="margin-bottom:12px">
          <button class="btn" style="width:100%" ${busy ? "disabled" : ""}>${tab === "up" ? "Create account" : "Sign in"}</button>
          ${tab === "in" ? `<button type="button" class="link-btn" data-do="forgot" style="margin-top:10px">Forgot password?</button>` : ""}
        </form>
        <p class="muted" style="font-size:12px;margin-top:12px">Signing in unlocks your <b>Digital SIM</b> and cloud features. Without an account, everything else in Blockvile still works.</p>`;

      const svcCard = key => {
        const S = SERVICES[key], linked = auth.providerOfToken() === S.provider && auth.providerToken(), d = svcData[key];
        const when = t => { const x = new Date(t); return isNaN(x) ? "" : x.toLocaleString([], { weekday: "short", hour: "2-digit", minute: "2-digit" }); };
        return `<div class="ac-svc"><h4>${S.icon} ${S.name} services</h4>
          <div class="ac-tiles">${S.apps.map(([ic, n, pkg, url]) => `<button class="ac-tile" data-svc="${key}" data-n="${esc(n)}"><span>${ic}</span>${esc(n)}</button>`).join("")}</div>
          ${linked ? (d ? (d.denied ? `<p class="muted">Couldn't read your ${S.name} data. Link again to allow it.</p>` : `
            <div class="list" style="margin-top:10px">
              <div><span>📧 Unread mail</span><b>${d.unread ?? "–"}</b></div>
              ${d.events.map(e => `<div data-url="${esc(e.url || "")}"><span>📅 ${esc(e.title)}</span><small>${esc(when(e.when))}</small></div>`).join("") || `<div><span class="muted">No upcoming events</span></div>`}
              ${d.files.map(f => `<div data-url="${esc(f.url || "")}"><span>📄 ${esc(f.title)}</span><small>open</small></div>`).join("")}
            </div>`) : `<p class="muted">Loading…</p>`)
            : `<button class="btn ghost" data-do="link-${S.provider}" style="margin-top:10px;width:100%" ${busy ? "disabled" : ""}>🔗 Link ${S.name} mail, calendar &amp; files</button>
               <p class="muted" style="font-size:12px;margin:6px 0 0">You choose what to allow on ${S.name}'s own page. Blockvile only reads, never sends or deletes, and doesn't keep the access after you close it.</p>`}</div>`;
      };

      const recovery = () => `<p><b>Choose a new password</b><br><small class="muted">You'll sign in with it afterwards.</small></p>${auth.recError ? `<div class="tip" style="margin-bottom:10px">⚠️ ${esc(auth.recError)} — press Forgot password to get a new link.</div>` : ""}<form data-newpw><input class="field" name="pw" type="password" minlength="8" placeholder="New password (at least 8 characters)" autocomplete="new-password" required style="margin-bottom:8px"><input class="field" name="pw2" type="password" minlength="8" placeholder="Type it again" autocomplete="new-password" required style="margin-bottom:12px"><button class="btn" style="width:100%" ${busy ? "disabled" : ""}>Save new password</button></form><button class="link-btn" data-do="cancelrec" style="margin-top:10px">Cancel</button>`;
      const changePw = () => `<details class="ac-setup"><summary><b>🔑 Change password</b></summary><form data-chpw style="margin-top:8px"><input class="field" name="cur" type="password" placeholder="Current password" autocomplete="current-password" required style="margin-bottom:8px"><input class="field" name="pw" type="password" minlength="8" placeholder="New password (at least 8 characters)" autocomplete="new-password" required style="margin-bottom:8px"><input class="field" name="pw2" type="password" minlength="8" placeholder="Type the new password again" autocomplete="new-password" required style="margin-bottom:10px"><button class="btn" ${busy ? "disabled" : ""}>Change password</button></form></details>`;
      const signedIn = () => `
        <div class="ac-me"><div class="ac-av">${profile.data?.ref_img ? `<img src="${esc(profile.data.ref_img)}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:inherit">` : esc(profile.data?.avatar || (auth.name() || "?")[0].toUpperCase())}</div>
          <div style="flex:1;min-width:0"><b>${esc(auth.name())}</b><br><small class="muted">${esc(auth.email())} · ${esc(auth.provider() === "azure" ? "Microsoft" : auth.provider() === "github" ? "GitHub" : auth.provider())}</small></div>
          ${btn("signout", "Sign out", "ghost")}</div>
        <div class="list" style="margin-top:14px">
          <button data-do="opensim"><span><b>📶 Digital SIM</b><br><small>Your Blockvile number — charges on Wi-Fi</small></span><small>›</small></button>
          <button data-do="openai"><span><b>✨ Blockvile AI</b><br><small>Ask anything or tell your device what to do</small></span><small>›</small></button>
        </div>
        <div class="ac-svc"><h4>📱 This device</h4>
          ${devs == null ? `<p class="muted">Loading…</p>` : `<div class="list">${devs.map(d => `<div><span>${d.platform === "android" ? "📱" : "💻"} ${esc(d.name)}${devices.isThis(d) ? ` <small>(this device)</small>` : ""}<br><small>Last seen ${new Date(d.last_seen).toLocaleDateString()}</small></span>${devices.isThis(d) ? "" : `<button class="btn ghost" style="padding:6px 10px" data-unlink="${d.id}">Unlink</button>`}</div>`).join("") || `<div><span class="muted">No linked devices yet</span></div>`}</div>`}
          ${devs && !devs.some(devices.isThis) ? btn("linkdev", "🔗 Link this device to my account") : `<p class="muted" style="font-size:12px">Linked devices share your account and SIM. Unlink any time.</p>`}
        </div>
        ${changePw()}
        ${svcCard("google")}${svcCard("microsoft")}`;

      const draw = () => {
        body.innerHTML = `<div class="ac">${note ? `<div class="tip" style="margin-bottom:12px">${esc(note)}</div>` : ""}
          ${auth.recovering && (auth.recToken || auth.recError || auth.user) ? recovery() : auth.user ? signedIn() : auth.configured() ? signedOut() : `<p>Sign in to unlock your <b>Digital SIM</b> and cloud features.</p>`}
          ${setupBox()}</div>`;
      };
      const load = async () => {
        if (!auth.user) return;
        try { devs = await devices.list(); await devices.touch(); } catch (e) { devs = []; note = "⚠️ Run supabase/schema.sql in your Supabase project (devices table missing)"; }
        draw();
        for (const k of ["google", "microsoft"]) {
          const t = auth.providerToken();
          if (t && auth.providerOfToken() === SERVICES[k].provider && !svcData[k]) { DATA[k](t).then(d => { svcData[k] = d; draw(); }).catch(() => { svcData[k] = { denied: true }; draw(); }); }
        }
      };
      const run = async fn => { busy = true; note = ""; draw(); try { await fn(); } catch (e) { note = "⚠️ " + err(e); } busy = false; draw(); };

      body.addEventListener("click", e => {
        const t = e.target.closest("[data-tab]"); if (t) { tab = t.dataset.tab; note = ""; return draw(); }
        const svc = e.target.closest("[data-svc]");
        if (svc) { const row = SERVICES[svc.dataset.svc].apps.find(a => a[1] === svc.dataset.n); return openService(row[2], row[3]); }
        const u = e.target.closest("[data-url]"); if (u && u.dataset.url) return window.BV.openWeb(u.dataset.url);
        const ul = e.target.closest("[data-unlink]"); if (ul) return run(async () => { await devices.unlink(ul.dataset.unlink); devs = await devices.list(); });
        const b = e.target.closest("[data-do]"); if (!b) return;
        const act = b.dataset.do;
        if (act === "savecfg") {
          const url = body.querySelector("[data-su]").value.trim().replace(/\/+$/, ""), key = body.querySelector("[data-sk]").value.trim();
          draft = { url, key };
          if (!validUrl(url)) return flash("That doesn't look like a Supabase project URL (https://xxxx.supabase.co)", true);
          if (/service_role/i.test(key) || key.length < 20) return flash("Use the anon / publishable key (not the service_role key)", true);
          store.set("supabaseCfg", { url, anonKey: key }); sb = null; setup = false; draft = null;
          return run(async () => { await auth.init(); note = "✅ Saved"; });
        }
        if (act === "google" || act === "azure" || act === "github") return run(() => auth.oauth(act, false));
        if (act === "link-google" || act === "link-azure") return run(() => auth.oauth(act.slice(5), true));
        if (act === "signout") return run(async () => { await auth.signOut(); devs = null; svcData = {}; });
        if (act === "cancelrec") { auth.recToken = null; auth.recError = null; auth.recovering = false; note = ""; return draw(); }
        if (act === "forgot") { const em = body.querySelector("[name=email]")?.value.trim(); if (!em) return flash("Type your email first", true); return run(async () => { await auth.reset(em); note = "📧 If that email has an account, a reset link is on its way"; }); }
        if (act === "linkdev") return run(async () => { await devices.link(); devs = await devices.list(); note = "✅ This device is linked"; });
        if (act === "opensim") return os.open("sim");
        if (act === "openai") return os.open("ai");
      });
      body.addEventListener("submit", e => {
        const np = e.target.closest("[data-newpw]");
        if (np) { e.preventDefault(); if (np.pw.value !== np.pw2.value) return flash("The two passwords don't match", true);
          return run(async () => { if (auth.recToken) await auth.setNewPassword(np.pw.value); else await auth.newPassword(np.pw.value); tab = "in"; note = "✅ Password changed. Now sign in with your new password."; }); }
        const cp = e.target.closest("[data-chpw]");
        if (cp) { e.preventDefault(); if (cp.pw.value !== cp.pw2.value) return flash("The two new passwords don't match", true); if (cp.pw.value === cp.cur.value) return flash("Choose a different password from your current one", true);
          return run(async () => { await auth.changePassword(cp.cur.value, cp.pw.value); note = "✅ Password changed"; }); }
        const f = e.target.closest("[data-form]"); if (!f) return; e.preventDefault();
        const em = f.email.value.trim(), pw = f.password.value;
        run(async () => {
          if (tab === "up") { const r = await auth.signUp(em, pw, f.name?.value.trim()); note = r.needsConfirm ? "📧 Almost done — open the email we sent to confirm your address, then sign in" : "✅ Account created"; if (r.needsConfirm) tab = "in"; }
          else await auth.signIn(em, pw);
        });
      });
      const onAuth = () => { if (!body.isConnected) return window.removeEventListener("bv:auth", onAuth); devs = null; svcData = {}; draw(); load(); };
      window.addEventListener("bv:auth", onAuth);
      const onProf = () => { if (!body.isConnected) return window.removeEventListener("bv:profile", onProf); draw(); };
      window.addEventListener("bv:profile", onProf);
      draw(); load();
      auth.providers().then(p => { if (p && body.isConnected) draw(); });
    }
  });

  /* start once the page is ready (os.js runs after this file) */
  window.addEventListener("load", () => setTimeout(() => { syncApps(); auth.init().catch(() => { }); }, 300));
})();
