/* Blockvile Plus OS — Debug Center app: see every problem Blockvile hit, copy or save the report, send it to the developer,
   or attach it to Feedback. Collection happens in debug-core.js. */
(() => {
  const { store, esc } = window.BV;
  const D = window.BV_DEBUG; if (!D) return;
  const CFG = () => window.BV_CONFIG || {};
  const os = () => window.BlockvileOS;
  const KINDS = { error: ["🔴", "Error"], network: ["🌐", "Network"], resource: ["🧩", "File"], warn: ["🟡", "Warning"] };
  const sharing = () => store.get("dbgShare", false) === true;

  function device() {
    const ua = navigator.userAgent, a = window.BV.android?.available ? window.BV.android.device?.() : null;
    const plat = a ? `Android ${a.android} (${a.model})` : /Android/.test(ua) ? "Android" : /iPhone|iPad/.test(ua) ? "iOS" : /Windows/.test(ua) ? "Windows" : /Mac/.test(ua) ? "macOS" : /Linux/.test(ua) ? "Linux" : "Other";
    const br = a ? "Blockvile Android app" : /Edg\//.test(ua) ? "Edge" : /Chrome\//.test(ua) ? "Chrome" : /Firefox\//.test(ua) ? "Firefox" : /Safari\//.test(ua) ? "Safari" : "Other";
    return `${plat} · ${br} · ${screen.width}x${screen.height} · ${os()?.state?.mode || ""} mode`;
  }
  const time = t => new Date(t).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const line = e => `[${new Date(e.t).toISOString()}] ${(KINDS[e.kind]?.[1] || e.kind).toUpperCase()} ${e.source}${e.n > 1 ? ` (x${e.n})` : ""}: ${e.msg}${e.stack ? "\n    " + e.stack.split("\n").slice(0, 4).join("\n    ") : ""}`;
  function report(list) {
    list = list || D.list();
    return [`Blockvile debug report`, `Version: ${CFG().version}`, `Device: ${device()}`, `Page: ${location.origin}${location.pathname}`, `Created: ${new Date().toISOString()}`, `Entries: ${list.length}`, "", ...list.map(line)].join("\n");
  }

  // ---- sending (only on the person's tap, or if they switched on automatic sharing) ----
  let sending = false, sessionSent = 0;
  async function send(list) {
    const A = window.BV.auth;
    if (!A?.configured?.()) throw new Error("Sending needs Blockvile's Supabase to be set up");
    if (navigator.onLine === false) throw new Error("You're offline");
    list = list.filter(e => e.kind !== "warn").slice(-30);
    if (!list.length) return 0;
    sending = true;
    try {
      const c = await A.client(), dev = device().slice(0, 200);
      const rows = list.map(e => ({ app_version: String(CFG().version || "").slice(0, 20), device: dev, kind: e.kind, source: e.source.slice(0, 80), message: e.msg.slice(0, 600), stack: (e.stack || "").slice(0, 1500) || null, page: (location.origin + location.pathname).slice(0, 200), happened_at: new Date(e.t).toISOString() }));
      const { error } = await c.from("debug_reports").insert(rows);
      if (error) throw new Error(error.message || "Couldn't send");
      D.mark(list); sessionSent += rows.length; return rows.length;
    } finally { sending = false; }
  }
  let autoT = 0;
  D.on(e => {
    if (!e || e.kind === "warn" || !sharing() || sessionSent > 60) return;
    clearTimeout(autoT);
    autoT = setTimeout(() => { if (sending) return; const todo = D.list().filter(x => !x.sent && x.kind !== "warn"); if (todo.length) send(todo).catch(() => { }); }, 20000);
  });
  window.BV.debug = { list: D.list, report, send, clear: D.clear, sharing, setSharing: v => store.set("dbgShare", !!v), device, KINDS };

  window.BV_APPS.push({
    id: "debug", name: "Debug Center", icon: "🐞", bg: "linear-gradient(135deg,#475569,#0f172a)", cat: "System", system: true, size: [620, 640],
    keywords: "debug errors problems log crash report bug console diagnostics developer",
    render(body, os) {
      let filter = "all", open = -1, note = "", busy = false;
      const draw = () => {
        const all = D.list(), shown = all.filter(e => filter === "all" || (filter === "errors" ? e.kind === "error" : filter === "net" ? e.kind === "network" || e.kind === "resource" : e.kind === "warn")).slice().reverse();
        const nErr = all.filter(e => e.kind !== "warn").length;
        body.innerHTML = `<div class="dbg">
          <div class="dbg-head"><b>${nErr ? `🔴 ${nErr} problem${nErr === 1 ? "" : "s"} recorded` : "✅ No problems recorded"}</b><small class="muted">Version ${esc(CFG().version)} · ${esc(device())}</small></div>
          <div class="dbg-tabs">${[["all", "All"], ["errors", "Errors"], ["net", "Network & files"], ["warn", "Warnings"]].map(([k, l]) => `<button data-f="${k}" class="${filter === k ? "on" : ""}">${l}</button>`).join("")}</div>
          <div class="dbg-list">${shown.length ? shown.map((e, i) => `<div class="dbg-row ${e.kind}" data-i="${i}">
              <div><span>${KINDS[e.kind]?.[0] || "•"}</span> <b>${esc(e.source || "")}</b>${e.n > 1 ? ` <em>×${e.n}</em>` : ""} <small class="muted">${time(e.t)}${e.sent ? " · sent" : ""}</small></div>
              <div class="dbg-msg">${esc(e.msg)}</div>${open === i && e.stack ? `<pre>${esc(e.stack)}</pre>` : ""}</div>`).join("") : `<p class="muted" style="text-align:center;padding:24px">Nothing here. Errors from every app show up in this list.</p>`}</div>
          ${note ? `<p class="dbg-note">${esc(note)}</p>` : ""}
          <div class="dbg-actions">
            <button class="btn" data-a="send" ${busy ? "disabled" : ""}>📤 Send to developer</button>
            <button class="btn ghost" data-a="feedback">💬 Attach to Feedback</button>
            <button class="btn ghost" data-a="copy">📋 Copy</button>
            <button class="btn ghost" data-a="save">💾 Save as file</button>
            <button class="btn ghost" data-a="clear">🗑 Clear</button></div>
          <label class="dbg-share"><input type="checkbox" data-share ${sharing() ? "checked" : ""}><span>Share errors with the developer automatically<br><small class="muted">Off by default. Sends only the error text, app version and device type, never passwords, keys or your files.</small></span></label>
        </div>`;
      };
      const on = e => { if (!body.isConnected) return; if (e === null || true) draw(); };
      let pending = 0;
      D.on(() => { if (body.isConnected) { clearTimeout(pending); pending = setTimeout(draw, 250); } });
      body.addEventListener("change", e => { if (e.target.matches("[data-share]")) { window.BV.debug.setSharing(e.target.checked); note = e.target.checked ? "Automatic sharing is on." : "Automatic sharing is off."; draw(); } });
      body.addEventListener("click", async e => {
        const f = e.target.closest("[data-f]"); if (f) { filter = f.dataset.f; open = -1; return draw(); }
        const row = e.target.closest("[data-i]"); if (row && !e.target.closest("button")) { open = open === +row.dataset.i ? -1 : +row.dataset.i; return draw(); }
        const a = e.target.closest("[data-a]")?.dataset.a; if (!a) return;
        if (a === "clear") { D.clear(); note = "Cleared."; return draw(); }
        if (a === "copy") { try { await navigator.clipboard.writeText(report()); note = "Report copied."; } catch { note = "Couldn't copy — use Save as file."; } return draw(); }
        if (a === "save") { window.BV.download(new Blob([report()], { type: "text/plain" }), `blockvile-debug-${new Date().toISOString().slice(0, 10)}.txt`); return; }
        if (a === "feedback") { const file = new File([report()], "blockvile-debug-report.txt", { type: "text/plain" }); return os.open("feedback", { type: "bug", text: "Debug report attached.", files: [file] }); }
        if (a === "send") {
          busy = true; note = "Sending…"; draw();
          try { const n = await send(D.list()); note = n ? `✅ Sent ${n} problem${n === 1 ? "" : "s"} to the developer. Thank you!` : "Nothing to send — no errors recorded."; }
          catch (err) { note = "⚠️ " + (err.message || "Couldn't send") + ". You can use Copy or Save as file instead."; }
          busy = false; draw();
        }
      });
      draw();
    }
  });
})();
