// Blockvile Plus OS — offline support for the installed app.
// Pages and files come from the website first (so updates show immediately) and from the saved copy when offline or slow.
const C = "blockvile-plus-v38";
const FILES = ["./", "index.html", "blockvile-plus-os.html", "privacy.html", "updater.html", "updater.webmanifest", "manifest.json", "css/style.css",
  "js/build.js", "js/config.js", "js/debug-core.js", "js/apps-debug.js", "js/lib.js", "js/android.js", "js/apps.js", "js/apps-media.js", "tube.html", "gamecenter.html", "js/games-catalog.js", "js/apps-games.js", "js/apps-publisher.js", "publisher.html", "js/apps-shop.js", "js/apps-admin.js", "games/bedwars.html", "games/skybedwars.html", "games/tidebreaker.html", "games/defense.html", "games/obby.html", "games/buttondash.html", "games/blockhop.html", "games/coincatcher.html", "games/memory.html", "games/snake.html", "js/apps-web.js", "js/apps-store.js", "js/apps-video.js", "js/apps-help.js", "js/accounts.js", "js/vendor/supabase.js", "js/updates.js", "js/apps-sim-ai.js", "js/os.js",
  "icons/logo.svg", "icons/icon-192.png", "icons/icon-512.png", "icons/maskable-512.png", "icons/apple-touch-icon.png"];

self.addEventListener("install", e => e.waitUntil(
  caches.open(C).then(c => Promise.all(FILES.map(f => c.add(f).catch(() => { })))).then(() => self.skipWaiting())
));
self.addEventListener("activate", e => e.waitUntil(
  caches.keys().then(ks => Promise.all(ks.filter(k => k !== C).map(k => caches.delete(k)))).then(() => self.clients.claim())
));
// "Update now": fetch every file fresh from the website into the cache, then tell the page to reload.
async function refreshAll() {
  const c = await caches.open(C);
  // optional files (e.g. the one-file copy, some icons) may not exist on every site, so only the core files must succeed
  const core = new Set(["index.html", "js/os.js", "js/lib.js", "css/style.css", "js/build.js"]);
  const res = await Promise.allSettled(FILES.map(async f => { const r = await fetch(f, { cache: "reload" }); if (!r.ok) throw new Error(f); await c.put(f, r); return f; }));
  const bad = FILES.filter((f, i) => res[i].status === "rejected" && core.has(f));
  if (bad.length) throw new Error("missing " + bad.join(", "));
}
self.addEventListener("message", e => {
  if (e.data !== "bv-update") return;
  const to = e.source;
  e.waitUntil(refreshAll().then(() => to && to.postMessage("bv-updated"), () => to && to.postMessage("bv-update-failed")));
});
self.addEventListener("fetch", e => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== "GET" || url.origin !== location.origin) return;
  if (url.pathname.endsWith("/version.json") || url.pathname.endsWith("/versions/index.json")) return;   // always ask the network, so "is there an update?" is never answered from the cache   // YouTube, weather etc. go straight to the network
  e.respondWith(caches.open("blockvile-local").then(async lc => {
    const mine = await lc.match(req, { ignoreSearch: req.mode === "navigate" });   // a zip installed from the Updater wins
    if (mine) return mine;
    return caches.open(C).then(async cache => {
    // Network first (so a new version shows straight away, even on phones), the saved copy only when offline or very slow
    const hit = await cache.match(req, { ignoreSearch: req.mode === "navigate" });
    const net = fetch(req, { cache: "no-cache" }).then(r => { if (r.ok) cache.put(req, r.clone()); return r; });
    try {
      return await (hit ? Promise.race([net, new Promise((_, no) => setTimeout(no, 4000))]) : net);
    } catch {
      e.waitUntil(net.catch(() => { }));
      if (hit) return hit;
      if (req.mode === "navigate") return (await cache.match("index.html")) || (await cache.match("blockvile-plus-os.html")) || Response.error();
      return Response.error();
    }
    });
  }));
});
