/* Blockvile Updater — settings. Use the SAME Supabase project as Blockvile Plus OS (Project Settings → API).
   The anon / publishable key is meant to be public. NEVER put the "service_role" key here. */
window.UPDATER_CONFIG = {
  supabaseUrl: "https://bcogtxeqeopvsyrejsdj.supabase.co",
  supabaseAnonKey: "sb_publishable_bPdSIexAYb7pHD0ALc_3wA_vj8XAWqH",
  osUrl: "https://1234pixil.github.io/blockvile-plus-os/"             // your Blockvile website, e.g. "https://1234pixil.github.io/blockvile-plus-os/"  (for the Open Blockvile link)
};
