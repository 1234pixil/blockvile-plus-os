plugins {
    id("com.android.application")
}

// Signing for Google Play uploads comes from environment variables (set by the GitHub workflow,
// or by you locally). Without them, release builds are simply left unsigned.
val keystoreFile: String? = System.getenv("BV_KEYSTORE_FILE")

android {
    namespace = "com.blockvile.plusos"
    compileSdk = 36

    defaultConfig {
        // Must be unique on Google Play — change it to something you own before your first upload.
        applicationId = "com.blockvile.plusos"
        minSdk = 26
        targetSdk = 36
        // Every upload to Play needs a higher number; the GitHub workflow passes its run number.
        versionCode = (project.findProperty("versionCode") as String?)?.toIntOrNull() ?: 1
        versionName = "3.25"
    }

    signingConfigs {
        create("release") {
            if (keystoreFile != null) {
                storeFile = file(keystoreFile)
                storePassword = System.getenv("BV_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("BV_KEY_ALIAS")
                keyPassword = System.getenv("BV_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (keystoreFile != null) signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // The Blockvile web OS lives in ../../web and is packed into the app as assets.
    sourceSets {
        getByName("main") {
            assets.srcDirs("src/main/assets", "../../web")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
