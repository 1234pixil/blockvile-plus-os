#!/usr/bin/env python3
"""
Packs the whole Blockvile Plus OS (web/ folder) into ONE self-contained HTML file.

    python3 tools/build-single-file.py                  -> blockvile-plus-os.html
    python3 tools/build-single-file.py out/page.html    -> custom output path

The result works when opened directly, hosted on any website, or embedded in an <iframe>.
"""
import base64, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
import subprocess
subprocess.run([sys.executable, str(ROOT / "tools" / "make-version.py")], check=True)   # keeps version.json / build id fresh
WEB = ROOT / "web"
out = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "blockvile-plus-os.html"

html = (WEB / "index.html").read_text(encoding="utf-8")
logo = "data:image/svg+xml;base64," + base64.b64encode((WEB / "icons/logo.svg").read_bytes()).decode()

def inline_css(m):
    css = (WEB / m.group(1)).read_text(encoding="utf-8")
    return "<style>\n" + css.replace("</style", "<\\/style") + "\n</style>"

def inline_js(m):
    js = (WEB / m.group(1)).read_text(encoding="utf-8").replace("icons/logo.svg", logo)
    return f"<script>/* {m.group(1)} */\n" + js.replace("</script", "<\\/script") + "\n</script>"

html = re.sub(r'<link rel="stylesheet" href="([^"]+)">', inline_css, html)
html = re.sub(r'\s*<link rel="manifest"[^>]*>', "", html)
html = html.replace("icons/logo.svg", logo)
# small PNG icons (home-screen icon on phones) are inlined too, so nothing points outside the file
for png in sorted((WEB / "icons").glob("*.png")):
    if png.stat().st_size < 8000:
        html = html.replace(f"icons/{png.name}", "data:image/png;base64," + base64.b64encode(png.read_bytes()).decode())
html = re.sub(r'<script src="([^"]+)"></script>', inline_js, html)
# tell the OS it's running as a single file (no offline service worker needed)
html = html.replace("<script>/* js/lib.js */", "<script>window.BV_SINGLE_FILE = true;</script>\n  <script>/* js/lib.js */", 1)

# the YouTube-style "Tube" page (tube.html) travels inside the file too, so it works without a website
tube = base64.b64encode((WEB / "tube.html").read_bytes()).decode()
html = html.replace("</body>", f'<script type="text/plain" id="bv-tube-src">{tube}</script>\n</body>', 1)

out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(html, encoding="utf-8")
print(f"Built {out} ({out.stat().st_size // 1024} KB)")
